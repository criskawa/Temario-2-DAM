
package serializable;
/*
 * @author Cris Perez
 */
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.SystemColor;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Label;

public class CrearEmpleado extends javax.swing.JFrame {
	
	// Creamos el array que contendra los trabajadores creados
	ArrayList<Empleado> grupoTrabajo = new ArrayList<>();

	// Configuracion de la ventana para crear empleados
	public CrearEmpleado() {
		setFont(new Font("Dialog", Font.BOLD, 13));
		getContentPane().setBackground(SystemColor.activeCaption);
		setTitle("Nuevo Empleado");
		initComponents();
		setLocationRelativeTo(null);
		
		

		// Configuracion para seleccionar solo un radiobutton
		if (rbHombre.isSelected()) {
			rbMujer.setSelected(false);
		}
	}
	
	
	private void initComponents() {
		new javax.swing.ButtonGroup();
		jDialog1 = new javax.swing.JDialog();
		jLabel1 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextPane1 = new javax.swing.JTextPane();
		jScrollPane2 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		lblNombre = new javax.swing.JLabel();
		lblNombre.setFont(new Font("Dialog", Font.BOLD, 13));
		lblAficiones = new javax.swing.JLabel();
		lblAficiones.setFont(new Font("Dialog", Font.BOLD, 13));
		lblEdad = new javax.swing.JLabel();
		lblEdad.setFont(new Font("Dialog", Font.BOLD, 13));
		lblGenero = new javax.swing.JLabel();
		lblGenero.setFont(new Font("Dialog", Font.BOLD, 13));
		btCrear = new javax.swing.JButton();
		btCrear.setFont(new Font("Dialog", Font.BOLD, 13));
		btMostrar = new javax.swing.JButton();
		btMostrar.setFont(new Font("Dialog", Font.BOLD, 13));
		tfNombre = new javax.swing.JTextField();
		tfNombre.setFont(new Font("Dialog", Font.PLAIN, 13));
		cbEdad = new javax.swing.JComboBox<>();
		cbEdad.setFont(new Font("Dialog", Font.BOLD, 13));
		cbProgramar = new javax.swing.JCheckBox();
		cbProgramar.setFont(new Font("Dialog", Font.BOLD, 13));
		cbCine = new javax.swing.JCheckBox();
		cbCine.setFont(new Font("Dialog", Font.BOLD, 13));
		cbDeporte = new javax.swing.JCheckBox();
		cbDeporte.setFont(new Font("Dialog", Font.BOLD, 13));
		rbMujer = new javax.swing.JRadioButton();
		rbMujer.setFont(new Font("Dialog", Font.BOLD, 13));
		rbHombre = new javax.swing.JRadioButton();
		rbHombre.setFont(new Font("Dialog", Font.BOLD, 13));
		
		
		javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
		jDialog1.getContentPane().setLayout(jDialog1Layout);
		jDialog1Layout.setHorizontalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 400, Short.MAX_VALUE));
		jDialog1Layout.setVerticalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 300, Short.MAX_VALUE));

		jLabel1.setText("jLabel1");

		jScrollPane1.setViewportView(jTextPane1);

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jScrollPane2.setViewportView(jTextArea1);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		lblNombre.setText("Nombre");

		lblAficiones.setText("Aficiones");

		lblEdad.setText("Edad");

		lblGenero.setText("Genero");

		btCrear.setText("Nuevo Empleado");
		btCrear.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btn_crearEmpleadoActionPerformed(evt);
			}
		});

		btMostrar.setText("Mostrar empleados");
		btMostrar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btn_mostrarEmpleadosActionPerformed(evt);
			}
		});

		tfNombre.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				tf_nombreEmpleadoActionPerformed(evt);
			}
		});

		cbEdad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "10-15", "15-20", "20-25", "25-30",
				"35-40", "40-45", "45-50", "50-55", "55-60", "60-65", "65-70" }));
		cbEdad.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

		cbProgramar.setText("Programar");
		cbProgramar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				cb_programarActionPerformed(evt);
			}
		});

		cbCine.setText("Cine");

		cbDeporte.setText("Deporte");

		rbMujer.setText("Mujer");
		rbMujer.addChangeListener(new javax.swing.event.ChangeListener() {
			public void stateChanged(javax.swing.event.ChangeEvent evt) {
				rb_mujerStateChanged(evt);
			}
		});

		rbHombre.setText("Hombre");
		rbHombre.addChangeListener(new javax.swing.event.ChangeListener() {
			public void stateChanged(javax.swing.event.ChangeEvent evt) {
				rb_hombreStateChanged(evt);
			}
		});
		
		JLabel lblBienvenido = new JLabel("Bienvenido");
		
		//Label que pasa el nombre introducido en la primera ventana
		JLabel lblNombre2 = new JLabel("");
		lblNombre2.setFont(new Font("SansSerif", Font.PLAIN, 14));
		lblNombre2.setVisible(false);
		
		

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGap(78)
					.addGroup(layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addGroup(layout.createSequentialGroup()
									.addGroup(layout.createParallelGroup(Alignment.LEADING)
										.addComponent(lblEdad)
										.addComponent(lblGenero, GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
										.addComponent(lblAficiones))
									.addGap(18))
								.addGroup(layout.createSequentialGroup()
									.addGap(1)
									.addGroup(layout.createParallelGroup(Alignment.LEADING)
										.addComponent(lblBienvenido, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNombre))
									.addGap(17)))
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
									.addComponent(tfNombre)
									.addGroup(layout.createSequentialGroup()
										.addGroup(layout.createParallelGroup(Alignment.TRAILING, false)
											.addComponent(cbEdad, Alignment.LEADING, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(cbProgramar, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(rbMujer, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(ComponentPlacement.UNRELATED)
										.addGroup(layout.createParallelGroup(Alignment.LEADING)
											.addGroup(layout.createSequentialGroup()
												.addComponent(cbCine)
												.addPreferredGap(ComponentPlacement.UNRELATED)
												.addComponent(cbDeporte))
											.addComponent(rbHombre))))
								.addGroup(layout.createSequentialGroup()
									.addGap(18)
									.addComponent(lblNombre2, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE))))
						.addGroup(layout.createSequentialGroup()
							.addComponent(btCrear)
							.addGap(39)
							.addComponent(btMostrar)))
					.addGap(45))
		);
		layout.setVerticalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGap(24)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblBienvenido, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNombre2, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(tfNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNombre))
					.addGap(32)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(cbProgramar)
						.addComponent(cbCine)
						.addComponent(cbDeporte)
						.addComponent(lblAficiones))
					.addGap(18)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEdad)
						.addComponent(cbEdad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblGenero)
						.addComponent(rbMujer)
						.addComponent(rbHombre))
					.addPreferredGap(ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btMostrar)
						.addComponent(btCrear))
					.addGap(43))
		);
		getContentPane().setLayout(layout);

		pack();
	}

	// Metodo para crear un archivo en el que guardaremos datos de trabajadores
	public File trabajadoresCreados() {

		String rutaProyecto = System.getProperty("user.dir");
		String separador = File.separator;
		String ruta_Archivos = rutaProyecto + separador + "carpeta";
		File carpeta = new File(ruta_Archivos);
		String crearArchivo = carpeta + separador + "listaTrabajadores.txt";
		File datos_empleados = new File(crearArchivo);
		// Comprobamos si existen trabajadores
		if (!datos_empleados.exists()) {
			try {
				datos_empleados.createNewFile();
			} catch (IOException ex) {
				Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		return datos_empleados;
	}

	// Comprobamos el genero seleccionado
	public String generoEmpleado() {

		String genero = "";
		if (rbHombre.isSelected()) {
			genero = "hombre";
		}
		if (rbMujer.isSelected()) {
			genero = "mujer";
		}
		return genero;
	}

	public String aficiones() {
		// Comprobamos qu� aficiones estan seleccionadas y ponemos condiciones en
		// funcion de las seleccionadas
		String aficion = "";
		boolean programar = cbProgramar.isSelected();
		boolean cine = cbCine.isSelected();
		boolean deporte = cbDeporte.isSelected();

		if (programar && cine && deporte) {
			aficion = "Programar, cine y deporte.";
		}
		if (programar && cine && !deporte) {
			aficion = "Programar y cine.";
		}
		if (programar && !cine && deporte) {
			aficion = "Programar y deporte.";
		}
		if (!programar && cine && !deporte) {
			aficion = "Cine.";
		}
		if (!programar && !cine && deporte) {
			aficion = "Deporte.";
		}
		if (!programar && cine && deporte) {
			aficion = "Cine y deporte.";
		}
		if (!programar && cine && deporte) {
			aficion = "Cine y deporte.";
		}
		if (programar && !cine && !deporte) {
			aficion = "Programar.";
		}return aficion;
	}

	// Leemos el archivo codificado
	public ArrayList recuperarTrabajadores(File datosEmpleados) throws IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(datosEmpleados));
		ArrayList grupoTrabajo = (ArrayList<Empleado>) ois.readObject();
		ois.close();

		return grupoTrabajo;
	}

	// Escribimos en el archivo codificado
	public void rellenarTrabajadores(ArrayList grupoTrabajo, File datosEmpleados)
			throws FileNotFoundException, IOException {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(datosEmpleados));
		oos.writeObject(grupoTrabajo);
		oos.close();
	}

	private void btn_crearEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {

		// Almacenamos el empleado y las selecciones
		File datosEmpleados = trabajadoresCreados();
		// Guardamos aficiones
		String aficion = aficiones();
		// Guardamos nombre
		String nombre = tfNombre.getText();
		// Guardamos edad
		String edad = cbEdad.getSelectedItem().toString();
		// Guardamos genero
		String genero = generoEmpleado();

		if (rbHombre.isSelected() || rbMujer.isSelected()) {
			if (!(nombre.isEmpty())) {

		// Generamos el empleado
				Empleado nuevoEmpleado = new Empleado(nombre, edad, genero, aficion);

				try {
					//Comprobamos si hay datos de empleados y los a�adimos al array
					String filtro = datosEmpleados.toString();
					if (filtro.isEmpty() == false) {
						grupoTrabajo = recuperarTrabajadores(datosEmpleados);
					}
				} catch (Exception e) {
				}
				//A�adimos los nuevos datos del empleado creado
				grupoTrabajo.add(nuevoEmpleado);

				try {
					rellenarTrabajadores(grupoTrabajo, datosEmpleados);
				} catch (IOException ex) {
					Logger.getLogger(CrearEmpleado.class.getName()).log(Level.SEVERE, null, ex);
				}

				// Ventana despues de introducir los datos correctamente
				jDialog1.setVisible(true);
				jDialog1.setLocationRelativeTo(null);
				jDialog1.setSize(300, 200);
				jLabel1.setText("Gracias por usar la aplicaci�n");
				jLabel1.setForeground(Color.black);
				Font auxFont = jLabel1.getFont();
				lblAficiones.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 15));
				jDialog1.setContentPane(jLabel1);

				// Ventana de aviso cuando no se ha introducido el nombre
			} else {
				jDialog1.setVisible(true);
				jDialog1.setLocationRelativeTo(null);
				jDialog1.setSize(250, 200);
				jLabel1.setText("Debe introducir el nombre");
				jLabel1.setForeground(Color.red);
				Font auxFont = jLabel1.getFont();
				jLabel1.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 15));
				jDialog1.setContentPane(jLabel1);
			}

			// Ventana de aviso de seleccion de genero
		} else {
			jDialog1.setVisible(true);
			jDialog1.setLocationRelativeTo(null);
			jDialog1.setSize(370, 200);
			jLabel1.setText("Debe introducir un genero");
			jLabel1.setForeground(Color.red);
			Font auxFont = jLabel1.getFont();
			jLabel1.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 15));
			jDialog1.setContentPane(jLabel1);
		}

	}
	private void rb_mujerStateChanged(javax.swing.event.ChangeEvent evt) {
		if (rbMujer.isSelected()) {
			rbHombre.setSelected(false);
		}
	}

	
	private void tf_nombreEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private void cb_programarActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private void rb_hombreStateChanged(javax.swing.event.ChangeEvent evt) {
		if (rbHombre.isSelected()) {
			rbMujer.setSelected(false);
		}
	}

	private void btn_mostrarEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {

		File datos_empleados = trabajadoresCreados();
		// Generamos una variable donde almacenaremos el archivo de empleados
		String archivoEmpleados = "";
		try {

			grupoTrabajo = recuperarTrabajadores(datos_empleados);
		// Recorremos el array y rellenamos el archivo
			for (int i = 0; i < grupoTrabajo.size(); i++) {
				archivoEmpleados += grupoTrabajo.get(i) + "\n";
			}

			jTextArea1.setText(archivoEmpleados);
			jDialog1.setVisible(true);
			jDialog1.setLocationRelativeTo(null);
			jDialog1.setSize(600, 400);
			jDialog1.setContentPane(jTextArea1);

		} catch (IOException ex) {
			Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(CrearEmpleado.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public static void main(String args[]) {

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(CrearEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(CrearEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(CrearEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(CrearEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		// </editor-fold>

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new CrearEmpleado().setVisible(true);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton btCrear;
	private javax.swing.JButton btMostrar;
	private javax.swing.JCheckBox cbCine;
	private javax.swing.JCheckBox cbDeporte;
	private javax.swing.JComboBox<String> cbEdad;
	private javax.swing.JCheckBox cbProgramar;
	private javax.swing.JDialog jDialog1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel lblNombre;
	private javax.swing.JLabel lblAficiones;
	private javax.swing.JLabel lblEdad;
	private javax.swing.JLabel lblGenero;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextPane jTextPane1;
	private javax.swing.JRadioButton rbHombre;
	private javax.swing.JRadioButton rbMujer;
	private javax.swing.JTextField tfNombre;
}
