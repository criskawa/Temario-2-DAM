
package serializable;
/*
 * @author Cris Perez
 */
import	java.io.Serializable;
// Clase Empleado con atributos,getters y setters, tambien serializable
public class Empleado implements Serializable {
    
    String nombre;
    String edad;
    String genero;
    String aficion;
    
    // Constructor de la clase
    public Empleado(String nombre,String edad,String genero, String aficion){
    this.nombre= nombre;
    this.edad=edad;
    this.genero=genero;
    this.aficion=aficion;
    }
    
    
    public String getNombre(){
        return nombre;
    }
    public String getEdad(){
        return edad;
    }
    public String getGenero(){
        return genero;
    }
    public String getHobby(){
        return aficion;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setEdad(String edad){
        this.edad=edad;
    }
    public void setSexo(String genero){
        this.genero=genero;
    }
    public void setHobby(String aficion){
        this.aficion=aficion;
    }
    
    // Generamos tambien toString
    public String toString (){
        return "Empleado: Nombre: "+nombre+" Edad: "+edad+" Sexo: "+genero+" Aficiones: " + aficion;
    }
}


