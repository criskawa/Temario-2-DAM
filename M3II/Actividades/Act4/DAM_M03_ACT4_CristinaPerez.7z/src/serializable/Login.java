
package serializable;
/*
 * @author Cris Perez
 */
import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;

//Configuracion de la ventana LOGIN (Layouts, compornentes)
public class Login extends javax.swing.JFrame {
	// Creamos una carpeta dentro del proyecto, para meter el archivo de texto que
	// se creara con los empleados introducidos
	public File crearCarpeta() {
		String rutaProyecto = System.getProperty("user.dir");
		// Separador para la carpeta
		String separador = File.separator;
		String ruta_Archivos = rutaProyecto + separador + "carpeta";
		File carpetaArchivo = new File(ruta_Archivos);
		// Si no existe la crea
		if (!carpetaArchivo.exists()) {
			carpetaArchivo.mkdir();
		}
		return carpetaArchivo;
	}

	// Creamos el archivo en el que vamos a introducir los empleados a traves del
	// formulario
	public File crearArchivo(File carpeta) {
		// Creo un separador para que no de problemas
		String separador = File.separator;
		String crearArchivo = carpeta + separador + "datos_login.txt";
		File archivo = new File(crearArchivo);
		// Si no existe el archivo,lo crea
		if (!archivo.exists()) {
			try {
				archivo.createNewFile();
			} catch (IOException ex) {
				Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		return archivo;
	}

	// Metodo para escribir en el archivo
	public void escribirArchivo(String texto, File archivo) {
		try {
			FileWriter fw = new FileWriter(archivo);
			BufferedWriter bw = new BufferedWriter(fw);
			// Escribimos y cerramos
			bw.write(texto);
			bw.close();
		} catch (IOException ex) {
			Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	// Metodo para leer el archivo que hemos creado
	public String leerArchivo(File archivo) {
		String linea = "";
		try {
			linea = "";
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			// Leemos y cerramos
			linea = br.readLine();
			br.close();
		} catch (IOException ex) {
			Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
		}
		return linea;
	}

	// Configuracion de la ventana login
	public Login() {
		getContentPane().setBackground(SystemColor.activeCaption);
		setBackground(SystemColor.activeCaption);
		setFont(new Font("Dialog", Font.PLAIN, 11));
		setTitle("LOGIN");
		initComponents();
		setLocationRelativeTo(null);
		setSize(561, 561);
	}

	// Inicializacion y configuracion de componentes
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jDialog1 = new javax.swing.JDialog();
		jLabel1 = new javax.swing.JLabel();
		btAceptar = new javax.swing.JButton();
		btAceptar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btAceptar.setBackground(SystemColor.textHighlight);
		tfUsuario = new javax.swing.JTextField();
		tfUsuario.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblUsuario = new javax.swing.JLabel();
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblContra = new javax.swing.JLabel();
		lblContra.setFont(new Font("Tahoma", Font.PLAIN, 14));
		pfContra = new javax.swing.JPasswordField();
		pfContra.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
	// Configuracion del layout
		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 100, Short.MAX_VALUE));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 100, Short.MAX_VALUE));
		javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
		jDialog1.getContentPane().setLayout(jDialog1Layout);
		jDialog1Layout.setHorizontalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 400, Short.MAX_VALUE));
		jDialog1Layout.setVerticalGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 300, Short.MAX_VALUE));
		
	//Etiqueta para errores
		jLabel1.setText(" ");
	//Configuracion de accion al cerrar la ventana
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
	//Configuracion de boton aceptar
		btAceptar.setText("Aceptar");
		btAceptar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btn_registroActionPerformed(evt);
			}
		});

	//Cuadro para introducir nombre del nuevo empleado
		tfUsuario.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
	//Etiquetas
		lblUsuario.setText("Usuario");

		lblContra.setText("Contrase\u00F1a");
	//Campo para introducir contrase�a
		pfContra.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jPasswordField1ActionPerformed(evt);
			}
		});
		
		JLabel lblVacias = new JLabel("DEBES INTRODUCIR LOS DATOS");
		lblVacias.setForeground(new Color(255, 0, 0));
		lblVacias.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblVacias.setVisible(false);
		
		JLabel lblIncorrectas = new JLabel("CREDENCIALES INCORRECTAS");
		lblIncorrectas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblIncorrectas.setForeground(new Color(255, 0, 0));
		lblIncorrectas.setVisible(false);

		
	//Configuracion de Layouts
		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGroup(layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
							.addGap(49)
							.addGroup(layout.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblContra)
								.addComponent(lblUsuario))
							.addGap(18)
							.addGroup(layout.createParallelGroup(Alignment.TRAILING)
								.addComponent(btAceptar)
								.addGroup(layout.createSequentialGroup()
									.addGroup(layout.createParallelGroup(Alignment.TRAILING)
										.addComponent(pfContra, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
										.addComponent(tfUsuario, GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE))
									.addGap(16))))
						.addGroup(layout.createSequentialGroup()
							.addGap(28)
							.addComponent(lblVacias, GroupLayout.PREFERRED_SIZE, 254, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, layout.createSequentialGroup()
							.addContainerGap(29, Short.MAX_VALUE)
							.addComponent(lblIncorrectas, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		layout.setVerticalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGap(77)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(tfUsuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblUsuario))
					.addGap(18)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(pfContra, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblContra, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(btAceptar)
					.addGap(18)
					.addComponent(lblVacias, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblIncorrectas, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(62, Short.MAX_VALUE))
		);
		getContentPane().setLayout(layout);
		pack();
	}

	public void btn_registroActionPerformed(java.awt.event.ActionEvent evt) {

	//Creamos carpeta y archivo para despues leerlo y comprobar si coincide usuario y password
		File carpeta = crearCarpeta();
		File archivo = crearArchivo(carpeta);
	//Escribimos en el archivo y lo leemos
		String usuarioContra = "user,12345";
		escribirArchivo(usuarioContra, archivo);
		String datosArchivo = leerArchivo(archivo);
		String contenidoArchivo = datosArchivo;

	// Recogemos los datos introducidos en la ventana de login
		String usuarioIntroducido = tfUsuario.getText();
		String contrase�aIntroducida = pfContra.getText();
		String usuario = contenidoArchivo.substring(0, 4);
		String contrase�a = contenidoArchivo.substring(5, 10);
		/**/

		jLabel1.setText(usuario);
	// Comprobamos los campos usuario y contrase�a, si estan vacios, queria mostar las etiquetas en rojo que he inicializado en false, pero no me sale 
	// por tema de ambitos,no lo he conseguido, asi que pongo un jDialog con label rojo
		if (usuarioIntroducido.isEmpty() && contrase�aIntroducida.isEmpty()) {

			//lblVacias.setVisible(true);
			
			jDialog1.setVisible(true);
			jDialog1.setLocationRelativeTo(null);
			jDialog1.setSize(300, 200);
			lblUsuario.setText("DEBES INTRODUCIR LOS DATOS");
			lblUsuario.setForeground(Color.red);
			Font auxFont = lblUsuario.getFont();
			lblUsuario.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 15));
			jDialog1.setContentPane(lblUsuario);

	//Aqui haria lo mismo,en caso de ser incorrectos, mostrar la etiqueta correspondiente, pero pongo un jDialog, y cerramos con dispose para  liberar memoria.	
		}else {
			if (usuario.equals(usuarioIntroducido) && contrase�a.equals(contrase�aIntroducida)) {
				
				//si son correctas abre la ventana de registrar empleados

				new CrearEmpleado().setVisible(true);
				// Liberamos recursos
				new Login().dispose();

			} else {
				
				//lblIncorrectas.setVisible(true);
				jDialog1.setVisible(true);
				jDialog1.setLocationRelativeTo(null);
				jDialog1.setSize(300, 200);
				lblUsuario.setText("CREDENCIALES INCORRECTAS");
				lblUsuario.setForeground(Color.red);
				Font auxFont = lblUsuario.getFont();
				lblUsuario.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 15));
				jDialog1.setContentPane(lblUsuario);
			}
		}
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		
	}

	private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {
		
	}

	public static void main(String args[]) {

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Login().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton btAceptar;
	private javax.swing.JDialog jDialog1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel lblUsuario;
	private javax.swing.JLabel lblContra;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPasswordField pfContra;
	private javax.swing.JTextField tfUsuario;
}
