package actividad07.exceptions;
/**3.	Crea una excepción propia NombreIncorrecto que se lance con el mensaje “El nombre debe tener mínimo 3 letras" o bien "El nombre no puede tener dígitos" en el método setNombre de Persona cuando el nombre tenga menos de 3 letras o contenga algún número respectivamente.  */
public class NombreIncorrecto extends Exception {
    public NombreIncorrecto(String mensaje){
        super(mensaje);
    }
}