package actividad07.exceptions;
/**2.	Crea una excepción propia EdadIncorrecta que se lance con el mensaje “La edad no puede ser menor a 1 ni mayor a 110” en el método setEdad de Persona cuando se intente establecer una edad menor a 1 o mayor a 110. */
public class EdadIncorrecta extends Exception{
    public EdadIncorrecta(String msg){
        super(msg);
    }
}