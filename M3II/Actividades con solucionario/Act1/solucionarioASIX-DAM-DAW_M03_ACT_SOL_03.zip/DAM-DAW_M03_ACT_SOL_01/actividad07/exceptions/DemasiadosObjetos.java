package actividad07.exceptions;
public class DemasiadosObjetos extends Exception {
	public DemasiadosObjetos (String mensaje){
		super(mensaje);
	}
}
