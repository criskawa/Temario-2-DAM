package actividad07.exceptions;

public class PosicionIncorrecta extends Exception{
    public PosicionIncorrecta(String msg){
        super(msg);
    }
}