package actividad07.exceptions;
/**2.	Crea una excepción propia EdadIncorrecta que se lance con el mensaje “La edad no puede ser menor a 1 ni mayor a 110” en el método setEdad de Persona cuando se intente establecer una edad menor a 1 o mayor a 110. */
public class DniIncorrecto extends Exception{
    public DniIncorrecto(){
        super("El DNI ha de ser una string de 9 valores");
    }
}