package actividad07;
import actividad07.exceptions.*;
/**1.	Crea una clase Persona con los siguientes campos: nombre y edad. Se debe crear el constructor y los métodos get y set necesarios.  */
public class Persona {
	private String nombre;
	private int edad;
	private String dni;

	public Persona(){
		super();
	}
	public Persona(String nombre, int edat,String dni) throws EdadIncorrecta, DniIncorrecto, NombreIncorrecto {
		setNombre(nombre);
		setEdad(edat);
		setDni(dni);
	}
	public String getNombre() {
		return nombre;
	}
	public String getDni(){
		return dni;
	}
	public void setDni(String dni) throws DniIncorrecto{
		if(dni.length()!=9){
			throw new DniIncorrecto();
		}
		this.dni = dni;
	}
	public void setNombre(String nombre) throws NombreIncorrecto {
		if(nombre.length()<3){
			throw new NombreIncorrecto("El nombre debe tener minimo 3 letras");
		}
		if(nombre.matches(".*\\d.*")){
			throw new NombreIncorrecto("El nombre no puede tener digitos");
		}
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) throws EdadIncorrecta {
		if(edad<1 || edad >110){
			throw new EdadIncorrecta("La edad no puede ser menor a 1 ni mayor a 110");
		}
		this.edad = edad;
	}
	public String toString(){
		return " _"+nombre+"_ edad:"+edad;
	}
	
}
