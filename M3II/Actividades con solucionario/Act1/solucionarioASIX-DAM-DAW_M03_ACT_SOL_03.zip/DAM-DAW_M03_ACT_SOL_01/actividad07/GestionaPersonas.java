package actividad07;

import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.Iterator;

import actividad07.Persona;
import actividad07.exceptions.*;
import actividad07.pideDatos.Pregunta;

/**
 * 4. Crea una clase GestionaPersonas que muestre un menú al usuario con las
 * opciones: • 1- Añadir una persona a un ArrayList de personas • 2- Borrar una
 * persona de un ArrayList de personas. • 0- Salir
 */
public class GestionaPersonas {
    static HashMap<String, Persona> trabajadores = new HashMap<String, Persona>();
    static ArrayList<Persona> grupoTrabajo = new ArrayList<Persona>();

    public static void main(String[] args) {
        try {
            trabajadores.put("55667788I", new Persona("Gin", 33,"55667788I"));
            trabajadores.put("33998877E", new Persona("Jon", 33,"33998877E"));
        } catch (EdadIncorrecta | DniIncorrecto | NombreIncorrecto e1) {
            e1.printStackTrace();
        }


        int opcion = 0;
        do {
            System.out.println("\n Qué quieres hacer?:" + "\n 1-Añade una Persona" +
             "\n 2-Borra una Persona"
                    + "\n 3-Añade una persona al grupo de trabajo " + "\n 4-Quita una persona del grupo de trabajo"
                    + "\n 0-Salir");
            opcion = Pregunta.pideValorMinMax(0, 4);
            switch (opcion) {
                case 0:
                    break;
                case 1:
                    addTrabajador();
                    muestraTrabajadores();
                    muestraGrupo();
                    break;
                case 2:
                    quitaTrabajador();
                    muestraTrabajadores();
                    muestraGrupo();
                    break;
                case 3:
                    try {
                        addPersonaGrupo();
                        muestraTrabajadores();
                        muestraGrupo();
                    } catch (DemasiadosObjetos e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    try {
                        quitaPersonaGrupo();
                        muestraTrabajadores();
                        muestraGrupo();
                    } catch (PosicionIncorrecta e) {
                        e.printStackTrace();
                    }
                    break;

            }

        } while (opcion != 0);
    }

    /*
     * • Si el usuario indica un índice fuera del rango posible, lanza desde la
     * función de borrar una persona, una excepción PosicionIncorrecta y capturala
     * en el main.
     */
    public static void quitaPersonaGrupo() throws PosicionIncorrecta {
        muestraGrupo();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Indica el numero de persona a borrar");
        try {
            int numero = Integer.parseInt(br.readLine());
            if (numero < 0 || numero >= grupoTrabajo.size()) {
                throw new PosicionIncorrecta(
                        "Numero de persona no puede ser menor a 0 ni mayor a " + (grupoTrabajo.size() - 1));
            }
            grupoTrabajo.remove(numero);

        } catch (NumberFormatException | IOException e) {
            e.printStackTrace();
            System.out.println("Formato del numero no valido");
        }
    }

    /*
     * • Como máximo el ArrayList puede contener 2 personas, si se intenta añadir
     * una tercera lanza ,desde la función de añadir una persona, una excepción
     * propia del tipo DemasiadoObjetos y captúrala en el main.
     */
    public static void addPersonaGrupo() throws DemasiadosObjetos {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        if (grupoTrabajo.size() >= 2) {
            throw new DemasiadosObjetos("Como máximo se puede contener 2 personas");
        }

        Persona persona = new Persona();
        boolean datoCorrecto;
        do {
            try {
                datoCorrecto = true;
                System.out.println("Indica el dni de la persona");
                String dni = br.readLine();
                persona = trabajadores.get(dni);
                if (persona == null) {
                    datoCorrecto = false;
                } else {

                }
            } catch (IOException e) {
                datoCorrecto = false;
            }
        } while (!datoCorrecto);

        grupoTrabajo.add(persona);
    }

    public static void muestraGrupo() {
        System.out.println("---Grupo de trabajo:---");
        for (int i = 0; i < grupoTrabajo.size(); i++) {
            System.out.println("[" + i + "] " + grupoTrabajo.get(i));

        }
    }

    /*
     * Muestra un listado de todos los trabajadores mostrando el dni, nombre y edad
     */
    public static void muestraTrabajadores() {
        System.out.println("---Lista de trabajadores:---");
        Iterator it = trabajadores.entrySet().iterator();
        it = trabajadores.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry e = (HashMap.Entry) it.next();
            System.out.println(e.getKey() + " -  " + e.getValue());
        }
    }

    /*
     * Crea una nueva persona y la añade al array de trabajadores.
     */
    public static void addTrabajador() {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        Persona persona = new Persona();
        boolean datoCorrecto;
        do {
            datoCorrecto = true;
            System.out.println("Indica nombre de la persona (solo letras)");
            try {
                String nombre = br.readLine();
                persona.setNombre(nombre);
            } catch (NombreIncorrecto e1) {
                e1.printStackTrace();
                datoCorrecto = false;
            } catch (IOException e2) {
                e2.printStackTrace();
                datoCorrecto = false;
            }
        } while (!datoCorrecto);

        do {
            datoCorrecto = true;
            System.out.println("Indica la edad (entre 1 y 110)");
            try {
                int edad = Integer.parseInt(br.readLine());
                persona.setEdad(edad);
            } catch (EdadIncorrecta | NumberFormatException | IOException e) {
                e.printStackTrace();
                datoCorrecto = false;
            }
        } while (!datoCorrecto);

        do {
            datoCorrecto = true;
            System.out.println("Indica el dni (una string de 9 caracteres)");
            try {
                String dni = (br.readLine());
                persona.setDni(dni);
            } catch (DniIncorrecto | IOException e) {
                e.printStackTrace();
                datoCorrecto = false;
            }
        } while (!datoCorrecto);

        trabajadores.put(persona.getDni(), persona);

    }

    public static void quitaTrabajador() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Persona persona;

        try {

            System.out.println("Indica el dni de la persona");
            String dni = br.readLine();
            persona = trabajadores.get(dni);
            if (persona == null) {
                System.out.print("La persona no existe");
            } else {
                System.out.println("El trabajador " + persona + " ha sido eliminado");
                trabajadores.remove(dni);
            }
        } catch (IOException e) {
            System.out.print("La persona no existe");
        }

    }
}
