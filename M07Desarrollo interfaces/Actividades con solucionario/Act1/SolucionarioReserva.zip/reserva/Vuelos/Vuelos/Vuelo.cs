﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Vuelos
{
    [Serializable]
    public class Vuelo
    {
        private String numero;
        private Aeropuerto origen;
        private Aeropuerto destino;
        private DateTime fecha;
        private Aerolinea aerolinea;
        public Vuelo(string numero, Aeropuerto origen, Aeropuerto destino, DateTime fecha, Aerolinea aerolinea)
        {
            this.numero = numero;
            this.origen = origen;
            this.destino = destino;
            this.fecha = fecha;
            this.aerolinea = aerolinea;
        }
        public string Numero { get => numero; set => numero = value; }
        public Aeropuerto Origen { get => origen; set => origen = value; }
        public Aeropuerto Destino { get => destino; set => destino = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public Aerolinea Aerolinea { get => aerolinea; set => aerolinea = value; }

        public void exportar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s = new FileStream(fichero, FileMode.Append, FileAccess.Write);
            bf.Serialize(s, this);
            s.Close();
        }
        public static List<Vuelo> importar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s;
            List<Vuelo> lista = new List<Vuelo>();
            s = new FileStream(fichero, FileMode.Open, FileAccess.ReadWrite);
            while (s.Position < s.Length)
            {
                Vuelo v = (Vuelo)bf.Deserialize(s);
                lista.Add(v);
            }
            s.Close();
            return lista;
        }
    }
}

