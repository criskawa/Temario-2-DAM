﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Vuelos
{
    [Serializable]
    public class Aeropuerto
    {
        private String nombre;
        private String siglas;
        private bool nacional;
        public Aeropuerto(string nombre, string siglas, bool nacional)
        {
            this.nombre = nombre;
            this.siglas = siglas;
            this.nacional = nacional;
        }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Siglas { get => siglas; set => siglas = value; }
        public bool Nacional { get => nacional; set => nacional = value; }
        public void exportar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s = new FileStream(fichero, FileMode.Append, FileAccess.Write);
            bf.Serialize(s, this);
            s.Close();
        }
        public static List<Aeropuerto> importar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s;
            List<Aeropuerto> lista = new List<Aeropuerto>();
            s = new FileStream(fichero, FileMode.Open, FileAccess.ReadWrite);
            while (s.Position < s.Length)
            {
                Aeropuerto a = (Aeropuerto)bf.Deserialize(s);
                lista.Add(a);
            }
            s.Close();
            return lista;
        }
    }
}
