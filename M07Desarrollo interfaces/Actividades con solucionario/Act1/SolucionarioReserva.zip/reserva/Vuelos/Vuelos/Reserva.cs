﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vuelos
{
    public partial class Reserva : Form
    {
        private Vuelo vuelo;
        private int adultos;
        private int ninyos;
        private bool extra;
        public Reserva(Vuelo vuelo,int adultos,int ninyos,bool extra)
        {
            InitializeComponent();
            this.vuelo = vuelo;
            this.adultos = adultos;
            this.ninyos = ninyos;
            this.extra = extra;
        }
        public Vuelo Vuelo { get => vuelo; set => vuelo = value; }
        public int Adultos { get => adultos; set => adultos = value; }
        public int Ninyos { get => ninyos; set => ninyos = value; }
        public bool Extra { get => extra; set => extra = value; }
        public void confirmar()
        {
            label2.Text = vuelo.Origen.Nombre;
            label5.Text = vuelo.Destino.Nombre;
            label7.Text = vuelo.Aerolinea.Nombre + " - " + vuelo.Numero;
            label9.Text = vuelo.Fecha.ToShortDateString();
            label11.Text = vuelo.Fecha.ToShortTimeString();
            label15.Text = adultos.ToString();
            label13.Text = ninyos.ToString();
            if (extra) label17.Text = "SI"; else label17.Text = "NO";
            this.ShowDialog();
        }
    }
}
