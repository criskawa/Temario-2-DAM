﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Vuelos
{
    [Serializable]
    public class Aerolinea
    {
        private String nombre;
        private String codigo;
        private Bitmap logo;
        public Aerolinea(string nombre, string codigo, Bitmap logo)
        {
            this.nombre = nombre;
            this.codigo = codigo;
            this.logo = logo;
        }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Codigo { get => codigo; set => codigo = value; }
        public Bitmap Logo { get => logo; set => logo = value; }
        public void exportar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s = new FileStream(fichero, FileMode.Append, FileAccess.Write);
            bf.Serialize(s, this);
            s.Close();
        }
        public static List<Aerolinea> importar(String fichero)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s;
            List<Aerolinea> lista = new List<Aerolinea>();
            s = new FileStream(fichero, FileMode.Open, FileAccess.ReadWrite);
            while (s.Position < s.Length)
            {
                Aerolinea a = (Aerolinea)bf.Deserialize(s);
                lista.Add(a);
            }
            s.Close();
            return lista;
        }
    }
}
