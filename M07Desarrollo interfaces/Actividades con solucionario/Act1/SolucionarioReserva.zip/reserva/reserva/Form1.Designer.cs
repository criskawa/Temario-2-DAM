﻿namespace reserva
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lista = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dtp_desde = new System.Windows.Forms.DateTimePicker();
            this.bt_buscar = new System.Windows.Forms.Button();
            this.dtp_hasta = new System.Windows.Forms.DateTimePicker();
            this.cb_salida = new System.Windows.Forms.ComboBox();
            this.cb_llegada = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cb_vueling = new System.Windows.Forms.CheckBox();
            this.cb_ryanair = new System.Windows.Forms.CheckBox();
            this.cb_qatar = new System.Windows.Forms.CheckBox();
            this.cb_aeuropa = new System.Windows.Forms.CheckBox();
            this.cb_easy = new System.Windows.Forms.CheckBox();
            this.cb_iberia = new System.Windows.Forms.CheckBox();
            this.nud_adultos = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_extra = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.nud_ninyos = new System.Windows.Forms.NumericUpDown();
            this.gb_reserva = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lb_vuelo = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_adultos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ninyos)).BeginInit();
            this.gb_reserva.SuspendLayout();
            this.SuspendLayout();
            // 
            // lista
            // 
            this.lista.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lista.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lista.FullRowSelect = true;
            this.lista.HideSelection = false;
            this.lista.Location = new System.Drawing.Point(28, 188);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(1234, 324);
            this.lista.SmallImageList = this.imageList1;
            this.lista.TabIndex = 0;
            this.lista.UseCompatibleStateImageBehavior = false;
            this.lista.View = System.Windows.Forms.View.Details;
            this.lista.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lista_MouseClick);
            this.lista.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lista_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Vuelo";
            this.columnHeader1.Width = 250;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Salida";
            this.columnHeader2.Width = 290;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Llegada";
            this.columnHeader3.Width = 261;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Fecha";
            this.columnHeader4.Width = 122;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Hora";
            this.columnHeader5.Width = 106;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "aireuropa.png");
            this.imageList1.Images.SetKeyName(1, "easyjet.png");
            this.imageList1.Images.SetKeyName(2, "iberia.png");
            this.imageList1.Images.SetKeyName(3, "qatar.png");
            this.imageList1.Images.SetKeyName(4, "Ryanair.png");
            this.imageList1.Images.SetKeyName(5, "vueling.png");
            // 
            // dtp_desde
            // 
            this.dtp_desde.Checked = false;
            this.dtp_desde.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_desde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_desde.Location = new System.Drawing.Point(91, 36);
            this.dtp_desde.Name = "dtp_desde";
            this.dtp_desde.ShowCheckBox = true;
            this.dtp_desde.Size = new System.Drawing.Size(160, 26);
            this.dtp_desde.TabIndex = 1;
            this.dtp_desde.ValueChanged += new System.EventHandler(this.dtp_desde_ValueChanged);
            // 
            // bt_buscar
            // 
            this.bt_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_buscar.Location = new System.Drawing.Point(1136, 99);
            this.bt_buscar.Name = "bt_buscar";
            this.bt_buscar.Size = new System.Drawing.Size(126, 44);
            this.bt_buscar.TabIndex = 2;
            this.bt_buscar.Text = "BUSCAR...";
            this.bt_buscar.UseVisualStyleBackColor = true;
            this.bt_buscar.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtp_hasta
            // 
            this.dtp_hasta.Checked = false;
            this.dtp_hasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_hasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_hasta.Location = new System.Drawing.Point(91, 92);
            this.dtp_hasta.Name = "dtp_hasta";
            this.dtp_hasta.ShowCheckBox = true;
            this.dtp_hasta.Size = new System.Drawing.Size(160, 26);
            this.dtp_hasta.TabIndex = 3;
            this.dtp_hasta.ValueChanged += new System.EventHandler(this.dtp_hasta_ValueChanged);
            // 
            // cb_salida
            // 
            this.cb_salida.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_salida.FormattingEnabled = true;
            this.cb_salida.Location = new System.Drawing.Point(91, 44);
            this.cb_salida.Name = "cb_salida";
            this.cb_salida.Size = new System.Drawing.Size(298, 28);
            this.cb_salida.TabIndex = 4;
            // 
            // cb_llegada
            // 
            this.cb_llegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_llegada.FormattingEnabled = true;
            this.cb_llegada.Location = new System.Drawing.Point(91, 102);
            this.cb_llegada.Name = "cb_llegada";
            this.cb_llegada.Size = new System.Drawing.Size(298, 28);
            this.cb_llegada.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Salida";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Llegada";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Desde";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Hasta";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dtp_hasta);
            this.groupBox1.Controls.Add(this.dtp_desde);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(448, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 141);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Fecha";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cb_llegada);
            this.groupBox2.Controls.Add(this.cb_salida);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(415, 148);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Aeropuerto";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_vueling);
            this.groupBox3.Controls.Add(this.cb_ryanair);
            this.groupBox3.Controls.Add(this.cb_qatar);
            this.groupBox3.Controls.Add(this.cb_aeuropa);
            this.groupBox3.Controls.Add(this.cb_easy);
            this.groupBox3.Controls.Add(this.cb_iberia);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(766, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(339, 137);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Compañia";
            // 
            // cb_vueling
            // 
            this.cb_vueling.Checked = true;
            this.cb_vueling.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_vueling.ImageIndex = 5;
            this.cb_vueling.ImageList = this.imageList1;
            this.cb_vueling.Location = new System.Drawing.Point(228, 74);
            this.cb_vueling.Name = "cb_vueling";
            this.cb_vueling.Size = new System.Drawing.Size(99, 52);
            this.cb_vueling.TabIndex = 5;
            this.cb_vueling.UseVisualStyleBackColor = true;
            // 
            // cb_ryanair
            // 
            this.cb_ryanair.Checked = true;
            this.cb_ryanair.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_ryanair.ImageIndex = 4;
            this.cb_ryanair.ImageList = this.imageList1;
            this.cb_ryanair.Location = new System.Drawing.Point(123, 74);
            this.cb_ryanair.Name = "cb_ryanair";
            this.cb_ryanair.Size = new System.Drawing.Size(99, 52);
            this.cb_ryanair.TabIndex = 4;
            this.cb_ryanair.UseVisualStyleBackColor = true;
            // 
            // cb_qatar
            // 
            this.cb_qatar.Checked = true;
            this.cb_qatar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_qatar.ImageIndex = 3;
            this.cb_qatar.ImageList = this.imageList1;
            this.cb_qatar.Location = new System.Drawing.Point(18, 74);
            this.cb_qatar.Name = "cb_qatar";
            this.cb_qatar.Size = new System.Drawing.Size(99, 52);
            this.cb_qatar.TabIndex = 3;
            this.cb_qatar.UseVisualStyleBackColor = true;
            // 
            // cb_aeuropa
            // 
            this.cb_aeuropa.Checked = true;
            this.cb_aeuropa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_aeuropa.ImageIndex = 0;
            this.cb_aeuropa.ImageList = this.imageList1;
            this.cb_aeuropa.Location = new System.Drawing.Point(228, 23);
            this.cb_aeuropa.Name = "cb_aeuropa";
            this.cb_aeuropa.Size = new System.Drawing.Size(99, 52);
            this.cb_aeuropa.TabIndex = 2;
            this.cb_aeuropa.UseVisualStyleBackColor = true;
            // 
            // cb_easy
            // 
            this.cb_easy.Checked = true;
            this.cb_easy.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_easy.ImageIndex = 1;
            this.cb_easy.ImageList = this.imageList1;
            this.cb_easy.Location = new System.Drawing.Point(123, 22);
            this.cb_easy.Name = "cb_easy";
            this.cb_easy.Size = new System.Drawing.Size(99, 52);
            this.cb_easy.TabIndex = 1;
            this.cb_easy.UseVisualStyleBackColor = true;
            // 
            // cb_iberia
            // 
            this.cb_iberia.Checked = true;
            this.cb_iberia.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_iberia.ImageIndex = 2;
            this.cb_iberia.ImageList = this.imageList1;
            this.cb_iberia.Location = new System.Drawing.Point(18, 25);
            this.cb_iberia.Name = "cb_iberia";
            this.cb_iberia.Size = new System.Drawing.Size(99, 52);
            this.cb_iberia.TabIndex = 0;
            this.cb_iberia.UseVisualStyleBackColor = true;
            // 
            // nud_adultos
            // 
            this.nud_adultos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_adultos.Location = new System.Drawing.Point(575, 38);
            this.nud_adultos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_adultos.Name = "nud_adultos";
            this.nud_adultos.Size = new System.Drawing.Size(52, 26);
            this.nud_adultos.TabIndex = 13;
            this.nud_adultos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_adultos.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(509, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Adultos";
            // 
            // cb_extra
            // 
            this.cb_extra.AutoSize = true;
            this.cb_extra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_extra.Location = new System.Drawing.Point(792, 40);
            this.cb_extra.Name = "cb_extra";
            this.cb_extra.Size = new System.Drawing.Size(117, 24);
            this.cb_extra.TabIndex = 15;
            this.cb_extra.Text = "Maleta Extra";
            this.cb_extra.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(652, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Niños";
            // 
            // nud_ninyos
            // 
            this.nud_ninyos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_ninyos.Location = new System.Drawing.Point(718, 38);
            this.nud_ninyos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_ninyos.Name = "nud_ninyos";
            this.nud_ninyos.Size = new System.Drawing.Size(52, 26);
            this.nud_ninyos.TabIndex = 16;
            this.nud_ninyos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_reserva
            // 
            this.gb_reserva.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gb_reserva.Controls.Add(this.button1);
            this.gb_reserva.Controls.Add(this.lb_vuelo);
            this.gb_reserva.Controls.Add(this.label6);
            this.gb_reserva.Controls.Add(this.nud_ninyos);
            this.gb_reserva.Controls.Add(this.cb_extra);
            this.gb_reserva.Controls.Add(this.label5);
            this.gb_reserva.Controls.Add(this.nud_adultos);
            this.gb_reserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_reserva.Location = new System.Drawing.Point(48, 528);
            this.gb_reserva.Name = "gb_reserva";
            this.gb_reserva.Size = new System.Drawing.Size(1114, 90);
            this.gb_reserva.TabIndex = 18;
            this.gb_reserva.TabStop = false;
            this.gb_reserva.Text = "RESERVA";
            this.gb_reserva.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(939, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 49);
            this.button1.TabIndex = 19;
            this.button1.Text = "RESERVAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lb_vuelo
            // 
            this.lb_vuelo.Location = new System.Drawing.Point(19, 22);
            this.lb_vuelo.Name = "lb_vuelo";
            this.lb_vuelo.Size = new System.Drawing.Size(463, 56);
            this.lb_vuelo.TabIndex = 18;
            this.lb_vuelo.Text = "-";
            this.lb_vuelo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 631);
            this.Controls.Add(this.gb_reserva);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bt_buscar);
            this.Controls.Add(this.lista);
            this.MinimumSize = new System.Drawing.Size(1320, 670);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_adultos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ninyos)).EndInit();
            this.gb_reserva.ResumeLayout(false);
            this.gb_reserva.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lista;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.DateTimePicker dtp_desde;
        private System.Windows.Forms.Button bt_buscar;
        private System.Windows.Forms.DateTimePicker dtp_hasta;
        private System.Windows.Forms.ComboBox cb_salida;
        private System.Windows.Forms.ComboBox cb_llegada;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cb_ryanair;
        private System.Windows.Forms.CheckBox cb_qatar;
        private System.Windows.Forms.CheckBox cb_aeuropa;
        private System.Windows.Forms.CheckBox cb_easy;
        private System.Windows.Forms.CheckBox cb_iberia;
        private System.Windows.Forms.CheckBox cb_vueling;
        private System.Windows.Forms.NumericUpDown nud_adultos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox cb_extra;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud_ninyos;
        private System.Windows.Forms.GroupBox gb_reserva;
        private System.Windows.Forms.Label lb_vuelo;
        private System.Windows.Forms.Button button1;
    }
}

