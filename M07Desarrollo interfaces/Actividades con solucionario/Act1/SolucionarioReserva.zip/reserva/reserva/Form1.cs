﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vuelos;
namespace reserva
{
    public partial class Form1 : Form
    {

        List<Vuelo> vuelos = new List<Vuelo>();
        List<Aeropuerto> aero = new List<Aeropuerto>();
        List<Aerolinea> lineas = new List<Aerolinea>();

        List<String> logos = new List<String>();
        CheckBox[] compa;
        public Form1()
        {
            InitializeComponent();
            setup();
            mostrar_vuelos();
        }
        private void mostrar_vuelos()
        {
            gb_reserva.Visible = false;
            lista.Items.Clear();
            foreach (Vuelo v in vuelos)
            {
                if (!filtrado(v)) continue;
                ListViewItem elem = lista.Items.Add("  " + v.Numero.ToString());
                elem.ImageIndex = logos.IndexOf(v.Aerolinea.Nombre);
                elem.SubItems.Add(v.Origen.Nombre);
                elem.SubItems.Add(v.Destino.Nombre);
                elem.SubItems.Add(v.Fecha.Date.ToShortDateString());
                elem.SubItems.Add(v.Fecha.ToShortTimeString());
            }
        }
        private bool filtrado(Vuelo v)
        {
            if (v.Fecha < dtp_desde.Value && dtp_desde.Checked) return false;
            if (v.Fecha > dtp_hasta.Value && dtp_hasta.Checked) return false;
            if (cb_salida.SelectedIndex!=0 && v.Origen.Nombre!=cb_salida.SelectedItem.ToString()) return false;
            if (cb_llegada.SelectedIndex != 0 && v.Destino.Nombre != cb_llegada.SelectedItem.ToString()) return false;
            if (!compa[logos.IndexOf(v.Aerolinea.Nombre)].Checked) return false;
            return true;
        }
        private void setup()
        {
            logos.Add("Air Europa");
            logos.Add("EasyJet");
            logos.Add("Iberia");
            logos.Add("Qatar Airways");
            logos.Add("Ryanair");
            logos.Add("Vueling");
            compa = new CheckBox[] { cb_aeuropa, cb_easy, cb_iberia, cb_qatar, cb_ryanair, cb_vueling };
            //createDB();
            aero = Aeropuerto.importar("aeropuertos.dat");
            lineas = Aerolinea.importar("aerolineas.dat");
            //crearVuelos();
            vuelos = Vuelo.importar("vuelos.dat");
            cb_salida.Items.Add("Todos");
            cb_llegada.Items.Add("Todos");
            foreach (Aeropuerto a in aero)
            {
                cb_salida.Items.Add(a.Nombre);
                cb_llegada.Items.Add(a.Nombre);
            }
            cb_salida.SelectedIndex = 0;
            cb_llegada.SelectedIndex = 0;
        }
        public void crearVuelos()
        {
            Vuelo v;
            List<Aeropuerto> bases= new List<Aeropuerto>();
            bases.Add(aero[6]);
            bases.Add(aero[7]);
            bases.Add(aero[16]);
            bases.Add(aero[24]);
            bases.Add(aero[25]);
            Random r = new Random();
            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 100; i++)
                {
                    int destino = r.Next(41);
                    if (aero[destino] == bases[j])
                    {
                        i--;
                        continue;
                    }
                    int linea = r.Next(6);
                    String cod = lineas[linea].Codigo + r.Next(10) + r.Next(10) + r.Next(10) + r.Next(10);
                    DateTime dia = new DateTime(2021, 10, 4+(i%10), r.Next(7, 23), r.Next(12) * 5, 0);
                    v = new Vuelo(cod, bases[j], aero[destino], dia, lineas[linea]);
                    v.exportar("vuelos.dat");
                    cod = lineas[linea].Codigo + r.Next(10) + r.Next(10) + r.Next(10) + r.Next(10);
                    dia = new DateTime(2021, 10, 11 + (i % 10), r.Next(7, 23), r.Next(12) * 5, 0); ;
                    v = new Vuelo(cod, aero[destino], bases[j], dia, lineas[linea]);
                    v.exportar("vuelos.dat");
                }
            }
        }
        public void createDB()
        {
            aero.Add(new Aeropuerto("A Coruña", "LCG", true));
            aero.Add(new Aeropuerto("Albacete", "ABC", true));
            aero.Add(new Aeropuerto("Alicante-Elche", "ALC", true));
            aero.Add(new Aeropuerto("Almería", "LEI", true));
            aero.Add(new Aeropuerto("Asturias", "OVD", true));
            aero.Add(new Aeropuerto("Badajoz", "BJZ", true));
            aero.Add(new Aeropuerto("Barcelona-El Prat", "BCN", true));
            aero.Add(new Aeropuerto("Bilbao", "BIO", true));
            aero.Add(new Aeropuerto("Burgos", "RGS", true));
            aero.Add(new Aeropuerto("Córdoba", "ODB", true));
            aero.Add(new Aeropuerto("Girona-Costa Brava", "GRO", true));
            aero.Add(new Aeropuerto("Gran Canaria", "LPA", true));
            aero.Add(new Aeropuerto("Granada-Jaen", "GRX", true));
            aero.Add(new Aeropuerto("Ibiza", "IBZ", true));
            aero.Add(new Aeropuerto("León", "LEN", true));
            aero.Add(new Aeropuerto("Logroño", "RJL", true));
            aero.Add(new Aeropuerto("Madrid-Barajas", "MAD", true));
            aero.Add(new Aeropuerto("Málaga-Costa del Sol", "AGP", true));
            aero.Add(new Aeropuerto("Menorca", "MAH", true));
            aero.Add(new Aeropuerto("Palma de Mallorca", "PMI", true));
            aero.Add(new Aeropuerto("Pamplona", "PNA", true));
            aero.Add(new Aeropuerto("Salamanca", "SLM", true));
            aero.Add(new Aeropuerto("San Sebastián", "EAS", true));
            aero.Add(new Aeropuerto("Santander", "SDR", true));
            aero.Add(new Aeropuerto("Sevilla", "SVQ", true));
            aero.Add(new Aeropuerto("Valencia", "VLC", true));
            aero.Add(new Aeropuerto("Valladolid", "VLL", true));
            aero.Add(new Aeropuerto("Vigo", "VGO", true));
            aero.Add(new Aeropuerto("Vitoria", "VIT", true));
            aero.Add(new Aeropuerto("Zaragoza", "ZAZ", true));
            aero.Add(new Aeropuerto("Frankfurt", "FRA", false));
            aero.Add(new Aeropuerto("Paris-Charles de Gaulle", "CDG", false));
            aero.Add(new Aeropuerto("Roma-Fiumicino", "FCO", false));
            aero.Add(new Aeropuerto("Amsterdam", "AMS", false));
            aero.Add(new Aeropuerto("Londres-Heathrow", "LHR", false));
            aero.Add(new Aeropuerto("Londres-Gatwick", "LGW", false));
            aero.Add(new Aeropuerto("Los Angeles", "LAX", false));
            aero.Add(new Aeropuerto("Miami", "MIA", false));
            aero.Add(new Aeropuerto("Chicago-O'Hare", "ORD", false));
            aero.Add(new Aeropuerto("Nueva York-JFK", "JFK", false));
            aero.Add(new Aeropuerto("Dallas/Fort Worth", "DFW", false));
            aero.Add(new Aeropuerto("Washington D.C.-Dulles", "IAD", false));
            foreach (Aeropuerto a in aero) a.exportar("aeropuertos.dat");

            lineas.Add(new Aerolinea("Iberia", "IBE", reserva.Properties.Resources.iberia));
            lineas.Add(new Aerolinea("Vueling", "VY", reserva.Properties.Resources.vueling));
            lineas.Add(new Aerolinea("Qatar Airways", "QTR", reserva.Properties.Resources.qatar));
            lineas.Add(new Aerolinea("EasyJet", "EZS", reserva.Properties.Resources.easyjet));
            lineas.Add(new Aerolinea("Ryanair", "FR", reserva.Properties.Resources.Ryanair));
            lineas.Add(new Aerolinea("Air Europa", "UX", reserva.Properties.Resources.aireuropa));
            foreach (Aerolinea a in lineas) a.exportar("aerolineas.dat");



        }
        private void button1_Click(object sender, EventArgs e)
        {
            mostrar_vuelos();
        }
        private void dtp_desde_ValueChanged(object sender, EventArgs e)
        {
            DateTime fecha = new DateTime(dtp_desde.Value.Year,
                dtp_desde.Value.Month,
                dtp_desde.Value.Day);
            dtp_desde.Value = fecha;
        }
        private void dtp_hasta_ValueChanged(object sender, EventArgs e)
        {
            DateTime fecha = new DateTime(dtp_hasta.Value.Year,
                dtp_hasta.Value.Month,
                dtp_hasta.Value.Day,23,59,0);
            dtp_hasta.Value = fecha;
        }
        private void lista_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            gb_reserva.Visible = true;
            String texto=lb_vuelo.Text = lista.SelectedItems[0].Text;
            texto += "     "+lista.SelectedItems[0].SubItems[1].Text;
            texto += " ->  " + lista.SelectedItems[0].SubItems[2].Text;
            texto += "\n";
            texto += "                      " + lista.SelectedItems[0].SubItems[3].Text;
            texto += "    " + lista.SelectedItems[0].SubItems[4].Text;
            lb_vuelo.Text = texto;
        }
        private void lista_MouseClick(object sender, MouseEventArgs e)
        {
            gb_reserva.Visible = false;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Reserva r = null;
            if ((int)nud_adultos.Value + nud_ninyos.Value < 1) return;
            foreach (Vuelo v in vuelos)
                if (lista.SelectedItems[0].Text.TrimStart() == v.Numero)
                {
                    r = new Reserva(v,(int)nud_adultos.Value,(int)nud_ninyos.Value,cb_extra.Checked);
                }
            r.confirmar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
