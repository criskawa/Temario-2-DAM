﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Backup
{
    public partial class Form1 : Form
    {
        List<TabPage> tabs = new List<TabPage>();
        bool planificado = false;
        public Form1()
        {
            InitializeComponent();
            Bitmap b = new Bitmap(Backup.Properties.Resources.start_png_44883, new Size(80, 80));
            btStart.Image = b;
            incializa();
        }

        #region "Funciones"
        private void incializa()
        {
            limpiar_lista();
            foreach (TabPage tp in tabControl1.TabPages) desactivar_prog(tp);
            dateTimePicker1.MinDate = DateTime.Now;
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
            comboBox5.SelectedIndex = 0;
            tbDestino.Text = "C:\\";
            comprobar_espacio();
            btAddDiary.Tag = new Control[] { lvDiario, dateTimePicker3, comboBox1 };
            btWeekly.Tag = new Control[] { lvWeekly, comboBox3, dateTimePicker4, comboBox2 };
            btMonthly.Tag = new Control[] { lvMonthly, numericUpDown1, dateTimePicker5, comboBox5 };
        }
        private String format_tamanyo(long tam)
        {
            String[] unidades = new string[] { " B", " KB", " MB", " GB", " TB" };
            int unidad = 0;
            double tamd = tam;
            while (tamd > 1024)
            {
                tamd /= 1024;
                unidad++;
            }
            return String.Format("{0,0:G4}", tamd) + unidades[unidad];
        }
        private String calcular_tamanyo()
        {
            long tam = 0;
            foreach (ListViewItem it in lvLista.Items)
            {

                tam += Convert.ToInt64(it.SubItems[2].Text);
            }
            return format_tamanyo(tam);
        }
        public long tamanyo_carpeta(DirectoryInfo d)
        {
            long tam = 0;
            FileInfo[] infos = d.GetFiles();
            foreach (FileInfo info in infos)
            {
                tam += info.Length;
            }
            // explorar subcarpetas
            DirectoryInfo[] dirinfos = d.GetDirectories();
            foreach (DirectoryInfo dirinfo in dirinfos)
            {
                tam += tamanyo_carpeta(dirinfo);
            }
            return tam;
        }
        private void actualizar_lista()
        {
            for (int i = 0; i < lvLista.Columns.Count; i++)
                lvLista.Columns[i].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
            lbTam.Text = "Total: " + calcular_tamanyo();
        }
        private void limpiar_lista()
        {
            lvLista.Items.Clear();
            for (int i = 0; i < lvLista.Columns.Count; i++)
                lvLista.Columns[i].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            lbTam.Text = "Total: " + calcular_tamanyo();
        }
        private void activar_prog(TabPage tp)
        {
            foreach (Control c in tp.Controls)
            {
                c.Visible = true;
                if (c.GetType().Name.Equals("PictureBox"))
                {
                    ((PictureBox)c).Image = Backup.Properties.Resources.trash;
                    c.Tag = true;
                }

            }
            tabs.Clear();
            foreach (TabPage tab in tabControl1.TabPages)
            {
                if (!tab.Equals(tp))
                {
                    tabs.Add(tab);
                    tabControl1.TabPages.Remove(tab);
                }
            }
        }
        private void desactivar_prog(TabPage tp)
        {
            foreach (Control c in tp.Controls)
            {
                c.Visible = false;
                if (c.GetType().Name.Equals("PictureBox"))
                {
                    ((PictureBox)c).Image = Backup.Properties.Resources.edit;
                    c.Tag = false;
                    c.Visible = true;
                }
                if (c.GetType().Name.Equals("ListView"))
                {
                    ((ListView)c).Items.Clear();
                }
            }
            foreach (TabPage tab in tabs) tabControl1.TabPages.Add(tab);
            tabs.Clear();
            planificado = false;
        }
        private void agregar_Elemento(Control[] controles)
        {
            ListViewItem elem;
            ListView lv = (ListView)controles[0];
            String[] datos = new string[controles.Length - 1];
            for (int i = 0; i < datos.Length; i++)
            {
                switch (controles[i + 1].GetType().Name)
                {
                    case "ComboBox":
                        datos[i] = ((ComboBox)controles[i + 1]).SelectedItem.ToString();
                        break;
                    case "DateTimePicker":
                        datos[i] = ((DateTimePicker)controles[i + 1]).Value.ToShortTimeString();
                        break;
                    case "NumericUpDown":
                        datos[i] = ((NumericUpDown)controles[i + 1]).Value.ToString();
                        break;
                }
            }
            elem = lv.Items.Add(datos[0]);
            for (int i = 1; i < datos.Length; i++) elem.SubItems.Add(datos[i]);
        }
        private void comprobar_espacio()
        {
            DriveInfo Info = new DriveInfo(tbDestino.Text);
            long tam = 0;
            foreach (ListViewItem it in lvLista.Items)
            {

                tam += Convert.ToInt64(it.SubItems[2].Text);
            }
            lbSpace.ForeColor = Color.Green;
            if (tam>Info.TotalFreeSpace)
            {
                MessageBox.Show("Espacio en disco Insuficiente!",
                    "ESPACIO INSUFICIENTE",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                lbSpace.ForeColor = Color.Red;
            }
            lbSpace.Text = "Espacio Disponible: "+format_tamanyo(Info.TotalFreeSpace);
        }
        private void emitir_aviso(String msg)
        {
            MessageBox.Show(msg, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        private bool start_backup()
        {
            if (lvLista.Items.Count == 0)
            {
                emitir_aviso("No hay ningun elemento elegido");
                return false;
            }
            if (lbSpace.ForeColor == Color.Red)
            {
                emitir_aviso("Espacio de disco insuficiente");
                return false;
            }
            if (!planificado)
            {
                emitir_aviso("Debes especificar una planificación");
                return false;
            }
            MessageBox.Show("Copia de seguridad planificada con exito",
                "COPIA PLANIFICADA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return true;
        }
        #endregion
        #region "Interaccion"    
        private void btFicheros_Click(object sender, EventArgs e)
        {
            ListViewItem elem;
            FileInfo info;
            if (dlgFicheros.ShowDialog() == DialogResult.OK)
            {
                foreach (String fichero in dlgFicheros.FileNames)
                {
                    info = new FileInfo(fichero);
                    elem = new ListViewItem(info.Name);
                    elem.ImageIndex = 1;
                    elem.SubItems.Add(info.DirectoryName);
                    elem.SubItems.Add(info.Length.ToString());
                    lvLista.Items.Add(elem);
                }
                actualizar_lista();
                comprobar_espacio();
            }
        }
        private void btCarpetas_click(object sender, EventArgs e)
        {
            ListViewItem elem;
            DirectoryInfo info;
            if (dlgCarpeta.ShowDialog() == DialogResult.OK)
            {
                info = new DirectoryInfo(dlgCarpeta.SelectedPath);
                elem = new ListViewItem(info.Name);
                elem.ImageIndex = 0;
                elem.SubItems.Add(info.Parent.FullName);
                elem.SubItems.Add(tamanyo_carpeta(info).ToString());
                lvLista.Items.Add(elem);
                actualizar_lista();
            }
            comprobar_espacio();
        }
        private void activar_click(object sender, EventArgs e)
        {
            PictureBox pb = (PictureBox)sender;
            Boolean activa = (Boolean)pb.Tag;
            if (pb.Name.Equals("pbOnce")) planificado = true;
            if (!activa) activar_prog(tabControl1.SelectedTab);
            else desactivar_prog(tabControl1.SelectedTab);  
        }
        private void addprog_click(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            Control[] cs = (Control[])bt.Tag;
            agregar_Elemento(cs);
            planificado = true;
        }
        private void delProg_click(object sender, EventArgs e)
        {
            ListView lv = (ListView)sender;
            if (lv.SelectedItems.Count != 1) return;
            lv.Items.Remove(lv.SelectedItems[0]);
            if (lv.Items.Count == 0) planificado = false;
        }        
        private void btDestino_Click(object sender, EventArgs e)
        {
            if (dlgCarpeta.ShowDialog() == DialogResult.OK)
            {
                tbDestino.Text = dlgCarpeta.SelectedPath;
                comprobar_espacio();
    
            }
        }
        private void delItem_clic(object sender, EventArgs e)
        {   
            if (lvLista.SelectedItems.Count != 1) return;
            lvLista.Items.Remove(lvLista.SelectedItems[0]);
            actualizar_lista();
            comprobar_espacio();
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            panel1.Enabled = radioButton2.Checked;
        }
        private void btStart_Click(object sender, EventArgs e)
        {
            start_backup();
        }
        #endregion
        #region "Menu"
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            incializa();
        }
        private void limpiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            limpiar_lista();
        }
        private void uncheck_progs()
        {
            unaVezToolStripMenuItem.Checked = false;
            diariaToolStripMenuItem.Checked = false;
            semanalToolStripMenuItem.Checked = false;
            mensualToolStripMenuItem.Checked = false;
            foreach (TabPage tp in tabControl1.TabPages) desactivar_prog(tp);
        }
        private void unaVezToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uncheck_progs();
            tabControl1.SelectedTab = (TabPage)pbOnce.Parent;
            activar_click(pbOnce, e);
            ((ToolStripMenuItem)sender).Checked = true;
        }
        private void diariaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uncheck_progs();
            tabControl1.SelectedTab = (TabPage)pbDiary.Parent;
            activar_click(pbDiary, e);
            ((ToolStripMenuItem)sender).Checked = true;
        }
        private void semanalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uncheck_progs();
            tabControl1.SelectedTab = (TabPage)pbWeekly.Parent;
            activar_click(pbWeekly, e);
            ((ToolStripMenuItem)sender).Checked = true;
        }
        private void mensualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uncheck_progs();
            tabControl1.SelectedTab = (TabPage)pbMonthly.Parent;
            activar_click(pbMonthly, e);
            ((ToolStripMenuItem)sender).Checked = true;
        }
        private void resetearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uncheck_progs();
        }
        private void iniciarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            start_backup();
        }       
        #endregion


    }
}
