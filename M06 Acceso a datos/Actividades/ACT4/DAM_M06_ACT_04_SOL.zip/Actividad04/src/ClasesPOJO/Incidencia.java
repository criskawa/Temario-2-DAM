package ClasesPOJO;

// Creamos la clase POJO Incidencia
public class Incidencia {

    // Creamos las variables de la clase Incidencia
    private int idincidencia;
    private String empleadoByOrigen;
    private String empleadoByDestino;
    private String fechahora;
    private String detalle;
    private String tipo;

    // Generamos el constructor de la clase Incidencia
    public Incidencia() {
    }

    public Incidencia(String empleadoByDestino) {
        this.empleadoByDestino = empleadoByDestino;
    }

    
    public Incidencia(int idincidencia, String empleadoByOrigen, String empleadoByDestino, String fechahora, String detalle, String tipo) {
        this.idincidencia = idincidencia;
        this.empleadoByOrigen = empleadoByOrigen;
        this.empleadoByDestino = empleadoByDestino;
        this.fechahora = fechahora;
        this.detalle = detalle;
        this.tipo = tipo;
    }

    // Generamos getters y setters de la clase Incidencia
    public int getIdincidencia() {
        return this.idincidencia;
    }

    public void setIdincidencia(int idincidencia) {
        this.idincidencia = idincidencia;
    }

    public String getEmpleadoByOrigen() {
        return this.empleadoByOrigen;
    }

    public void setEmpleadoByOrigen(String empleadoByOrigen) {
        this.empleadoByOrigen = empleadoByOrigen;
    }

    public String getEmpleadoByDestino() {
        return this.empleadoByDestino;
    }

    public void setEmpleadoByDestino(String empleadoByDestino) {
        this.empleadoByDestino = empleadoByDestino;
    }

    public String getFechahora() {
        return this.fechahora;
    }

    public void setFechahora(String fechahora) {
        this.fechahora = fechahora;
    }

    public String getDetalle() {
        return this.detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Incidencia:" + "\n"
                + "ID:" + +idincidencia + "\n"
                + "Fecha y hora: " + fechahora + "\n"
                + "Usuario de origen: " + empleadoByOrigen+ "\n"
                + "Usuario de destino: " + empleadoByDestino + "\n"
                + "Detalle: " + detalle + "\n"
                + "Tipo de prioridad: " + tipo + "\n";
    }

}
