package ClasesPOJO;

// Creamos la clase POJO Historial
public class Historial {

    // Creamos las variables de la clase Historial
    private Integer idevento;
    private String empleado;
    private String tipo;
    private String fechahora;

    // Generamos el constructor de la clase Historial
    public Historial() {
    }

    public Historial(String empleado, String tipo, String fechahora) {
        this.empleado = empleado;
        this.tipo = tipo;
        this.fechahora = fechahora;
    }

    // Generamos getters y setters de la clase Historial
    public Integer getIdevento() {
        return this.idevento;
    }

    public void setIdevento(Integer idevento) {
        this.idevento = idevento;
    }

    public String getEmpleado() {
        return this.empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFechahora() {
        return this.fechahora;
    }

    public void setFechahora(String fechahora) {
        this.fechahora = fechahora;
    }

    @Override
    public String toString() {
        return "Historial:" + "\n"
                + "ID del evento:" + idevento + "\n"
                + "Tipo de incidencia: " + tipo + "\n"
                + "Fecha y hora: " + fechahora + "\n"
                + "Empleado: " + empleado + "\n";
    }
}
