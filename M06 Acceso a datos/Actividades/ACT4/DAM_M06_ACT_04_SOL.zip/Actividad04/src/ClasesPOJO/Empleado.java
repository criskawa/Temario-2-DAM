package ClasesPOJO;


// Creamos la clase POJO Empleado
public class Empleado {

    // Creamos las variables de la clase Empleado
    private String nombreusuario;
    private String password;
    private String nombrecompleto;
    private String telefono;
    public int incidenciasUrgentes;

    // Generamos el constructor de la clase Empleado
    public Empleado() {
    }
    
    public Empleado(String nombreusuario) {
        this.nombreusuario = nombreusuario;
    }
    
    public Empleado(String nombreusuario, String password, String nombrecompleto, String telefono) {
        this.nombreusuario = nombreusuario;
        this.password = password;
        this.nombrecompleto = nombrecompleto;
        this.telefono = telefono;
    }

    public Empleado(String nombreusuario, String password, String nombrecompleto, String telefono, int incidenciasUrgentes) {
        this.nombreusuario = nombreusuario;
        this.password = password;
        this.nombrecompleto = nombrecompleto;
        this.telefono = telefono;
        this.incidenciasUrgentes = incidenciasUrgentes;
    }

    // Generamos getters y setters de la clase Empleado
    public String getNombreusuario() {
        return this.nombreusuario;
    }

    public void setNombreusuario(String nombreusuario) {
        this.nombreusuario = nombreusuario;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombrecompleto() {
        return this.nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getIncidenciasUrgentes() {
        return incidenciasUrgentes;
    }

    public void setIncidenciasUrgentes(int incidenciasUrgentes) {
        this.incidenciasUrgentes = incidenciasUrgentes;
    }

    @Override
    public String toString() {
        return "Usuario: " + nombreusuario + "\n"
                + "Contrase�a " + password + "\n"
                + "Nombre: " + nombrecompleto + "\n"
                + "Telefono: " + telefono + "\n"
                + "Incidencias urgentes: " + incidenciasUrgentes + "\n";
    }
    
}
