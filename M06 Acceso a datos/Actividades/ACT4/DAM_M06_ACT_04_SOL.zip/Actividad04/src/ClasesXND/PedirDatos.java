package ClasesXND;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

//Clase PedirDatos
public class PedirDatos {

    //Función que pide al usuario un número entero por pantalla
    public static Integer pideEntero(String pregunta) {
        System.out.println(pregunta);
        Scanner scanner = new Scanner(System.in);
        int entrada = 100;
        do {
            try {
                entrada = scanner.nextInt();
            } catch (Exception e) {
                System.out.println("No has introducido un número entero. Prueba de nuevo");
                scanner.next();
            }
        } while (entrada == 100);
        return entrada;
    }

    //Función que pide al usuario un String por pantalla
    public static String pideString(String txt) {
        System.out.println(txt);
        boolean repeat;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        do {
            repeat = false;
            try {
                return br.readLine();
            } catch (IOException ex) {
                repeat = true;
            }
        } while (repeat);
        return null;
    }

    //Función que pide al usuario un número double por pantalla
    public static Double pideDouble(String pregunta) {
        System.out.println(pregunta);
        Scanner scanner = new Scanner(System.in);
        double entrada = 100.0;
        do {
            try {
                entrada = scanner.nextDouble();
            } catch (Exception e) {
                System.out.println("No has introducido un número double. Prueba de nuevo");
                scanner.next();
            }
        } while (entrada == 100.0);
        return entrada;
    }
}
