package ClasesXND;

import ClasesPOJO.Incidencia;
import static ClasesXND.GestionXND.hacerConsulta;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XMLResource;

public class IncidenciasXND {

    // Funcion que obtiene una incidencia a partir de su ID
    public static Incidencia obtenerIncidenciaSegunId() throws XMLDBException {
        Incidencia i = new Incidencia();
        int id = PedirDatos.pideEntero("Introduzca el id de la incidencia que desea obtener:");
        String consulta = "for $id in doc('incidencias.xml')//incidencias/incidencia where $id/id='" + id + "' return $id/*/text()";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        while (it.hasMoreResources()) {
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosIncidencia = hijo.item(0).getChildNodes();
            i = leerDom(datosIncidencia);

        }
        return i;
    }

    // Funcion que imprime un listado de todas las incidencias
    public static List<Incidencia> listarIncidencias() throws XMLDBException {
        System.out.println("---INCIDENCIAS EXISTENTES---");
        String consulta = "for $incidencia in doc('incidencias.xml')//incidencias/incidencia/*/text() return $incidencia";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        List<Incidencia> listaIncidencias = new ArrayList<>();
        while (it.hasMoreResources()) {
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosIncidencia = hijo.item(0).getChildNodes();
            Incidencia i = leerDom(datosIncidencia);
            listaIncidencias.add(i);
        }
        return listaIncidencias;
    }

    //Funcion que inserta una nueva incidencia
    public static void insertarIncidencias() throws XMLDBException {
        //Pedimos los datos de la nueva incidencia
        String usuarioOrigen = PedirDatos.pideString("Inserte el nombre de usuario de origen");
        String usuarioDestino = PedirDatos.pideString("Inserte el nombre de usuario de destino");
        String detalles = PedirDatos.pideString("Inserte los detalles de la incidencia");
        String tipo = PedirDatos.pideString("Indique si la incidencia es Normal o Urgente");
        String fechaHora = PedirDatos.pideString("Introduzca la fecha y hora con el siguiente formato: yyyy/MM/dd HH:mm:ss");
        List<Incidencia> listaIncidencias = listarIncidencias();
        int ultimoID = listaIncidencias.size();
        int idincidencia = ultimoID + 1;
        if (usuarioOrigen.isEmpty() || usuarioDestino.isEmpty() || detalles.isEmpty() || tipo.isEmpty() || fechaHora.isEmpty()) {
            System.out.println("Debe introducir todos los campos que se solicitan");
        } else {
            if (!tipo.equalsIgnoreCase("Normal") && !tipo.equalsIgnoreCase("Urgente")) {
                System.out.println("Debe indicar si la incidencia es de tipo Normal o Urgente");
            } else {
                String consulta = "update insert <incidencia> <id>" + idincidencia + "</id>"
                        + "<origen>" + usuarioOrigen + "</origen>"
                        + "<destino>" + usuarioDestino + "</destino>"
                        + "<tipo>" + tipo + "</tipo>"
                        + "<detalle>" + detalles + "</detalle>"
                        + "<fechahora>" + fechaHora + "</fechahora> </incidencia> into /incidencias";
                hacerConsulta(consulta);
                if (tipo.equalsIgnoreCase("Urgente")) {
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                    String format = dtf.format(LocalDateTime.now());
                    String nuevoHistorial = "update insert <historial> <tipo>U</tipo>"
                            + "<fechahora>" + format + "</fechahora>"
                            + "<empleado>" + usuarioOrigen + "</empleado></historial> into /historiales";
                    hacerConsulta(nuevoHistorial);
                }
                System.out.println("Nueva incidencia a�adida!!");
            }
        }
    }

    //Funcion que imprime por pantalla las incidencias cuyo destinatario es el usuario pedido por pantalla
    public static List<Incidencia> incidenciasDestino() throws XMLDBException {
        String usuario = PedirDatos.pideString("Inserte el nombre de usuario de destino");
        String consulta = "for $incidencia in doc('incidencias.xml')//incidencias/incidencia where $incidencia/destino='" + usuario + "' return $incidencia/*/text()";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        List<Incidencia> listaIncidencias = new ArrayList<>();
        while (it.hasMoreResources()) {
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosIncidencia = hijo.item(0).getChildNodes();
            Incidencia i = leerDom(datosIncidencia);
            listaIncidencias.add(i);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            String format = dtf.format(LocalDateTime.now());
            String nuevoHistorial = "update insert <historial> <tipo>C</tipo>"
                    + "<fechahora>" + format + "</fechahora>"
                    + "<empleado>" + usuario + "</empleado></historial> into /historiales";
            hacerConsulta(nuevoHistorial);
        }
        return listaIncidencias;
    }

    //Funcion que imprime por pantalla las incidencias cuyo origen es el usuario pedido por pantalla
    public static List<Incidencia> incidenciasOrigen() throws XMLDBException {
        String usuario = PedirDatos.pideString("Inserte el nombre de usuario de origen");
        String consulta = "for $incidencia in doc('incidencias.xml')//incidencias/incidencia where $incidencia/origen='" + usuario + "' return $incidencia/*/text()";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        List<Incidencia> listaIncidencias = new ArrayList<>();
        while (it.hasMoreResources()) {
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosIncidencia = hijo.item(0).getChildNodes();
            Incidencia i = leerDom(datosIncidencia);
            listaIncidencias.add(i);
        }
        return listaIncidencias;
    }

    // Funcion para leer el DOM
    public static Incidencia leerDom(NodeList datos) {
        int contador = 1;
        Incidencia incidencia = new Incidencia();
        for (int i = 0; i < datos.getLength(); i++) {
            Node ntemp = datos.item(i);
            if (ntemp.getNodeType() == Node.ELEMENT_NODE) {
                switch (contador) {
                    case 1:
                        incidencia.setIdincidencia(Integer.parseInt(ntemp.getChildNodes().item(0).getNodeValue()));
                        contador++;
                        break;
                    case 2:
                        incidencia.setEmpleadoByOrigen(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 3:
                        incidencia.setEmpleadoByDestino(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 4:
                        incidencia.setTipo(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 5:
                        incidencia.setDetalle(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 6:
                        incidencia.setFechahora(ntemp.getChildNodes().item(0).getNodeValue());
                }
            }
        }
        return incidencia;
    }


}
