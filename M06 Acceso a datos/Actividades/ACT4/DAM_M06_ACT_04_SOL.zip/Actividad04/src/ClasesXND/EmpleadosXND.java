package ClasesXND;

import ClasesPOJO.Empleado;
import static ClasesXND.GestionXND.hacerConsulta;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.XMLResource;

public class EmpleadosXND {    

    // Funci�n que inserta un nuevo empleado
    public static void a�adirEmpleado() throws XMLDBException {
        String usuario = PedirDatos.pideString("Introduzca el nombre de usuario");
        String contrase�a = PedirDatos.pideString("Introduzca la contrase�a");
        String nombre = PedirDatos.pideString("Introduzca el nombre completo");
        String telefono = PedirDatos.pideString("Introduzca el telefono");
        String query = "update insert <empleado> <usuario>" + usuario + "</usuario>"
                + "<contrase�a>" + contrase�a + "</contrase�a>"
                + "<nombre>" + nombre + "</nombre>"
                + "<telefono>" + telefono + "</telefono></empleado> into /empleados";
        if (usuario.isEmpty() || contrase�a.isEmpty() || nombre.isEmpty() || telefono.isEmpty()) {
            System.out.println("Debe introducir todos los datos solicitados");
        } else {
            hacerConsulta(query);
            System.out.println("Nuevo empleado a�adido");
        }

    }

    // Funci�n que valida la entrada de un empleado pidiendo por pantalla su usuario y contrase�a
    public static void validarEmpleado() throws XMLDBException {
        System.out.println("-----LOGIN-----");
        boolean login = false;
        while (login == false) {
            String usuario = PedirDatos.pideString("Introduzca el nombre de usuario del empleado a validar");
            String contrase�a = PedirDatos.pideString("Introduzca la contrase�a del empleado");
            String consulta = "for $empleado in doc('empleados.xml')/empleados/empleado "
                    + "where $empleado/usuario='" + usuario + "' "
                    + "and $empleado/contrase�a='" + contrase�a + "' return $empleado/contrase�a/text()";
            ResourceSet resultado = hacerConsulta(consulta);
            ResourceIterator it = resultado.getIterator();
            while (it.hasMoreResources()) {
                Resource res = it.nextResource();
                if (contrase�a.equals(res.getContent())) {
                    login = true;
                    System.out.println("Login realizado correctamente");
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                    String format = dtf.format(LocalDateTime.now());
                    String nuevoHistorial = "update insert <historial> <tipo>I</tipo>"
                            + "<fechahora>" + format + "</fechahora>"
                            + "<empleado>" + usuario + "</empleado></historial> into /historiales";
                    hacerConsulta(nuevoHistorial);
                }
                if (login == false) {
                    System.out.println("El usuario y/o la contrase�a son incorrectas");
                }
            }
        }
    }

    // Funci�n que modifica el perfil de un empleado
    public static void modificarEmpleado() throws XMLDBException {
        mostrarUsuarios();
        String usuario = PedirDatos.pideString("Introduzca el nombre de usuario del empleado que desea modificar");
        String consulta = "for $usuario in doc('empleados.xml')//empleados/empleado/usuario/text() return $usuario";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        while (it.hasMoreResources()) {
            Resource res = it.nextResource();
            if (usuario.equals(res.getContent())) {
                mostrarDatos(usuario);
                String nuevoUsuario = PedirDatos.pideString("Introduzca el nuevo nombre de usuario");
                String contrase�a = PedirDatos.pideString("Introduzca la nueva contrase�a");
                String nombre = PedirDatos.pideString("Introduzca el nuevo nombre completo");
                String telefono = PedirDatos.pideString("Introduzca el nuevo telefono");
                if (nuevoUsuario.isEmpty() || contrase�a.isEmpty() || nombre.isEmpty() || telefono.isEmpty()) {
                    System.out.println("Debe introducir todos los datos solicitados");
                } else {
                    String consultaUsuario = "update replace /empleados/empleado[usuario='" + usuario + "']/usuario with <usuario>" + nuevoUsuario + "</usuario>";
                    hacerConsulta(consultaUsuario);
                    String consultaContrase�a = "update replace /empleados/empleado[usuario='" + nuevoUsuario + "']/contrase�a with <contrase�a>" + contrase�a + "</contrase�a>";
                    hacerConsulta(consultaContrase�a);
                    String consultaNombre = "update replace /empleados/empleado[usuario='" + nuevoUsuario + "']/nombre with <nombre>" + nombre + "</nombre>";
                    hacerConsulta(consultaNombre);
                    String consultaTelefono = "update replace /empleados/empleado[usuario='" + nuevoUsuario + "']/telefono with <telefono>" + telefono + "</telefono>";
                    hacerConsulta(consultaTelefono);
                    System.out.println("Los datos actualizados del empleado son estos: ");
                    mostrarDatos(nuevoUsuario);
                }
            } else {
                System.out.println("Debe escribir correctamente el nombre de usuario!!");
            }
        }
    }

    // Funci�n que permite cambiar la contrase�a de un usuario
    public static void cambiarContrase�a() throws XMLDBException {
        mostrarUsuarios();
        String usuario = PedirDatos.pideString("Introduzca el nombre de usuario cuya contrase�a quiere modificar");
        mostrarDatos(usuario);
        String contrase�a = PedirDatos.pideString("Introduzca la nueva contrase�a");
        if (contrase�a.isEmpty()) {
            System.out.println("La contrase�a no puede estar vac�a");
        } else {
            String consultaContrase�a = "update replace /empleados/empleado[usuario='" + usuario + "']/contrase�a with <contrase�a>" + contrase�a + "</contrase�a>";
            hacerConsulta(consultaContrase�a);
            System.out.println("Los datos actualizados del empleado son estos: ");
            mostrarDatos(usuario);
        }
    }

    // Funci�n que elimina un empleado 
    public static void eliminarEmpleado() throws XMLDBException {
        mostrarUsuarios();
        String usuario = PedirDatos.pideString("Introduzca el nombre de usuario del empleado que quiere eliminar");
        String consulta = "update delete //empleados/empleado[usuario='" + usuario + "']";
        hacerConsulta(consulta);
        System.out.println("Empleado eliminado correctamente");
    }

    //Funci�n que muestra los usuarios existentes
    public static void mostrarUsuarios() throws XMLDBException {
        System.out.println("--USUARIOS EXISTENTES--");
        String consulta = "for $usuario in doc('empleados.xml')//empleados/empleado/usuario/text() return $usuario";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        while (it.hasMoreResources()) {
            Resource res = it.nextResource();
            System.out.println(res.getContent());
        }
    }

    // Funci�n que muestra los datos de un usuario
    public static Empleado mostrarDatos(String usuario) throws XMLDBException {
        Empleado e = new Empleado();
        System.out.println("---DATOS DEL EMPLEADO---");
        String consulta = "for $datos in doc('empleados.xml')//empleados/empleado let $usuario := $datos/usuario where $usuario='"
                + usuario + "' return $datos";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        while (it.hasMoreResources()) {
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosEmpleado = hijo.item(0).getChildNodes();
            e = leerDom(datosEmpleado);
        }
        return e;
    }

    // Funcion para leer el DOM
    public static Empleado leerDom(NodeList datos) {
        int contador = 1;
        Empleado e = new Empleado();
        for (int i = 0; i < datos.getLength(); i++) {
            Node ntemp = datos.item(i);
            if (ntemp.getNodeType() == Node.ELEMENT_NODE) {
                switch (contador) {
                    case 1:
                        e.setNombreusuario(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 2:
                        e.setPassword(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 3:
                        e.setNombrecompleto(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 4:
                        e.setTelefono(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                }
            }
        }
        return e;
    }

}
