package ClasesXND;

import ClasesPOJO.Historial;
import static ClasesXND.GestionXND.hacerConsulta;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XMLResource;



public class HistorialXND {


    // Funcion que obtiene un listado de todos los inicios de sesion que ha habido
    public static List<Historial> obtenerIniciosSesion() throws XMLDBException {
        String consulta = "for $historial in doc('historial.xml')//historiales/historial where $historial/tipo='I'"
                + "return $historial/*/text()";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        List<Historial> listadoHistoriales = new ArrayList<>();
        while (it.hasMoreResources()){
            XMLResource res = (XMLResource) it.nextResource();
            Node nodo = res.getContentAsDOM();
            NodeList hijo = nodo.getChildNodes();
            NodeList datosHistorial = hijo.item(0).getChildNodes();
            Historial h = leerDom(datosHistorial);
            listadoHistoriales.add(h);
        }
        return listadoHistoriales;
    }

    // Funcion que obtiene un listado de los empleados que han consultado sus incidencias
    public static void listadoConsultaDeEmpleados() throws XMLDBException {
        String consulta = "for $historial in doc('historial.xml')//historiales/historial where $historial/tipo='C'"
                + "order by $historial/empleado "
                + "return $historial/empleado/text()";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        String empleado = null;  
        while (it.hasMoreResources()){
            Resource res = it.nextResource();
            if(!empleado.equals(res.getContent().toString())){
                empleado = res.getContent().toString();
                System.out.println("Nombre de usuario del empleado: " + res.getContent());
            }
        }       
    }

    // Funcion que hace un listado del numero de incidencias que hay en la BBDD
    public static int listarIncidencias() throws XMLDBException {
        int contador = 0;
        String consulta = "for $incidencia in doc ('incidencias.xml')//incidencias/incidencia/id/text() return $incidencia";
        ResourceSet resultado = hacerConsulta(consulta);
        ResourceIterator it = resultado.getIterator();
        while (it.hasMoreResources()){
            it.nextResource();
            contador++;
        }
        return contador;
    }

    // Funcion para leer el DOM
    public static Historial leerDom(NodeList datos) {
        int contador = 1;
        Historial h = new Historial();
        for (int i = 0; i < datos.getLength(); i++) {
            Node ntemp = datos.item(i);
            if (ntemp.getNodeType() == Node.ELEMENT_NODE) {
                switch (contador) {
                    case 1:
                        h.setIdevento(Integer.parseInt(ntemp.getChildNodes().item(0).getNodeValue()));
                        contador++;
                        break;
                    case 2:
                        h.setTipo(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 3:
                        h.setFechahora(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                    case 4:
                        h.setEmpleado(ntemp.getChildNodes().item(0).getNodeValue());
                        contador++;
                        break;
                }
            }
        }
        return h;
    }

}
