package ClasesXND;

import java.io.File;
import java.util.Scanner;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.XMLDBException;

public class TestXND {

    static Collection col;
    static EmpleadosXND e = new EmpleadosXND();
    static IncidenciasXND i = new IncidenciasXND();
    static HistorialXND h = new HistorialXND();
    static GestionXND g = new GestionXND();

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, XMLDBException {
        
        col = g.conexionBBDD();
        col = g.leerColeccion("/db");
        g.crearColeccion(col, "Actividad04");
        String rutaProyecto = System.getProperty("user.dir");
        String separador = System.getProperty("file.separator");
        File incidenciaXML = new File(rutaProyecto + separador + "src" + separador + "incidencias.xml");
        File empleadoXML = new File(rutaProyecto + separador + "src" + separador + "empleados.xml");
        File historialXML = new File(rutaProyecto + separador + "src" + separador + "historial.xml");
        col = g.leerColeccion("/db/Actividad04");
        g.asignarRecurso(col, incidenciaXML);
        g.asignarRecurso(col, empleadoXML);
        g.asignarRecurso(col, historialXML);

        boolean salir = false;
        do {
            try {
                //Mostramos el menu principal con las diferentes opciones
                Integer pideEntero = menuPrincipal();
                switch (pideEntero) {
                    case 0:
                        salir = true;
                        System.out.println("Hasta pronto!!");
                        break;
                    case 1:
                        menuEmpleado();
                        break;
                    case 2:
                        menuIncidencia();
                        break;
                    case 3:
                        menuHistorial();
                        break;
                    default:
                        System.out.println("Valor introducido incorrecto. Intentalo de nuevo");
                        break;
                }
            } catch (Exception ex) {
                System.out.println("Opcion no valida");
            }
        } while (!salir);

    }

    //////////////////////////// METODOS PROPIOS \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    // Metodo que muestra el menu principal
    public static Integer menuPrincipal() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        int entrada = 100;
        do {
            try {
                System.out.println("************************************************");
                System.out.println("BIENVENID@ A LA ACTIVIDAD 2");
                System.out.println("------------------------------------");
                System.out.println("�Que menu quieres ver?");
                System.out.println("1. EmpleadoXND");
                System.out.println("2. IncidenciaXND");
                System.out.println("3. HistorialXND");
                System.out.println("0. Finalizar");
                System.out.println("************************************************");
                entrada = scanner.nextInt();
                salir = validarOpcion(entrada);
            } catch (Exception e) {
                System.out.println("No has elegido una opcion valida. Debes introducir un entero");
                scanner.next();
            }
        } while (!salir);
        return entrada;
    }

    // Funcion que valida que las opciones elegidas en el menu principal sean correctas
    public static boolean validarOpcion(Integer entrada) {
        if (entrada < 0 || entrada > 3) {
            System.out.println("Opcion incorrecta");
            return false;
        } else {
            return true;
        }

    }

    public static void menuEmpleado() {
        boolean salir = false;
        do {
            try {
                //Mostramos el menu pinrcipal con las diferentes opciones
                Integer pideEntero = menuPrincipalEmpleado();
                switch (pideEntero) {
                    case 0:
                        salir = true;
                        System.out.println("Hasta pronto!!");
                        break;
                    case 1:
                        e.a�adirEmpleado();
                        break;
                    case 2:
                        e.validarEmpleado();
                        break;
                    case 3:
                        e.modificarEmpleado();
                        break;
                    case 4:
                        e.cambiarContrase�a();
                        break;
                    case 5:
                        e.eliminarEmpleado();
                        break;
                    default:
                        System.out.println("Valor introducido incorrecto. Intentalo de nuevo");
                        break;
                }
            } catch (Exception ex) {
                System.out.println("Opcion no valida");
            }
        } while (!salir);

    }

    // Metodo que muestra el menú principal
    public static Integer menuPrincipalEmpleado() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        int entrada = 100;
        do {
            try {
                System.out.println("************************************************");
                System.out.println("Elige una de las siguientes opciones");
                System.out.println("1. Insertar un nuevo empleado en la BBDD");
                System.out.println("2. Validar la entrada de un empleado");
                System.out.println("3. Modificar el perfil de un empleado");
                System.out.println("4. Cambiar la contraseña de un empleado");
                System.out.println("5. Eliminar un empleado");
                System.out.println("0. Finalizar");
                System.out.println("************************************************");
                entrada = scanner.nextInt();
                salir = validarOpcion2(entrada);
            } catch (Exception e) {
                System.out.println("No has elegido una opcion valida. Debes introducir un entero");
                scanner.next();
            }
        } while (!salir);
        return entrada;
    }

    // Funcion que valida que las opciones elegidas en el menu principal sean correctas
    public static boolean validarOpcion2(Integer entrada) {
        if (entrada < 0 || entrada > 5) {
            System.out.println("Opcion incorrecta");
            return false;
        } else {
            return true;
        }

    }

    public static void menuIncidencia() {
        boolean salir = false;
        do {
            try {
                //Mostramos el menu pinrcipal con las diferentes opciones
                Integer pideEntero = menuPrincipalIncidencia();
                switch (pideEntero) {
                    case 0:
                        salir = true;
                        System.out.println("Hasta pronto!!");
                        break;
                    case 1:
                        int idincidencia = PedirDatos.pideEntero("Inserte el ID de una incidencia");
                        i.obtenerIncidenciaSegunId();
                        break;
                    case 2:
                        i.listarIncidencias();
                        break;
                    case 3:
                        i.insertarIncidencias();
                        break;
                    case 4:
                        e.mostrarUsuarios();
                        String usuarioDestino = PedirDatos.pideString("Inserte el nombre de usuario de destino");
                        i.incidenciasDestino();
                        break;
                    case 5:
                        e.mostrarUsuarios();
                        String usuarioOrigen = PedirDatos.pideString("Inserte el nombre de usuario de origen");
                        i.incidenciasOrigen();
                        break;
                    default:
                        System.out.println("Valor introducido incorrecto. Intentalo de nuevo");
                        break;
                }
            } catch (Exception ex) {
                System.out.println("Opcion no valida");
            }
        } while (!salir);
    }

    // Metodo que muestra el menu principal
    public static Integer menuPrincipalIncidencia() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        int entrada = 100;
        do {
            try {
                System.out.println("************************************************");
                System.out.println("Elige una de las siguientes opciones");
                System.out.println("1. Obtener una incidencia a partir de su ID");
                System.out.println("2. Listar incidencias");
                System.out.println("3. Insertar incidencia");
                System.out.println("4. Obtener incidencias destinadas a un empleado");
                System.out.println("5. Obtener incidencias creadas por un empleado");
                System.out.println("0. Finalizar");
                System.out.println("************************************************");
                entrada = scanner.nextInt();
                salir = validarOpcion2(entrada);
            } catch (Exception e) {
                System.out.println("No has elegido una opción válida. Debes introducir un entero");
                scanner.next();
            }
        } while (!salir);
        return entrada;
    }

    public static void menuHistorial() {
        boolean salir = false;
        do {
            try {
                //Mostramos el menu pinrcipal con las diferentes opciones
                Integer pideEntero = menuPrincipalHistorial();
                switch (pideEntero) {
                    case 0:
                        salir = true;
                        System.out.println("Hasta pronto!!");
                        break;
                    case 1:
                        h.obtenerIniciosSesion();
                        break;
                    case 2:
                        h.listadoConsultaDeEmpleados();
                        break;
                    case 3:
                        h.listarIncidencias();
                        break;
                    default:
                        System.out.println("Valor introducido incorrecto. Intentalo de nuevo");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Opcion no valida");
            }
        } while (!salir);
    }

    // Metodo que muestra el menu principal
    public static Integer menuPrincipalHistorial() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        int entrada = 100;
        do {
            try {
                System.out.println("************************************************");
                System.out.println("Elige una de las siguientes opciones");
                System.out.println("1. Obtener el listado de todos los inicios de sesion que ha habido");
                System.out.println("2. Obtener el listado de los empleados que han consultado sus incidencias");
                System.out.println("3. Obtener el numero de incidencias que hay en la BBDD");
                System.out.println("0. Finalizar");
                System.out.println("************************************************");
                entrada = scanner.nextInt();
                salir = validarOpcion2(entrada);
            } catch (Exception e) {
                System.out.println("No has elegido una opcion valida. Debes introducir un entero");
                scanner.next();
            }
        } while (!salir);
        return entrada;
    }

    
}
