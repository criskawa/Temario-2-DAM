package ClasesXND;

import java.io.File;
import javax.xml.transform.OutputKeys;
import org.exist.util.UTF8;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.CollectionManagementService;
import org.xmldb.api.modules.XMLResource;
import org.xmldb.api.modules.XQueryService;

public class GestionXND {

    protected static String driver = "org.exist.xmldb.DatabaseImpl";
    public static String URL = "xmldb:exist://localhost:8080/exist/xmlrpc";
    static Database database;
    static Collection col;
    private static String usuario;
    private static String contrase�a;
    private static String collection;
    private static String recurso;

    public GestionXND() {
        this.database = null;
        this.usuario = "admin";
        this.contrase�a = "admin";
        collection = "/db";
        recurso = null;
    }

    public static Collection crearColeccion(Collection contexto, String nColeccion) throws XMLDBException {
        Collection nuevaColeccion = null;
        try {
            col = (Collection) DatabaseManager.getCollection(URL + "/db", usuario, contrase�a);
            CollectionManagementService mgtService = (CollectionManagementService) col.getService("CollectionManagementService", "1.0");
            nuevaColeccion = mgtService.createCollection(new String(UTF8.encode(nColeccion)));
        } catch (XMLDBException e) {
            e.getMessage();
        }
        return nuevaColeccion;
    }

    public static void asignarRecurso(Collection contexto, File archivo) throws XMLDBException {
        Resource nuevoRecurso = contexto.createResource(archivo.getName(), "XMLResource");
        nuevoRecurso.setContent(archivo);
        contexto.storeResource(nuevoRecurso);
    }

    public static Collection leerColeccion(String coleccion) {
        Collection colRet = null;
        try {
            colRet = DatabaseManager.getCollection(URL + coleccion, usuario, contrase�a);
        } catch (XMLDBException e) {
            e.getMessage();
        }
        return colRet;
    }

    public static Collection conexionBBDD() throws ClassNotFoundException, InstantiationException, IllegalAccessException, XMLDBException {

        Class cl = Class.forName(driver);
        database = (Database) cl.newInstance();
        DatabaseManager.registerDatabase(database);
        col = DatabaseManager.getCollection(URL + collection, usuario, contrase�a);
        return col;

    }

    //Funcion para hacer una consulta
    public static ResourceSet hacerConsulta(String consulta) throws XMLDBException {
        col = (Collection) DatabaseManager.getCollection(URL + collection, usuario, contrase�a);
        XQueryService service = (XQueryService) col.getService("XQueryService", "1.0");
        service.setProperty(OutputKeys.INDENT, "yes");
        service.setProperty(OutputKeys.ENCODING, "UTF-8");
        CompiledExpression compiled = service.compile(consulta);
        ResourceSet resultado = service.execute(compiled);
        return resultado;
    }
}
