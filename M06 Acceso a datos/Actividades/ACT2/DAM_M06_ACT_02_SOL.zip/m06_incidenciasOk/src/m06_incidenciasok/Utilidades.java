/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m06_incidenciasok;
/**
 *
 * @author olga_
 */


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Utilidades {
    /*	Función que solicita al usuario que introduzca un número entero, si es válido lo devuelve a la función que le ha llamado*/
    // función declarada con el parámetro pregunta, contendrá la pregunta a realizar al usuario y devuelve un entero.	
    public static int pideEntero(String pregunta) {
            boolean pedir ;
            String leeNumero;
            int numero= 0;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));		

            do {
                    pedir=false; // indicador si el número que ha introducido el usuario es correcto.
                    // Motramos la pregunta que se ha pasado por parámetro.
                    System.out.println(pregunta);				

                    try{
                            // guardamos el dato que ha metido el usuario por consola.
                            leeNumero = br.readLine();
                            //Convertimos el dato introducido por consola a Integer.
                            numero = Integer.parseInt(leeNumero);
                            // Si al parsear el número no ha dado error está todo ok continúa la ejecución
                            pedir = true;

                    }catch (NumberFormatException e) {
                            // controlamos que no introduzca un String en vez de un número.
                            System.out.println("Debe introducir un número entero, no se admiten cadenas");						

                    }catch (Exception e){
                                    System.out.println("Se ha producido un error, debe introducir un número "+e.getMessage());								
                    }							

            } while (!pedir); // repetir hasta que pedir=true

            // Devolvemos el número introducido por el usuario.
            return numero;
    }
	

    /*	 Función que devuelve un número double que ha introducido el usuario por consola*/
    // función declarada con el parámetro pregunta, contendrá la pregunta a realizar al usuario  y devuelve un double.
    public static double pideDouble(String pregunta) {		

            boolean pedir ;
            String leeNumero;
            double numero= 0;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));		

            do {
                    pedir=false; // indicador si el número que ha introducido el usuario es correcto.
                    // Motramos la pregunta que se ha pasado por parámetro.
                    System.out.println(pregunta);				

                    try{
                            // guardamos el dato que ha metido el usuario por consola.
                            leeNumero = br.readLine();
                            //Convertimos el dato introducido por consola a Integer.
                            numero = Double.parseDouble(leeNumero);
                            // Si al parsear el número no ha dado error está todo ok, continúo la ejecución
                            pedir = true;

                    }catch (NumberFormatException e) {
                            // controlamos que no introduzca un String en vez de un número.
                            System.out.println("Debe introducir un número, no se admiten cadenas");						

                    }catch (Exception e){
                                    System.out.println("Se ha producido un error, debe introducir un número "+e.getMessage());								
                    }							

            } while (!pedir); // repetir hasta que pedir=true

            // Devolvemos el número introducido por el usuario.
            return numero;
    }	
	
	
    /*	Función que solicita al usuario que introduzca un texto, si es válido lo devuelve a la función que le ha llamado*/
    // función declarada con el parámetro pregunta, contendrá la pregunta a realizar al usuario y devuelve un String.	
    public static String pideTexto(String texto) {
            boolean pedir ;
            String textoIntroducido="";

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));		

            do {
                    pedir=false; // indicador si el texto que ha introducido el usuario es correcto.

                    // Motramos el texto que se ha pasado por parámetro.
                    System.out.println(texto);				

                    try{
                            // guardamos el texto que ha introducido el usuario por consola.
                            textoIntroducido = br.readLine();
                            // Si al parsear el número no ha dado error está todo ok continúa la ejecución
                            pedir = true;

                    }catch (IOException e) {
                            // controlamos que no introduzca un String en vez de un número.
                            System.out.println("Se ha producido un error en el texto introducido, vuelvalo a intentar");						

                    }catch (Exception e){
                                    System.out.println("Se ha producido un error "+e.getMessage());								
                    }							

            } while (!pedir); // repetir hasta que pedir=true

            // Devolvemos el texto introducido por el usuario.
            return textoIntroducido;
    }
}