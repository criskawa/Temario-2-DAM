package m06_opcionesMenu;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import m06_incidenciasok.Utilidades;
import org.hibernate.Session;


public class TestORM {
    
    private static final Session sesion = null;
    private static String nombre = null;
    private static String pass = null;
        
    public static void main(String[] args) {
        
        Logger.getLogger("org.hibernate").setLevel(Level.OFF);
        
        // Pedimos que se identifique el usuario      
        boolean existe = false;
        
        // Pedimos que se identifique el usuario.
        System.out.println("----- Identifíquese en el sistema ------");
        
        // comprobamos si existe el usuario
        EmpleadosORM.pedirEmpleado();        
        
        // Mostramos las opciones del menú.
        int opcion;
	do {
              System.out.println("********************************************");
              System.out.println("* 1.- Gestión de empleados                 *");
              System.out.println("* 2.- Gestión de incidencias               *");
              System.out.println("* 3.- Gestión del histórico de incidencias *");
              System.out.println("* 0.- Salir                                *");
              System.out.println("********************************************");
              
              opcion=Utilidades.pideEntero("Seleccione una opción");

              switch (opcion) {
                    case 1: {
                        try {
                                EmpleadosORM empORM = new EmpleadosORM(nombre);
                                break;
                        } catch (IOException ex) {
                                Logger.getLogger(TestORM.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        }
                    case 2: {
                        IncidenciasORM ind = new IncidenciasORM();
                        break;	
                    }
                    case 3: {
                        // Menú de Historial
                        HistorialORM his = new HistorialORM();                        
                        break;	
                    }
                    case 0: {
                        System.out.println("Hasta pronto!!!");
                        break;
                    }
                    default: 
                        System.out.println("Opción incorrecta");
                }
        }while (opcion !=0) ;
        
        
    }    
    
    
   
   
    
    
}
