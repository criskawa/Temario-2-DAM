package m06_opcionesMenu;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import m06_incidenciasok.Empleado;
import m06_incidenciasok.HibernateUtil;
import m06_incidenciasok.Historial;
import m06_incidenciasok.Utilidades;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author olga_
 */
public class HistorialORM {
    
    private static Session sesion = null;

    public HistorialORM(){
        Logger.getLogger("org.hibernate").setLevel(Level.OFF);  
       // Abrimos la sesión con la BBDD   
       sesion = HibernateUtil.getSessionFactory().openSession();

       // Mostramos las opciones del menú.
       int opcion;
       do {
           // Opciones del menú
           System.out.println("********* GESTIÓN DE HISTORIAL **********");
           System.out.println("* 1.- Consulta inicio de sesión         *");
           System.out.println("* 2.- Ranking incidencias urgentes      *");
           System.out.println("* 3.- Posisión en el ranking            *");
           System.out.println("* 0.- Salir                             *");
           System.out.println("*****************************************");

           opcion=Utilidades.pideEntero("Seleccione una opción");
           switch (opcion) {
               case 1: {
                   // Muestra una incidencia en concreto
                   dameHistorialSesion();                   
                   break;
               }
               case 2: {                   
                   // Mostrar todas las incidencias
                   List<Object []> lista = dameRanking();                   
                   break;	
               }
               case 3: {
                   damePosicionRanking();
                   break;	
               }
               case 0: {
                   System.out.println("Hasta pronto!!!");
                   break;
               }
               default: 
                   System.out.println("Opción incorrecta");
           }  
      }while (opcion !=0) ;      
    }      
    
    // Método que inserta en el Historial cuando se produce un evento
    public static void altaEvento(Empleado emp, String tipo){
        
        // Abrimos la sesión con la BBDD   
        sesion = HibernateUtil.getSessionFactory().openSession();
        // Obtenemos el último idevento dado de alta en la bbdd
        Query consulta = sesion.createQuery("select max(idevento) from Historial a");
        List lisEventos = consulta.list();
        int codigo = ((Integer)lisEventos.get(0)); 
        // Obtenemos la fecha y hora
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        String fecha = dtf.format(LocalDateTime.now());
                
        // damos de alta en historial        
        Historial his = new Historial();
        Transaction tr = sesion.beginTransaction();
            his.setIdevento(codigo+1);
            his.setEmpleado(emp);
            his.setFechahora(fecha);
            his.setTipo(tipo);
        sesion.save(his);
        tr.commit();
    }
    
    
    // Método que devuelve una Incidencia a partir de su idincidencia   
     public static void dameHistorialSesion(){
          // Pedimos el empleado al usuario.
        Empleado emp = EmpleadosORM.dameEmpleado();
        // Obtenemos su pk
        String nombre = emp.getNombreusuario();        
        // Creamos la query con parámetros.
        Query consulta = sesion.createQuery("select a.fechahora "
                                           + " from Historial a "
                                           + "where empleado = :nombre "
                                           + "and tipo = 'I' "
                                           + "order by fechahora desc");        
        // Asisgnamos valor al parámetro
        consulta.setString("nombre", nombre);        
        List lisHistorial = consulta.list();
        String fecha;
        fecha = (String)lisHistorial.get(0);
        System.out.println("El último inicio de sesión fue: " + fecha);    
        System.out.println("");
     }
    
     // Método que devuelve la lista de empleados con incidencias Urgentes
     public static List<Object []> dameRanking(){ 
          // Creamos la query con parámetros.
        Query consulta = sesion.createQuery("select a.empleado, count(*) as contador "
                                           + " from Historial a "
                                           + "where tipo = 'U' "
                                           + "group by empleado "
                                           + "order by contador desc");  
        List<Object[]> lisHistorial = consulta.list();
        
        System.out.println( "****   Listado de empleados con incidencias de tipo Urgente  ****");
        for (Object[] lista : lisHistorial){
            // Obtenemos el Empleado
            Empleado emp = (Empleado)lista[0];
            // Obtenemos su nombre completo
            String nombre = emp.getNombrecompleto();
            System.out.println( "El empleado "+ nombre + " tiene " + lista[1] + " incidencias");           
        }
         System.out.println("");        
        
        return lisHistorial;
     }
     
          
     // Método que devuelve la posición en el ranking de un empleado
     public static void damePosicionRanking(){ 
        int cont = 0;
        Empleado emp;
        String nombreEmp;
        // Obtenemos las incidencias urgentes por empleado. 
        List<Object[]> lisHistorial = dameRanking();
        // pedimos el empleado que se quiere consultar.
        String nombre = Utilidades.pideTexto("Introduzca el nombre del usuario");
        // Nos recorremos la lista para comprobar si está en ella
        for (Object[] lista : lisHistorial){            
            // Obtenemos el Empleado
            emp = (Empleado)lista[0];
            // Obtenemos su nombre completo
            nombreEmp = emp.getNombreusuario();
            if (nombre.equals(nombreEmp)){
                System.out.println( "Posición: " + cont);
                System.out.println( "El empleado "+ nombre + " tiene " + lista[1] + " incidencias");  
                System.out.println( "");               
            }                    
            cont ++;
        }    
        // si no ha encontrado al empleado dentro del listado.
        if (cont==0){
            System.out.println( " El empleado no tiene incidencias urgentes ");
        }
        
     }
     
}


