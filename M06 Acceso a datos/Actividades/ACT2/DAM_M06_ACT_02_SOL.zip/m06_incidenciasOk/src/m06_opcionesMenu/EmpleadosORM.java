package m06_opcionesMenu;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import m06_incidenciasok.Empleado;
import m06_incidenciasok.HibernateUtil;
import m06_incidenciasok.Utilidades;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author olga_
 */

// Clase que se encargará de la gestión de empleados
public class EmpleadosORM {
    
    private static Session sesion = null;
    private static Empleado emp;
    private static String nombre = null;
    private static String pass = null;
   
   public EmpleadosORM (String nombre) throws IOException {
       
     Logger.getLogger("org.hibernate").setLevel(Level.OFF);  
    // Abrimos la sesión con la BBDD   
    sesion = HibernateUtil.getSessionFactory().openSession();
    
    // Mostramos las opciones del menú.
    int opcion;
    do {
        // Opciones del menú
        System.out.println("****** GESTIÓN DE EMPLEADOS *********");
        System.out.println("* 1.- Insertar empleado             *");
        System.out.println("* 2.- Validar  empleado             *");
        System.out.println("* 3.- Modificar perfil del empleado *");
        System.out.println("* 4.- Cambiar contraseña            *");
        System.out.println("* 0.- Salir                         *");
        System.out.println("*************************************");

        opcion=Utilidades.pideEntero("Seleccione una opción");
          
        switch (opcion) {
            case 1: {
                insertarEmpleado();
                break;
            }
            case 2: {
                pedirEmpleado();
                // Llamar al menú de incidencias
                break;	
            }
            case 3: {
                modificarPerfil();
                break;	
            }
            case 4: {
                cambiarPass();
                break;	
            }
            case 0: {
                System.out.println("Hasta pronto!!!");
                break;
            }
            default: 
                System.out.println("Opción incorrecta");
        }  
     }while (opcion !=0) ;      
   }  
   
   // Insertar un empleado nuevo
   public static void insertarEmpleado(){
       
            Transaction tx = sesion.beginTransaction();

            String nombreusuario = Utilidades.pideTexto("Introduce el nombre de usuario (10 posiciones)");
            String password = Utilidades.pideTexto("Introduce la contraseña (10 posiciones)");
            String nombreCompleto = Utilidades.pideTexto("Introduce el nombre completo del empleado(50 posiciones)");
            String telefono=Utilidades.pideTexto("Introduce el teléfono (9 posiciones)");
            if((telefono.length()>9)|| (nombreusuario.length()>10)|| (password.length()>10)||(nombreCompleto.length()> 50)){
                System.out.println("Verifique el tamaño de los campos en alguno de ellos se ha excedido del límite");
                System.out.println("");
            }else{        
                // Creamos el objeto Empleado
                Empleado emp = new Empleado(nombreusuario,password,nombreCompleto,telefono);
                // Lo guardamos en la bbdd
                sesion.save(emp);
                tx.commit();   
                System.out.println("Los nuevos datos del empleado son: "+emp);
                System.out.println("");
            }    
   }
   
   public static void pedirEmpleado(){
       
       boolean existe = false;
            
       // Se repite hasta que se introduzcan los datos correctos
       while (!existe){
            nombre = Utilidades.pideTexto("Introduzca su nombre de usuario");
            pass = Utilidades.pideTexto("Introduzca su contraseña");
            // comprobamos si existe como empleado en el sistema
            Empleado emp = EmpleadosORM.validarEmpleado(nombre, pass);

            if (emp == null){
                // No existe
                System.out.println("Usuario no registrado en el sistema");
            }else{
                existe = true;
                // Insertamos un registro en Historial por inicio de sesión
                HistorialORM.altaEvento(emp,"I");                        
            }
        }
   }
   
   // Método que valida si los datos introducidos existen en el sistema
    public static Empleado validarEmpleado(String nombre, String pass){
        
        // Creamos la conexión con la bbdd 
        sesion = HibernateUtil.getSessionFactory().openSession();
        // Obtenemos todos los empleados con el nombre pasado por parámetro
        Empleado emp = (Empleado) sesion.get(Empleado.class, nombre);
        
        if (emp == null || emp.getPassword().equals(pass)== false){
            // cerramos la conexión con la bbdd
            sesion.close();
            // No se ha obtenido ningún empleado con ese nombre
            // o la password es errónea.
            System.out.println("No existe ningún empleado con esos datos");
        }
        return emp;
    } 
   
    // Método que modifica los datos de un empleado.
    public static void modificarPerfil(){
        // Nos devuelve un Empleado 
        emp = dameEmpleado();       
        // existe el empleado, mostramos sus datos
        System.out.println(emp);
        // pedimos los nuevos datos a modificar, excepto la PK.
        String passUsuario = Utilidades.pideTexto("Introduzca la contraseña");
        String nombreCompleto = Utilidades.pideTexto("Introduzca el nombre completo del usuario");
        String telefono = Utilidades.pideTexto("Introduzca el teléfono del usuario");
        
        if((telefono.length()>9)|| (passUsuario.length()>10)||(nombreCompleto.length()> 50)){
                System.out.println("Verifique el tamaño de los campos en alguno de ellos se ha excedido del límite");
                System.out.println("");
        }else{ 
            // Guardamos los datos modificados del empleado
            Transaction tx = sesion.beginTransaction();
                    emp.setPassword(passUsuario);
                    emp.setNombrecompleto(nombreCompleto);
                    emp.setTelefono(telefono);
            sesion.update(emp);
            tx.commit();
            System.out.println("Los nuevos datos del empleado son: "+emp);
            System.out.println("");
        }    
    }
    
    // Método que modifica la contraseña de un usuario
    public static void cambiarPass(){
        
        // Nos devuelve un Empleado 
        emp = dameEmpleado();
        
        // Pedimos la nueva contraseña
        String passUsuario = Utilidades.pideTexto("Introduzca la contraseña");
        if(passUsuario.length()>10){
                System.out.println("Verifique el tamaño de la contraseña, se ha excedido del límite");
                System.out.println("");
        }else{         
            // Iniciamos la transacción para guardar los datos.
            Transaction tx = sesion.beginTransaction();
                emp.setPassword(passUsuario);
            sesion.update(emp);
            tx.commit();
            System.out.println("Los nuevos datos del empleado son: "+emp);
            System.out.println("");
        }    
    }

    public static Empleado dameEmpleado(){
        Empleado empl;
        boolean existe = false;    
        // Comprobamos si hay conexión
        if ( (sesion==null) || (sesion.isConnected()==false) )
             sesion=HibernateUtil.getSessionFactory().openSession();
        do{        
            String nombre = Utilidades.pideTexto("Introduzca el nombre de usuario");
            // Comprobamos que ha introducido un nombre

            // Obtenemos el objeto Empleado que tiene todos los datos del nombre pasado por parámetro
            empl = (Empleado) sesion.get(Empleado.class, nombre);

            if (empl == null){
                // No existe el empleado
                existe = false;
                System.out.println("El nombre del empleado introducido no existe en el sistema. Inténtelo de nuevo");
            }else{
                existe = true;                
            }                
        } while (!existe);    
        
        return empl;
    }
}
