package m06_opcionesMenu;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import m06_incidenciasok.Empleado;
import m06_incidenciasok.HibernateUtil;
import m06_incidenciasok.Incidencia;
import m06_incidenciasok.Utilidades;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author olga_
 */
public class IncidenciasORM {
    
    private static Session sesion = null;

    public IncidenciasORM(){
        Logger.getLogger("org.hibernate").setLevel(Level.OFF);  
       // Abrimos la sesión con la BBDD   
       sesion = HibernateUtil.getSessionFactory().openSession();

       // Mostramos las opciones del menú.
       int opcion;
       do {
           // Opciones del menú
           System.out.println("********* GESTIÓN DE INCIDENCIAS ***********");
           System.out.println("* 1.- Obtener incidencia                   *");
           System.out.println("* 2.- Lista de incidencias                 *");
           System.out.println("* 3.- Nueva incidencia                     *");
           System.out.println("* 4.- Incidencias destinadas a un empleado *");
           System.out.println("* 5.- Incidencias creadas por empleados    *");
           System.out.println("* 0.- Salir                                *");
           System.out.println("********************************************");

           opcion=Utilidades.pideEntero("Seleccione una opción");
           switch (opcion) {
               case 1: {
                   // Muestra una incidencia en concreto
                   Incidencia ind = dameIncidencia();                   
                   break;
               }
               case 2: {                   
                   // Mostrar todas las incidencias
                   dameTodasIncidencias();                   
                   break;	
               }
               case 3: {
                   altaIncidencia();
                   break;	
               }
               case 4: {
                   dameIncidenciaEmpleado();
                   break;	
               }
               
               case 5: {
                   dameInciCreadasPorEmpleado();
                   break;	
               }
               case 0: {
                   System.out.println("Hasta pronto!!!");
                   break;
               }
               default: 
                   System.out.println("Opción incorrecta");
           }  
      }while (opcion !=0) ;      
      }      
    
    
 
    // Método que devuelve una Incidencia a partir de su id
     public static Incidencia dameIncidencia(){
        Incidencia ind;
        boolean existe = false;        
       
        int codigo = Utilidades.pideEntero("Introduzca el código de incidencia");
        // Comprobamos que ha introducido un nombre

        // Obtenemos el objeto Empleado que tiene todos los datos del nombre pasado por parámetro
        ind = (Incidencia) sesion.get(Incidencia.class, codigo);

        if (ind == null){
            // No existe esa incidencia
            existe = false;
            System.out.println("El código de incidencia no existe en el sistema.");
            System.out.println("");
        }else{
            existe = true;                
            System.out.println(ind);
        }                
        
        
        return ind;
    }
     
    // Método que devuelve todas las Incidencia 
    public static void dameTodasIncidencias(){    
        // Montamos la consulta
        Query consulta = sesion.createQuery("select a from Incidencia a");
        // Devuelve un list de objetos Incidencia
        List<Incidencia> lisIncidencia = consulta.list();
        // Nos recorremos el list para mostrarlas por pantalla
        for(Incidencia inc: lisIncidencia){
            System.out.println(inc);            
        }
        
        System.out.println("");
    }
    
    // Método que da de alta una incidencia
    public static void altaIncidencia(){    
        // Pedimos los datos necesarios al usuario.
        // Obtenemos la última idincidencia dada de alta en la bbdd
        Query consulta = sesion.createQuery("select max(idincidencia) from Incidencia a");
        List lisIncidencia = consulta.list();
        
        int codigo = ( (Integer)lisIncidencia.get(0)); 
        // Obtenemos el empleado origen
        Empleado origen = EmpleadosORM.dameEmpleado();
        // Obtenemos el empleado destino
        Empleado destino = EmpleadosORM.dameEmpleado();
        // Pedimos la fecha y hora
        String fecha = Utilidades.pideTexto("Introduce la fecha y hora (YYYY/MM/DD HH:MM:SS)");
        // Pedimos el detalle
        String detalle = Utilidades.pideTexto("Introduzca alguna observación");
        // Pedimos el tipo de incidencia
        String tipo = Utilidades.pideTexto("Introduzca el tipo de incidencia (Urgente-Normal)");        
        
        // guardamos los datos en la bbdd
        Transaction tr = sesion.beginTransaction();
        // Cargamos el objeto incidencia con los datos solicitados al usuario
        Incidencia incide = new Incidencia();        
            incide.setIdincidencia(codigo+1);
            incide.setEmpleadoByOrigen(origen);
            incide.setEmpleadoByDestino(destino);
            incide.setFechahora(fecha);
            incide.setDetalle(detalle);
            incide.setTipo(tipo);
        sesion.save(incide);
        tr.commit();
        
        System.out.println("Se ha dado de alta la incidencia con éxito, con los siguientes datos:");
        System.out.println(incide);
        System.out.println("");
        // Si el tipo de incidencia es Urgente, insertamos un registro en Historial
        if (tipo.charAt(0)== 'U'){
             HistorialORM.altaEvento(origen,"U");            
        }     
        
    }    

    // Método que devuelve las incidencias destinadas a un empleado en concreto
    public static void dameIncidenciaEmpleado(){  
        // Pedimos el empleado al usuario.
        Empleado emp = EmpleadosORM.dameEmpleado();
        // Obtenemos su pk
        String destino = emp.getNombreusuario();        
        // Creamos la query con parámetros.
        Query consulta = sesion.createQuery("select a from Incidencia a where destino = :destino");
        // Asisgnamos valor al parámetro
        consulta.setString("destino", destino);        
        List<Incidencia> lisIncidencia = consulta.list();
        if (lisIncidencia.size()>0){
            // Recorremos las incidencias para mostrarlas por consola
            for(Incidencia inc: lisIncidencia){
                System.out.println(inc);            
            }        
            System.out.println("");
            // Damos de alta en Historial, con C de Consulta
            HistorialORM.altaEvento(emp,"C");             
        } else{
            System.out.println("No existen incidencias para el empleado: " + destino);
        }    
    }
    
    // Método que devuelve las incidencias de un empleado en concreto
    public static void dameInciCreadasPorEmpleado(){  
        // Pedimos el empleado al usuario.
        Empleado emp = EmpleadosORM.dameEmpleado();
        // Obtenemos su pk
       String origen = emp.getNombreusuario();
        
        Query consulta = sesion.createQuery("select a from Incidencia a where origen =:origen");
        consulta.setString("origen", origen);
        
        List<Incidencia> lisIncidencia = consulta.list();
        // Recorremos las incidencias para mostrarlas por consola
        for(Incidencia inc: lisIncidencia){
            System.out.println(inc);            
        }        
        System.out.println("");
    }
    
    
}
