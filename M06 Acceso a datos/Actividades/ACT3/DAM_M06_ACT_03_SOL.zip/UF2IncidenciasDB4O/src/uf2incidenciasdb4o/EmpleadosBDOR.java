package uf2incidenciasdb4o;

import uf2incidenciasdb4o.gestoresBD.GestorEmpleados;
import uf2incidenciasdb4o.gestoresBD.GestorHistorial;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import uf2incidenciasdb4o.pojo.Empleado;

/**
 *
 * @author Irene Orta Cintado
 */
public class EmpleadosBDOR {

    /**
     * Muestra el menú de gestión de empleados y llama al método correspondiente
     * en función de la opción escogida.
     */
    public static void gestionarEmpleados() {
        int opcion;
        do {
            displayMenu();
            opcion = Utilidades.pideEntero("Opción: ");

            switch (opcion) {
                case 1:
                    insertarEmpleado();
                    break;
                case 2:
                    validarPassword();
                    break;
                case 3:
                    Empleado e1 = seleccionarEmpleado();
                    if (e1 != null) {
                        modificarPerfil(e1);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 4:
                    Empleado e2 = seleccionarEmpleado();
                    if (e2 != null) {
                        modificarPassword(e2);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 5:
                    Empleado e3 = seleccionarEmpleado();
                    if (e3 != null) {
                        eliminarEmpleado(e3);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 0:
                    break;
                default:
                    System.out.println("La opción " + opcion + " no está disponible.");
            }

        } while (opcion != 0);

    }

    /**
     * Muestra por consola el menú de gestión de empleados.
     */
    private static void displayMenu() {
        System.out.println("\nGESTOR DE EMPLEADOS");
        System.out.println("Usuario: " + TestBDOR.usuarioActual.getNombreusuario() + "\n");
        System.out.println("Seleccione una opción:\n"
                + "1.Insertar un empleado nuevo en la B.D.\n"
                + "2.Validar la entrada de un empleado (suministrando usuario y contraseña)\n"
                + "3.Modificar el perfil de un empleado existente.\n"
                + "4.Cambiar la contraseña de un empleado existente.\n"
                + "5.Eliminar un empleado.\n"
                + "0.Volver al menú principal.");
    }

    //////////////  OPCION 1    //////////////
    //
    /**
     * Llama a los métodos necesarios para pedir al usuario la información de un
     * nuevo empleado y lo añade a la BBDD.
     */
    private static void insertarEmpleado() {

        GestorEmpleados.insertarEmpleado(
                pedirNombreUsuario(),
                pedirPassword(),
                pedirNombreCompleto(),
                pedirTelefono());
    }

    /**
     * Pide al usuario por consola el nombre de usuario de un empleado.
     *
     * @return
     */
    private static String pedirNombreUsuario() {
        String nombreusuario = "";
        boolean formatoCorrecto = false;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Introduzca el nombre de usuario:");
        do {
            try {
                nombreusuario = br.readLine();

                if (nombreusuario.isBlank()) {
                    System.out.println("La información no puede estar vacía o contener sólo espacios.");
                } else if (nombreusuario.length() > 10) {
                    System.out.println("El nombre de usuario no puede contener más de 10 caracteres.");
                } else if (!nombreusuario.matches("^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$")) {
                    System.out.println("El nombre de usuario sólo puede contener carateres alfanuméricos, además de puntos y guines bajos (exceptuando al inicio).");
                } else {
                    formatoCorrecto = true;
                }
            } catch (IOException ex) {
                Logger.getLogger(EmpleadosBDOR.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error de entrada de datos.");
            }
        } while (!formatoCorrecto);

        return nombreusuario;
    }

    /**
     * Pide al usuario por consola la contraseña de un empleado.
     *
     * @return
     */
    private static String pedirPassword() {
        String password = "";
        boolean formatoCorrecto = false;

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Introduzca la contraseña:");
        do {
            try {
                password = br.readLine();

                if (password.isBlank()) {
                    System.out.println("La información no puede estar vacía o contener sólo espacios.");
                } else if (password.length() > 10 || password.length() < 3) {
                    System.out.println("La contraseña de contener entre 3 y 10 caracteres.");
                } else {
                    formatoCorrecto = true;
                }
            } catch (IOException ex) {
                Logger.getLogger(EmpleadosBDOR.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error de entrada de datos.");
            }
        } while (!formatoCorrecto);

        return password;
    }

    /**
     * Pide al usuario por consola el nombre completo de un empleado.
     *
     * @return
     */
    private static String pedirNombreCompleto() {
        String nombrecompleto = "";
        boolean formatoCorrecto = false;

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Introduzca el nombre del empleado:");
        do {
            try {
                nombrecompleto = br.readLine();

                if (nombrecompleto.isBlank()) {
                    System.out.println("La información no puede estar vacía o contener sólo espacios.");
                } else if (nombrecompleto.length() > 50) {
                    System.out.println("El nombre del empleado no puede contener más de 50 caracteres.");
                } else if (nombrecompleto.matches(".*\\d.*")) {
                    System.out.println("El nombre del empleado no puede contener dígitos.");
                } else {
                    formatoCorrecto = true;
                }
            } catch (IOException ex) {
                Logger.getLogger(EmpleadosBDOR.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error de entrada de datos.");
            }
        } while (!formatoCorrecto);

        return nombrecompleto;
    }

    /**
     * Pide al usuario por consola el teléfono de un empleado.
     *
     * @return
     */
    private static String pedirTelefono() {
        String telefono = "";
        boolean formatoCorrecto = false;

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Introduzca el número de teléfono:");
        do {
            try {
                telefono = br.readLine();

                if (telefono.isBlank()) {
                    System.out.println("La información no puede estar vacía o contener sólo espacios.");
                } else if (!telefono.matches("\\d{9}")) {
                    System.out.println("El teléfono tener 9 dígitos.");
                } else {
                    formatoCorrecto = true;
                }
            } catch (IOException ex) {
                Logger.getLogger(EmpleadosBDOR.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error de entrada de datos.");
            }
        } while (!formatoCorrecto);

        return telefono;
    }

    ////////////// OPCION 2 //////////////
    //
    /**
     * Valida la contraseña de un usuario, comprobando que coincide con la
     * registrada en la BBDD.
     *
     * Inicia sesión con el usuario validado y añade un evento de inicio de
     * sesión al historial.
     *
     * @return
     */
    static boolean validarPassword() {
        boolean passwordValida = false;
        System.out.print("USUARIO - ");
        Empleado e = GestorEmpleados.buscarEmpleado(pedirNombreUsuario());

        if (e != null) {

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                System.out.println("PASSWORD - Introduzca la contraseña:");
                String password = br.readLine();
                passwordValida = e.getPassword().equals(password);
                if (passwordValida) {
                    System.out.println("Usuario " + e.getNombreusuario() + " validado.");
                    //  guarda el empleado que acaba de acceder con su usuario y contraseña
                    TestBDOR.usuarioActual = e;
                    //  genera un evento de inicio de sesión
                    GestorHistorial.insertarEvento(
                            "I",
                            new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()),
                            e);
                } else {
                    System.out.println("La contraseña no es correcta para el usuario " + e.getNombreusuario());
                }
            } catch (IOException ex) {
                Logger.getLogger(EmpleadosBDOR.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error de entrada de datos.");
            }

        } else {
            System.out.println("El usuario introducido no existe.");
        }
        return passwordValida;
    }

    ////////////// OPCION 3 //////////////
    //
    /**
     * Muestra un lista con todos los empleado y pide al usuario seleccionar uno
     * de ellos. Devuelve un objeto del Empleado seleccionado.
     *
     * Si no se selecciona un empleado existente, devuelve null.
     *
     * @return
     */
    static Empleado seleccionarEmpleado() {
        System.out.println("Lista de Empleados: ");
        listarEmpleados();
        System.out.println("\n¿Qué empleado desea seleccionar?");
        return GestorEmpleados.buscarEmpleado(pedirNombreUsuario());
    }

    /**
     * Muestra un menú que permite al ususario escoger modificar el nombre o el
     * teléfono de un empleado y llama al método para realizar la acción de al
     * opción escogida.
     *
     * .* @param e
     */
    private static void modificarPerfil(Empleado e) {
        int opcion;
        do {
            System.out.println("\nMODIFICAR EMPLEADO " + e.getNombreusuario());
            displayMenuModificarPerfil();
            opcion = Utilidades.pideEntero("Opción: ");

            switch (opcion) {
                case 1:
                    modificarNombreCompleto(e);
                    break;
                case 2:
                    modificarTelefono(e);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("La opción " + opcion + " no está disponible.");
            }

        } while (opcion != 0);
    }

    /**
     * Muestra el menú de modificación del perfil de un empleado por consola.
     */
    private static void displayMenuModificarPerfil() {
        System.out.println("Seleccione una opción:\n"
                + "1.Modificar nombre completo.\n"
                + "2.Modificar teléfono.\n"
                + "0.Volver al menú de gestión de empleados.");
    }

    /**
     * Pide los datos al usuario y modifica el nombre de un empleado.
     *
     * @param e
     */
    private static void modificarNombreCompleto(Empleado e) {
        String nombrecompleto = pedirNombreCompleto();
        GestorEmpleados.modificarNombreCompleto(e, nombrecompleto);
    }

    /**
     * Pide los datos al usuario y modifica el teléfono de un empleado.
     *
     * @param e
     */
    private static void modificarTelefono(Empleado e) {
        String telefono = pedirTelefono();
        GestorEmpleados.modificarTelefono(e, telefono);
    }

    ////////////// OPCION 4 //////////////
    //
    /**
     * Pide una nueva contraseña y modifica la contraseña del empleado
     * seleccionado pasado como parámetro.
     *
     * ESTE APARTADO TENDRÍA MÁS SENTIDO QUE SIRVIERA PARA MODIFICAR LA
     * CONTRASEÑA DEL EMPLEADO CON LA SESIÓN ACTIVA, PERO EL ENUNCIADO INDICA
     * QUE ES UN EMPLEADO EXISTENTE, NO SÓLO EL ACTIVO.
     *
     * @param e
     */
    private static void modificarPassword(Empleado e) {
        String password = pedirPassword();
        GestorEmpleados.modificarPassword(e, password);
    }

    ////////////// OPCION 5 //////////////
    //
    /**
     * Elimina el empleado pasado como parámetro de la BBDD, pidiendo una
     * confirmación de la operación al usuario.
     *
     * @param e
     */
    private static void eliminarEmpleado(Empleado e) {
        System.out.println(e.toString());
        if (Utilidades.requestYesNo("\n¿Desea eliminar el empleado indicado?")) {
            GestorEmpleados.eliminarEmpleado(e);
            System.out.println("Empleado borrado");
            //  si se elimina el empleado actual, se vuelve a pedir login
            if (e.getNombreusuario().equals(TestBDOR.usuarioActual.getNombreusuario())) {
                boolean loginCorrecto = false;
                do {
                    loginCorrecto = EmpleadosBDOR.validarPassword();
                } while (!loginCorrecto);
            }
        } else {
            System.out.println("Operción de borrado cancelada.");
        }
    }

    //  UTILIDADES
    /**
     * Muestra una lista con todos los empleados por consola.
     */
    static void listarEmpleados() {
        List<Empleado> le = GestorEmpleados.listarEmpleados();

        for (Empleado e : le) {
            System.out.println(e);
        }
    }

    /**
     * Llama al método seleccionarEmpleado() hasta que el usuario selecciona un
     * empleado con un nombre de ususario válido.
     *
     * @return
     */
    static Empleado pedirEmpleado() {
        Empleado e;
        do {
            e = seleccionarEmpleado();
            if (e == null) {
                System.out.println("El empleado indicado no existe.");
            }
        } while (e == null);
        return e;
    }
}
