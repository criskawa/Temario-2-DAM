package uf2incidenciasdb4o;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Irene Orta Cintado
 */
public class Utilidades {
    /**
     * Pide un número por consola (si el usuario no introduce un número, vuelve
     * a pedirlo repitiendo el proceso hasta que el usuario introduzca un valor
     * numérico válido) y retorna el número introducido.
     *
     * @return
     */
    public static int pideEntero() {
        int int_number = 0;
        boolean numero_incorrecto;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do {
            try {
                int_number = Integer.parseInt(br.readLine());
                numero_incorrecto = false;
            } catch (NumberFormatException ex) {
                System.out.println("El valor introducido debe ser un número entero (int).");
                numero_incorrecto = true;
            } catch (IOException ex) {
                System.out.println("Ha habido un error con la entrada de datos.");
                numero_incorrecto = true;
            }
        } while (numero_incorrecto);

        return int_number;
    }

    /**
     * Llama al método pideEntero(), imprimiendo por pantalla la pregunta
     * recibida como parámetro.
     *
     * @param pregunta texto de la pregunta a realizar para solocitar la entrade
     * de datos
     * @return número introducido por el usuario
     */
    public static int pideEntero(String pregunta) {
        System.out.println(pregunta);
        return Utilidades.pideEntero();
    }

    /**
     * Pide una respuesta afirmativa o negativa
     *
     * @return choice devuelve true si la respuesta es afirmativa y false si es
     * negativa
     */
    public static boolean requestYesNo() {
        char answer;
        boolean choice = false;
        boolean invalidAnswer = true;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do {
            try {
                answer = br.readLine().charAt(0);

                if (answer == 'y' || answer == 'Y') {
                    choice = true;
                    invalidAnswer = false;
                } else if (answer == 'n' || answer == 'N') {
                    choice = false;
                    invalidAnswer = false;
                } else {
                    System.out.println("Seleccione una opción válida (y/n):");
                }
            } catch (IOException ex) {
                System.out.println("Seleccione una opción válida (y/n):");
            }

        } while (invalidAnswer);

        return choice;
    }

    /**
     * Pide una respuesta afirmativa o negativa a una pregunta
     *
     * @param question preguta a realizar
     * @return choice devuelve true si la respuesta es afirmativa y false si es
     * negativa
     */
    public static boolean requestYesNo(String question) {
        System.out.println(question + " (y/n)");
        return requestYesNo();
    }
}
