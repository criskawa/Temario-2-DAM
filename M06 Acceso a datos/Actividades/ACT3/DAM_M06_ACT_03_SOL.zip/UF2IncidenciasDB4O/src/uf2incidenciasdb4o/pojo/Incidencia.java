package uf2incidenciasdb4o.pojo;

/**
 *
 * @author Irene Orta Cintado
 */
public class Incidencia {
    
    int idincidencia;

    private Empleado origen;
    private Empleado destino;

    private String fechahora;
    private String detalle;
    private String tipo;

    public Incidencia() {
    }

    public Incidencia(Incidencia i) {
        this.idincidencia = i.idincidencia;
        this.origen = i.origen;
        this.destino = i.destino;
        this.fechahora = i.fechahora;
        this.detalle = i.detalle;
        this.tipo = i.tipo;
    }
    
    public Incidencia(int idincidencia, Empleado origen, Empleado destino, String fechahora, String detalle, String tipo) {
        this.idincidencia = idincidencia;
        this.origen = origen;
        this.destino = destino;
        this.fechahora = fechahora;
        this.detalle = detalle;
        this.tipo = tipo;
    }    
    
    public Incidencia(Empleado origen, Empleado destino, String fechahora, String detalle, String tipo) {
        this.origen = origen;
        this.destino = destino;
        this.fechahora = fechahora;
        this.detalle = detalle;
        this.tipo = tipo;
    }
    
        @Override
    public String toString() {
        return "INCIDENCIA "+idincidencia+":\norigen: " + origen + "\ndestino: " + destino + "\nfechahora: " + fechahora + ", tipo: " + tipo + "\ndetalle: " + detalle;
    }

    public int getIdincidencia() {
        return idincidencia;
    }

    public void setIdincidencia(int idincidencia) {
        this.idincidencia = idincidencia;
    }


    public Empleado getOrigen() {
        return origen;
    }

    public void setOrigen(Empleado origen) {
        this.origen = origen;
    }

    public Empleado getDestino() {
        return destino;
    }

    public void setDestino(Empleado destino) {
        this.destino = destino;
    }

    public String getFechahora() {
        return fechahora;
    }

    public void setFechahora(String fechahora) {
        this.fechahora = fechahora;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
}
