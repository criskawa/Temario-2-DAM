package uf2incidenciasdb4o.pojo;

/**
 *
 * @author Irene Orta Cintado
 */
public class Empleado {
    
    private String nombreusuario;
    private String password;
    private String nombrecompleto;
    private String telefono;

    public Empleado() {
    }

    public Empleado(Empleado e) {
        this.nombreusuario = e.nombreusuario;
        this.password = password;
        this.nombrecompleto = nombrecompleto;
        this.telefono = telefono;
    }

    public Empleado(String nombreusuario, String password, String nombrecompleto, String telefono) {
        this.nombreusuario = nombreusuario;
        this.password = password;
        this.nombrecompleto = nombrecompleto;
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "nombreusuario=" + nombreusuario + ", nombrecompleto=" + nombrecompleto + ", telefono=" + telefono;
    }
    
    public String getNombreusuario() {
        return nombreusuario;
    }

    public void setNombreusuario(String nombreusuario) {
        this.nombreusuario = nombreusuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
}
