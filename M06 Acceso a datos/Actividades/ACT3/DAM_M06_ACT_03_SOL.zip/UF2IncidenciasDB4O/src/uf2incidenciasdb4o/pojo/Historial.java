package uf2incidenciasdb4o.pojo;

/**
 *
 * @author Irene Orta Cintado
 */
public class Historial {

    private String tipo;
    private String fechahora;

    private Empleado empleado;

    public Historial() {
    }

    public Historial(Historial h) {
        this.tipo = h.tipo;
        this.fechahora = h.fechahora;
        this.empleado = h.empleado;
    }

    public Historial(String tipo, String fechahora, Empleado empleado) {
        this.tipo = tipo;
        this.fechahora = fechahora;
        this.empleado = empleado;
    }

    @Override
    public String toString() {
        return "EVENTO: tipo=" + tipo + ", fechahora=" + fechahora + "\nEmpleado: " + empleado;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFechahora() {
        return fechahora;
    }

    public void setFechahora(String fechahora) {
        this.fechahora = fechahora;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

}
