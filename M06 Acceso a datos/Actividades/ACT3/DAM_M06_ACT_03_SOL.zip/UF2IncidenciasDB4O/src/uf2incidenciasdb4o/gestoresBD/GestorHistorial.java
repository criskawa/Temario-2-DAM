package uf2incidenciasdb4o.gestoresBD;

import com.db4o.ObjectSet;
import java.util.ArrayList;
import java.util.List;
import uf2incidenciasdb4o.RankingEmpleado;
import uf2incidenciasdb4o.TestBDOR;
import uf2incidenciasdb4o.pojo.Empleado;
import uf2incidenciasdb4o.pojo.Historial;

/**
 * Clase que contiene métodos para acceder y modificar los datos de la clase
 * historial en la BBDD.
 *
 * @author Irene Orta Cintado
 */
public class GestorHistorial {

    /**
     * Inserta un evento en la tabla historial con los datos pasados como
     * parámetros.
     *
     * @param tipo
     * @param fechahora
     * @param empleado
     */
    public static void insertarEvento(String tipo, String fechahora, Empleado empleado) {
        TestBDOR.gestorDB.db.store(new Historial(tipo, fechahora, empleado));
    }

    /**
     * Busca en la tabla historial el último evento de inicio de sesión del
     * empleado pasado como parámetro.
     *
     * @param e
     * @return
     */
    public static Historial ultimoInicioSesion(Empleado e) {
        boolean encontradoInicioSesion = false;
        Historial busqueda = new Historial(null, null, e);
        Historial encontrado = null;
        ObjectSet os = TestBDOR.gestorDB.db.queryByExample(busqueda);

        while (os.hasNext()) {
            Historial temp = (Historial) os.next();
            if (temp.getTipo().equals("I")) {
                encontradoInicioSesion = true;
                if (encontrado != null) {
                    //  si el temporal es posterior al encontrado, actualiza el encontrado
                    if (temp.getFechahora().compareTo(encontrado.getFechahora()) > 0) {
                        encontrado = temp;
                    }

                } else {
                    encontrado = temp;
                }
            }
        }
        
        if(!encontradoInicioSesion) encontrado = null;

        return encontrado;
    }

    /**
     * Realiza una búsqueda en la BBDD de los empleados que han creado
 incidencias urgentes y devuelve una lista ordenada de RankingEmpleado con la
 información de los empleados, su posición en el ranking y el número de
 incidencias urgentes creadas.
     *
     * @return
     */
    public static List<RankingEmpleado> rankingEmpleadosPorIncidenciasUrgentesCreadas() {
        List<RankingEmpleado> ranking = new ArrayList<RankingEmpleado>();
        List<Empleado> empleados = TestBDOR.gestorDB.db.query(Empleado.class);

        // crear objetos RankingEmpleado
        for (Empleado e : empleados) {
            ObjectSet os = TestBDOR.gestorDB.db.queryByExample(new Historial("U", null, e));
            int counter = 0;
            while (os.hasNext()) {
                os.next();
                counter++;
            }
            ranking.add(new RankingEmpleado(e, counter));
        }
        //  actualiza las posiciones de los empleados en el ranking
        ranking = RankingEmpleado.setPosicionesEmpleados(ranking);

        return ranking;
    }

}
