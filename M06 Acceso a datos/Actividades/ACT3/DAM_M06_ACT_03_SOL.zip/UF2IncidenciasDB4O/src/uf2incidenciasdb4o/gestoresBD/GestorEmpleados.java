package uf2incidenciasdb4o.gestoresBD;

import com.db4o.ObjectSet;
import java.util.List;
import uf2incidenciasdb4o.TestBDOR;
import uf2incidenciasdb4o.pojo.Empleado;

/**
 * Clase que contiene métodos para acceder y modificar los datos de la clase
 * empleado en la BBDD.
 *
 * @author Irene Orta Cintado
 */
public class GestorEmpleados {

    /**
     * Inserta un empleado en la bbdd con los datos pasados como parámetros.
     *
     * @param nombreusuario
     * @param password
     * @param nombrecompleto
     * @param telefono
     */
    public static void insertarEmpleado(String nombreusuario, String password, String nombrecompleto, String telefono) {
        Empleado existe = buscarEmpleado(nombreusuario);
        if(existe==null)
            TestBDOR.gestorDB.db.store(new Empleado(nombreusuario, password, nombrecompleto, telefono));
        else    System.out.println("El empleado con el usuario "+nombreusuario+" ya existe.");
    }

    /**
     * Devuelve un objeto con la información de la BBDD del empleado con el
     * nombre de usuario pasado por parámetro.
     *
     * @param nombreusuario
     * @return
     */
    public static Empleado buscarEmpleado(String nombreusuario) {
        Empleado e;
        Empleado busqueda = new Empleado(nombreusuario, null, null, null);
        ObjectSet os = TestBDOR.gestorDB.db.queryByExample(busqueda);

        if (os.size() >0) {
            e = (Empleado) os.next();
        } else {
            e = null;
        }

        return e;
    }

    /**
     * Devuelve una lista con todos los empleados en la bbdd.
     *
     * @return
     */
    public static List<Empleado> listarEmpleados() {
        List<Empleado> listadoEmpleados = TestBDOR.gestorDB.db.query(Empleado.class);

        return listadoEmpleados;
    }

    /**
     * Modifica la contraseña del empleado pasado por parámetro con el texto del
     * parámetro password.
     *
     * @param e
     * @param password
     */
    public static void modificarPassword(Empleado e, String password) {
        Empleado encontrado = buscarEmpleado(e.getNombreusuario());

        if (encontrado != null) {
            encontrado.setPassword(password);
            TestBDOR.gestorDB.db.store(encontrado);
        }
    }

    /**
     * Modifica el nombre del empleado pasado por parámetro con el texto del
     * parámetro nombrecompleto.
     *
     * @param e
     * @param nombrecompleto
     */
    public static void modificarNombreCompleto(Empleado e, String nombrecompleto) {
        Empleado encontrado = buscarEmpleado(e.getNombreusuario());

        if (encontrado != null) {
            encontrado.setNombrecompleto(nombrecompleto);
            TestBDOR.gestorDB.db.store(encontrado);
        }
    }

    /**
     * Modifica el telefono del empleado pasado por parámetro con el texto del
     * parámetro telefono.
     *
     * @param e
     * @param telefono
     */
    public static void modificarTelefono(Empleado e, String telefono) {
        Empleado encontrado = buscarEmpleado(e.getNombreusuario());

        if (encontrado != null) {
            encontrado.setTelefono(telefono);
            TestBDOR.gestorDB.db.store(encontrado);
        }
    }

    /**
     * Elimina el empleado pasado por parámetro de la base de datos.
     *
     * @param e
     */
    public static void eliminarEmpleado(Empleado e) {
        Empleado encontrado = buscarEmpleado(e.getNombreusuario());

        if (encontrado != null) {
            TestBDOR.gestorDB.db.delete(encontrado);
        }
    }
}
