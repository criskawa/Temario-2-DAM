package uf2incidenciasdb4o.gestoresBD;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import uf2incidenciasdb4o.pojo.Empleado;
import uf2incidenciasdb4o.pojo.Historial;
import uf2incidenciasdb4o.pojo.Incidencia;

/**
 *
 * @author Irene Orta Cintado
 */
public class GestorDB4O {

    ObjectContainer db;

    public GestorDB4O() {
        db = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(), "gestion_incidencias.txt");
    }

    public void initData() {

        //System.out.println(db.query(Empleado.class).size());
        //  si no hay datos en la bbdd, carga los datos por defecto        
        if (db.query(Empleado.class).size() == 0 && db.query(Incidencia.class).size() == 0 && db.query(Historial.class).size() == 0) {
            Empleado e1 = new Empleado("fito", "pez", "Fito Fitipaldi", "888888888");
            Empleado e2 = new Empleado("mar", "1234", "Mar Fontana", "555555555");
            Empleado e3 = new Empleado("enjuto", "intlene", "Enjuto Mojamuto", "333333333");
            Empleado e4 = new Empleado("Quetin", "pulp", "Quentin Tarantino", "777777777");

            db.store(e1);
            db.store(e2);
            db.store(e3);
            db.store(e4);

            Incidencia i1 = new Incidencia(0, e1, e2, "2021/02/03 17:56:00", "Terremoto", "Urgente");
            Incidencia i2 = new Incidencia(1, e3, e4, "2021/03/03 14:56:00", "No quedan galletas", "Normal");
            Incidencia i3 = new Incidencia(2, e1, e3, "2021/04/03 16:56:00", "Suministro de electricidad interrumpido", "Urgente");
            Incidencia i4 = new Incidencia(3, e2, e1, "2021/05/03 18:46:00", "Serpiente desaparecida!", "Urgente");
            Incidencia i5 = new Incidencia(4, e4, e2, "2021/06/03 10:46:00", "Incendio en la cocina!", "Urgente");

            db.store(i1);
            db.store(i2);
            db.store(i3);
            db.store(i4);
            db.store(i5);

            Historial h1 = new Historial("U", "2021/02/03 17:56:00", e1);
            Historial h2 = new Historial("U", "2021/04/03 16:56:00", e1);
            Historial h3 = new Historial("U", "2021/05/03 18:46:00", e2);
            Historial h4 = new Historial("U", "2021/06/03 10:46:00", e4);
            Historial h5 = new Historial("I", "2021/02/03 17:56:00", e1);
            Historial h6 = new Historial("I", "2021/04/03 16:56:00", e1);
            Historial h7 = new Historial("I", "2021/05/03 12:46:00", e2);
            Historial h8 = new Historial("I", "2021/06/03 13:46:00", e4);
            Historial h9 = new Historial("I", "2021/05/03 17:46:00", e3);
            Historial h10 = new Historial("C", "2021/06/03 15:46:00", e3);
            Historial h11 = new Historial("C", "2021/06/03 10:46:00", e3);

            db.store(h1);
            db.store(h2);
            db.store(h3);
            db.store(h4);
            db.store(h5);
            db.store(h6);
            db.store(h7);
            db.store(h8);
            db.store(h9);
            db.store(h10);
            db.store(h11);
        }

        //  si hay datos en la bbdd, pero no hay empelados, crea uno para poder iniciar sesión
        if (db.query(Empleado.class).size() == 0) {
            Empleado e1 = new Empleado("fito", "pez", "Fito Fitipaldi", "888888888");
            db.store(e1);
        }
    }

    public void cerrar() {
        db.close();
    }
}
