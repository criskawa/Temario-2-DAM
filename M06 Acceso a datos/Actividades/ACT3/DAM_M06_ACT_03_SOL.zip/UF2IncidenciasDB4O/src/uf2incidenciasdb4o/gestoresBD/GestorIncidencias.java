package uf2incidenciasdb4o.gestoresBD;

import com.db4o.ObjectSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import uf2incidenciasdb4o.TestBDOR;
import uf2incidenciasdb4o.pojo.Empleado;
import uf2incidenciasdb4o.pojo.Incidencia;

/**
 * Clase que contiene métodos para acceder y modificar los datos de la clase
 * incidencia en la BBDD.
 *
 * @author Irene Orta Cintado
 */
public class GestorIncidencias {

    /**
     * Busca el objeto incidencia con el id pasado por parámetro y devuelve un
     * objeto Incidencia can la información de ese registro o null si no lo
     * encuentra.
     *
     * @param idincidencia
     * @return
     */
    public static Incidencia buscarIncidencia(int idincidencia) {
        Incidencia encontrada;
        Incidencia busqueda = new Incidencia(idincidencia, null, null, null, null, null);
        ObjectSet os = TestBDOR.gestorDB.db.queryByExample(busqueda);

        if (os.size() == 1) {
            encontrada = (Incidencia) os.next();
        } else {
            encontrada = null;
        }

        return encontrada;
    }

    /**
     * Devuelve una lista de las incidencias registradas en la tabla incidencia.
     *
     * @return
     */
    public static List<Incidencia> listarIncidencias() {
        List<Incidencia> listadoIncidencias = TestBDOR.gestorDB.db.query(Incidencia.class);

        return listadoIncidencias;
    }

    /**
     * Devuelve una lista de las incidencias enviadas al empleado pasado como
     * parámetro.
     *
     * @param e
     * @return
     */
    public static List<Incidencia> listarIncidenciasParaEmpleado(Empleado e) {
        List<Incidencia> listadoIncidencias = new ArrayList<Incidencia>();
        Incidencia busqueda = new Incidencia(0, null, e, null, null, null);
        ObjectSet os = TestBDOR.gestorDB.db.queryByExample(busqueda);

        while (os.hasNext()) {
            listadoIncidencias.add((Incidencia) os.next());
        }

        return listadoIncidencias;
    }

    /**
     * Devuelve una lista de las incidencias enviadas por el empleado pasado
     * como parámetro.
     *
     * @param e
     * @return
     */
    public static List<Incidencia> listarIncidenciasDeEmpleado(Empleado e) {
        List<Incidencia> listadoIncidencias = new ArrayList<Incidencia>();
        Incidencia busqueda = new Incidencia(0, e, null, null, null, null);
        ObjectSet os = TestBDOR.gestorDB.db.queryByExample(busqueda);

        while (os.hasNext()) {
            listadoIncidencias.add((Incidencia) os.next());
        }
        return listadoIncidencias;
    }

    /**
     * Inserta una incidencia en la bbdd con los datos pasados como parámetros.
     *
     * @param origen
     * @param destino
     * @param fechahora
     * @param detalle
     * @param tipo
     */
    public static void insertarIncidencia(Empleado origen, Empleado destino, String fechahora, String detalle, String tipo) {
        TestBDOR.gestorDB.db.store(new Incidencia(generarId(), origen, destino, fechahora, detalle, tipo));
    }

    /**
     * Comprueba que el id a signar al objeto está disponible
     *
     * @return
     */
    public static int generarId() {
        boolean nuevoIdEncontrado = false;
        List<Incidencia> listaIncidencias = listarIncidencias();
        int nuevoId = 0;
        int contadorIncidencias = 1;

        while (!nuevoIdEncontrado) {
            for (Incidencia i : listaIncidencias) {
                if (i.getIdincidencia() == nuevoId) {
                    break;
                }
                if (contadorIncidencias == listaIncidencias.size()) {
                    nuevoIdEncontrado = true;
                }
                contadorIncidencias++;
            }
            contadorIncidencias = 1;
            nuevoId++;
        }
        return nuevoId;
    }
}
