package uf2incidenciasdb4o;

import uf2incidenciasdb4o.gestoresBD.GestorDB4O;
import uf2incidenciasdb4o.pojo.Empleado;

/**
 *
 * @author Irene Orta Cintado
 */
public class TestBDOR {

    static Empleado usuarioActual;
    public static GestorDB4O gestorDB;

    public static void main(String args[]) {
        //  iniciar bbdd
        gestorDB = new GestorDB4O();
        //  generar datos
        gestorDB.initData();
        //  realiza el log in del usuario antes de empezar a usar el programa
        boolean loginCorrecto = false;
        do {
            loginCorrecto = EmpleadosBDOR.validarPassword();
        } while (!loginCorrecto);

        //  menu principal
        int opcion;
        do {
            displayMenu();
            opcion = Utilidades.pideEntero("Opción: ");

            switch (opcion) {
                case 1:
                    EmpleadosBDOR.gestionarEmpleados();
                    break;
                case 2:
                    IncidenciasBDOR.gestionarIncidencias();
                    break;
                case 3:
                    HistorialBDOR.gestionarIncidencias();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("La opción " + opcion + " no está disponible.");
            }
        } while (opcion != 0);
        
        System.out.println("Bye, bye!");
        //cerrar bbdd
        gestorDB.cerrar();
    }

    /**
     * Muestra las opciones del menu principal por consola.
     */
    private static void displayMenu() {
        System.out.println("\nMENU PRINCIAL TEST ORM");
        System.out.println("Usuario: " + usuarioActual.getNombreusuario() + "\n");
        System.out.println("¿Qué tipo de operaciones quiere realizar?\n"
                + "1.Gestionar empleados.\n"
                + "2.Gestionar incidencias.\n"
                + "3.Gestionar el historial.\n"
                + "0.Salir.");
    }

    
}
