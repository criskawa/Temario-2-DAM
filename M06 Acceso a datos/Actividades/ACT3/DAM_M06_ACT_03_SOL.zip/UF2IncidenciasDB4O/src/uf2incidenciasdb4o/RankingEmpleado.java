package uf2incidenciasdb4o;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import uf2incidenciasdb4o.pojo.Empleado;

/**
 * Clase que almacena información sobre el ranking de empleados.
 *
 * @author Irene Orta Cintado
 */
public class RankingEmpleado {

    private Empleado empleado;
    private int incidenciasUrgentes;
    private int posicion;

    RankingEmpleado() {
    }

    public RankingEmpleado(Empleado empleado, int incidenciasUrgentes, int posicion) {
        this.empleado = empleado;
        this.incidenciasUrgentes = incidenciasUrgentes;
        this.posicion = posicion;
    }

    public RankingEmpleado(Empleado empleado, int incidenciasUrgentes) {
        this.empleado = empleado;
        this.incidenciasUrgentes = incidenciasUrgentes;
    }

    /**
     * Permite ordenar una colección de objetos RankingEmpleado, usando el método
 sort de la clase Collections.
     *
     * @param o1
     * @param o2
     * @return
     */

    /**
     * Ordena el ranking y asigna las posiciones a los empleados.
     *
     * @param list
     * @return
     */
    public static List<RankingEmpleado> setPosicionesEmpleados(List<RankingEmpleado> list) {
        
        List<RankingEmpleado> listaOrdenada = new ArrayList<RankingEmpleado>();
        
        for (RankingEmpleado empleado: list){
            //  si no hay elementos, añade el primero
            if (listaOrdenada.size()==0) listaOrdenada.add(empleado);
            else {
                // compara las incidencias del empleado con los registrados en el ranking
                for(int i=0;i<listaOrdenada.size();i++){
                    //  si el empleado en el ranking tiene menos incidencias, el nuevo empleado se inserta en su posición
                    if(listaOrdenada.get(i).incidenciasUrgentes<empleado.incidenciasUrgentes){
                        listaOrdenada.add(i,empleado);
                        break;
                    }
                    //  si ya se ha comparado con todos los empleados del ranking, se añade al final
                    else if (listaOrdenada.size()==(i+1)){
                        listaOrdenada.add(empleado);
                        break;
                    }
                }
            }
        }
        
        // añade la posición a los objetos RankingEmpleado
        for (int i = 0; i < listaOrdenada.size(); i++) {
            listaOrdenada.get(i).posicion = i + 1;
        }

        return listaOrdenada;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public int getIncidenciasUrgentes() {
        return incidenciasUrgentes;
    }

    public void setIncidenciasUrgentes(int incidenciasUrgentes) {
        this.incidenciasUrgentes = incidenciasUrgentes;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    @Override
    public String toString() {
        return "(" + incidenciasUrgentes + ") " + posicion + ". " + empleado.getNombrecompleto();
    }

}
