package uf2incidenciasdb4o;

import uf2incidenciasdb4o.gestoresBD.GestorIncidencias;
import uf2incidenciasdb4o.gestoresBD.GestorHistorial;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import uf2incidenciasdb4o.pojo.Empleado;
import uf2incidenciasdb4o.pojo.Incidencia;

/**
 *
 * @author Irene Orta Cintado
 */
public class IncidenciasBDOR {

    /**
     * Muestra el menú de gestión de incidencias y llama al método
     * correspondiente en función de la opción escogida.
     */
    public static void gestionarIncidencias() {
        int opcion;

        do {
            displayMenu();
            opcion = Utilidades.pideEntero("Opción: ");

            switch (opcion) {
                case 1:
                    mostrarIncidencia(seleccionarIncidencia());
                    break;
                case 2:
                    listarIncidencias();
                    break;
                case 3:
                    insertarIncidencia();
                    break;
                case 4:
                    Empleado e1 = EmpleadosBDOR.seleccionarEmpleado();
                    if (e1 != null) {
                        listarIncidenciasParaEmpleado(e1);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 5:
                    Empleado e2 = EmpleadosBDOR.seleccionarEmpleado();
                    if (e2 != null) {
                        listarIncidenciasDeEmpleado(e2);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 0:

                    break;
                default:
                    System.out.println("La opción " + opcion + " no está disponible.");
            }

        } while (opcion != 0);

    }

    /**
     * Muestra por consola el menú de gestión de incidencias.
     */
    private static void displayMenu() {
        System.out.println("\nGESTOR DE INCIDENCIAS");
        System.out.println("Usuario: " + TestBDOR.usuarioActual.getNombreusuario() + "\n");
        System.out.println("Seleccione una opción:\n"
                + "1.Obtener Incidencia.\n"
                + "2.Obtener la lista de todas las incidencias.\n"
                + "3.Insertar incidencia.\n"
                + "4.Obtener las incidencias recibidas por un empleado.\n"
                + "5.Obtener las incidencias creadas por un empleado.\n"
                + "0.Volver al menú principal.");
    }

    ////////////// OPCION 1 //////////////
    //
    /**
     * Pide al usuario el ID de la incidencia que desea buscar y llama un método
     * que muestra su información.
     *
     * @return
     */
    private static Incidencia seleccionarIncidencia() {
        List<Incidencia> listaIncidencias =  GestorIncidencias.listarIncidencias();
        System.out.println("¿Qué incidencia desea seleccionar?");
        return GestorIncidencias.buscarIncidencia(Utilidades.pideEntero("Número:"));
    }

    /**
     * Muestra por consola la información de la incidencia pasada como
     * parámetro.
     *
     * En caso de ser null, muestra un mensaje informando que la incidencia
     * seleccionada no está registrada en el sistema.
     *
     * @param i
     */
    private static void mostrarIncidencia(Incidencia i) {
        if (i != null) {
            System.out.println(i);
        } else {
            System.out.println("El id seleccionado no coincide con niguna incidencia registrada.");
        }
    }

    ////////////// OPCION 2 //////////////
    //
    /**
     * Muestra un lista con todas las incidencias por consola.
     */
    private static void listarIncidencias() {
        List<Incidencia> li = GestorIncidencias.listarIncidencias();

        for (Incidencia i : li) {
            System.out.println(i);
        }
    }

    ////////////// OPCION 3 //////////////
    //
    /**
     * Pide los datos necesarios al usuario y crea una nueva incidencia en la
     * BBDD.
     *
     * Si la incidencia es de tipo Urgente, genera un evento en el historial.
     */
    private static void insertarIncidencia() {
        String fechahora, detalle, tipo;
        Empleado origen, destino;
        System.out.println("LISTA DE EMPLEADOS:");
        EmpleadosBDOR.listarEmpleados();
        System.out.println("");
        System.out.println("Origen");
        origen = EmpleadosBDOR.pedirEmpleado();
        System.out.println("Destino:");
        do {
            destino = EmpleadosBDOR.pedirEmpleado();
            if (destino.equals(origen)) {
                System.out.println("El empleado de destino debe ser diferente al de origen.");
            }
        } while (destino.getNombreusuario().equals(origen.getNombreusuario()));

        fechahora = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date());
        detalle = pedirDetalleIncidencia();
        tipo = pedirTipoIncidencia();

        GestorIncidencias.insertarIncidencia(origen, destino, fechahora, detalle, tipo);

        if (tipo.equals("Urgente")) {
            //  genera un evento de creación de incidencia urgente
            GestorHistorial.insertarEvento(
                    "U",
                    new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()),
                    TestBDOR.usuarioActual);
        }
    }

    /**
     * Pide al usuario el detalle de una incidencia.
     *
     * @return
     */
    private static String pedirDetalleIncidencia() {
        String detalle = "";
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Introduzca los detalles de la incidencia:");
        try {
            detalle = br.readLine();
        } catch (IOException ex) {
            Logger.getLogger(IncidenciasBDOR.class.getName()).log(Level.SEVERE, null, ex);
        }
        return detalle;
    }

    /**
     * Pide al usuario el tipo de incidencia hasta selecionar un tipo válido.
     *
     * @return
     */
    private static String pedirTipoIncidencia() {
        String tipo = "";
        boolean tipoCorrecto = false;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Introduzca el tipo de incidencia (Urgente[u], Normal[n]):");
        do {
            try {
                tipo = br.readLine();
                if (tipo.equals("u") || tipo.equals("n")) {
                    if (tipo.equals("u")) {
                        tipo = "Urgente";
                    } else {
                        tipo = "Normal";
                    }
                    tipoCorrecto = true;
                } else {
                    System.out.println("El tipo de incidencia sólo puede ser Normal[n] o Urgente[u].");
                }
            } catch (IOException ex) {
                Logger.getLogger(IncidenciasBDOR.class.getName()).log(Level.SEVERE, null, ex);
            }
        } while (!tipoCorrecto);
        return tipo;
    }

    ////////////// OPCION 4 //////////////
    //
    /**
     * Muestra una lista por consola con todas incidencia enviadas a un
     * empleado.
     *
     * Genera un evento de consulta en el historial.
     *
     * @param e
     */
    private static void listarIncidenciasParaEmpleado(Empleado e) {
        List<Incidencia> li = GestorIncidencias.listarIncidenciasParaEmpleado(e);

        for (Incidencia i : li) {
            System.out.println(i);
        }

        //  genera un evento de consulta de incidencias para un empleado
        GestorHistorial.insertarEvento(
                "C",
                new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()),
                TestBDOR.usuarioActual);
    }

    ////////////// OPCION 5 //////////////
    /**
     * Muestra una lista por consola con todas incidencia enviadas por un
     * empleado.
     *
     * @param e
     */
    private static void listarIncidenciasDeEmpleado(Empleado e) {
        List<Incidencia> li = GestorIncidencias.listarIncidenciasDeEmpleado(e);

        for (Incidencia i : li) {
            System.out.println(i);
        }
    }
}
