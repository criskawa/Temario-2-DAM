package uf2incidenciasdb4o;

import uf2incidenciasdb4o.gestoresBD.GestorHistorial;
import java.util.List;
import uf2incidenciasdb4o.pojo.Empleado;
import uf2incidenciasdb4o.pojo.Historial;

/**
 *
 * @author Irene Orta Cintado
 */
public class HistorialBDOR {

    /**
     * Muestra el menú de gestión del historial y llama al método
     * correspondiente en función de la opción escogida.
     */
    public static void gestionarIncidencias() {
        int opcion;

        do {
            displayMenu();
            opcion = Utilidades.pideEntero("Opción: ");

            switch (opcion) {
                case 1:
                    Empleado e1 = EmpleadosBDOR.seleccionarEmpleado();
                    if (e1 != null) {
                        obtenerFechHoraInicioSesion(e1);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 2:
                    mostrarRankingEmpleados();
                    break;
                case 3:
                    Empleado e2 = EmpleadosBDOR.seleccionarEmpleado();
                    if (e2 != null) {
                        mostrarPosicionEmpleadoRanking(e2);
                    } else {
                        System.out.println("El usuario introducido no corresponde a ningún empleado.");
                    }
                    break;
                case 0:

                    break;
                default:
                    System.out.println("La opción " + opcion + " no está disponible.");
            }

        } while (opcion != 0);

    }

    /**
     * Muestra por consola el menú de gestión del historial.
     */
    private static void displayMenu() {
        System.out.println("\nGESTOR DEL HISTORIAL");
        System.out.println("Usuario: " + TestBDOR.usuarioActual.getNombreusuario() + "\n");
        System.out.println("Seleccione una opción:\n"
                + "1.Obtener fecha-hora del último inicio de sesión de un empleado.\n"
                + "2.Obtener ranking de los empleados por cantidad de incidencias urgentes creadas.\n"
                + "3.Obtener la posición dentro del ranking para un empleado concreto.\n"
                + "0.Volver al menú principal.");
    }

    //////////////  OPCION 1    //////////////
    //
    /**
     * Muestra por consola la fecha y hora del último inicio de sesión del
     * usuario pasado por parámetro.
     *
     * @param e
     */
    private static void obtenerFechHoraInicioSesion(Empleado e) {
        Historial h = GestorHistorial.ultimoInicioSesion(e);

        if (h == null) {
            System.out.println("Este empleado nunca ha iniciado sesión");
        } else {
            System.out.println("Último inicio de sesión: " + h.getFechahora());
        }
    }

    //////////////  OPCION 2    //////////////
    //
    /**
     * Muestra por consola un ránking de los empleados por número de incidencias
     * urgentes creadas.
     */
    private static void mostrarRankingEmpleados() {
        List<RankingEmpleado> ranking = GestorHistorial.rankingEmpleadosPorIncidenciasUrgentesCreadas();

        System.out.println("RANKING DE EMPLEADOS POR NÚMERO DE INCIDENCIAS URGENTES CREADAS");
        for (RankingEmpleado ri : ranking) {
            System.out.println(ri);
        }
    }

    //////////////  OPCION 3    //////////////
    //
    /**
     * Muestra por consola la posición en el ranking del empleado pasado por
     * parámetro.
     *
     * @param e
     */
    private static void mostrarPosicionEmpleadoRanking(Empleado e) {
        List<RankingEmpleado> ranking = GestorHistorial.rankingEmpleadosPorIncidenciasUrgentesCreadas();
        boolean noEstaEnElRanking = true;

        for (RankingEmpleado ri : ranking) {
            if (ri.getEmpleado().getNombreusuario().equals(e.getNombreusuario())) {
                System.out.println("La posición en el ranking de " + e.getNombrecompleto() + " es la " + ri.getPosicion() 
                        + ", con "+ri.getIncidenciasUrgentes() +" incidencias urgentes.");
                noEstaEnElRanking = false;
            }
        }
        if (noEstaEnElRanking) {
            System.out.println("El empleado " + e.getNombrecompleto() + " no ha creado ninguna incidencia urgente.");
        }
    }
}
