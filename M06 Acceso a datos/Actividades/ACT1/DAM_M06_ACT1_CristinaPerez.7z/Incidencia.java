package m06_act1cpb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Cris
 */
//Clase POJO con etiquetas para transformar a XML
@XmlRootElement(name = "Incidencia")
@XmlAccessorType (XmlAccessType.FIELD)
public class Incidencia {
    
    @XmlAttribute(name = "fechaHora", required = true)
    private String fechaHora;
    @XmlElement(required = true)
    private String inicia;
    @XmlElement(required = true)
    private String finaliza;
    @XmlElement(required = true)
    private String detalle;
    @XmlElement(required = true)
    private String tipo;


    @Override
    public String toString() {
        return "Incidencia{" +
                "fechaHora='" + fechaHora + '\'' +
                ", inicia='" + inicia + '\'' +
                ", finaliza='" + finaliza + '\'' +
                ", detalle='" + detalle + '\'' +
                ", tipo='" + tipo + '\'' +
                '}';
    }

    public Incidencia() {
    }

    public Incidencia(String fechaHora, String inicia, String finaliza, String detalle, String tipo) {
        this.fechaHora = fechaHora;
        this.inicia = inicia;
        this.finaliza = finaliza;
        this.detalle = detalle;
        this.tipo = tipo;
    }

    
    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getInicia() {
        return inicia;
    }

    public void setInicia(String inicia) {
        this.inicia = inicia;
    }

    public String getFinaliza() {
        return finaliza;
    }

    public void setFinaliza(String finaliza) {
        this.finaliza = finaliza;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}