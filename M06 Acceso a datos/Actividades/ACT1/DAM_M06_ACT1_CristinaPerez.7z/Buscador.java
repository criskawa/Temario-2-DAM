package m06_act1cpb;

import java.io.FileInputStream;
import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * @author Cris
 */
public class Buscador {

    public static void main(String[] args) {
    
        XPathExpression exp = null;
        Document XMLDoc = null;
        XPath xpath = null;

        //Abrimos el fichero XML y generamos estructura DOM
        try {
            xpath = XPathFactory.newInstance().newXPath();
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            XMLDoc = (Document) factory.newDocumentBuilder().parse(new InputSource(new FileInputStream("..\\..\\incidencias.xml")));

            System.out.println(System.getProperty("user.dir"));
            String salida = "";
            
            //Consulta de incidencias del empleado jramirez 
            exp = xpath.compile("/incidencias/incidencia[finaliza='jramirez']");
            //Resultado
            Object result = exp.evaluate(XMLDoc, XPathConstants.NODESET);
            NodeList nodeList = (NodeList) result;
            
            //Recorremos los nodos
            for (int i = 0; i < nodeList.getLength(); i++) {
                salida = salida
                        + "\n"
                        + "\n" + nodeList.item(i).getNodeName().toUpperCase() + " " + (i + 1)
                        + "\n" + nodeList.item(i).getAttributes().getNamedItem("fechaHora")
                        + "\n" + nodeList.item(i).getChildNodes().item(1).getNodeName()
                        + ": " + nodeList.item(i).getChildNodes().item(1).getChildNodes().item(0).getNodeValue()
                        + "\n" + nodeList.item(i).getChildNodes().item(3).getNodeName()
                        + ": " + nodeList.item(i).getChildNodes().item(3).getChildNodes().item(0).getNodeValue()
                        + "\n" + nodeList.item(i).getChildNodes().item(5).getNodeName()
                        + ": " + nodeList.item(i).getChildNodes().item(5).getChildNodes().item(0).getNodeValue()
                        + "\n" + nodeList.item(i).getChildNodes().item(7).getNodeName()
                        + ": " + nodeList.item(i).getChildNodes().item(7).getChildNodes().item(0).getNodeValue();
            }
            System.out.println(salida);
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }
}
