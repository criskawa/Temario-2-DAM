package m06_act1cpb;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Cris
 */
//Lista de objetos de tipo incidencia y etiquetas para JAXB 
public class Incidencias {

    @XmlRootElement(name = "incidencias")
    @XmlAccessorType(XmlAccessType.FIELD)
    public class Incidencias {

        @XmlElement(name = "incidencia")
        private List<Incidencia> incidencias = null;

        public void setIncidencias(List<Incidencia> incidencias) {
            this.incidencias = incidencias;
        }

        public List<Incidencia> getIncidencias() {
            return incidencias;
        }

    }

}
