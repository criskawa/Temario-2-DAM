package m06_act1cpb;

import m06_act1cpb.Incidencias;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.xml.bind.Marshaller;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.nio.file.Files;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

/**
 * @author Cris
 */
public class Traspaso {

    public static void main(String[] args) throws JAXBException {
        File archivo = null;
        File ruta = null;

        Incidencias incidencias = new Incidencias();

        incidencias.setIncidencias(new ArrayList<>());

        try {

            //Ruta y archivo txt a leer
            ruta = new File("..\\..\\m06_ac1CPB");
            archivo = new File(ruta, "incidencias.txt");

            //Leemos el archivo txt
            if (!archivo.exists()) {
                System.out.println("El archivo no existe");
            } else {
                //Coleccion de Strings con el texto leido
                List<String> txtList = Files.readAllLines(Paths.get("..\\..\\incidencias.txt"));
                String textoCompleto = txtList.toString();

                //Creamos una incidencia por cada % y guardamos en un array.
                String[] incidList = textoCompleto.split("%");

                //Recorremos el array de incidencias
                for (int i = 1; i < incidList.length; i++) {
                    //Dividimos cada caso con comas
                    String[] partesIncidencias = incidList[i].split(",");
                    String[] lineaUno = partesIncidencias[0].split(" ");
                    //Creamos un objeto por cada caso y los añadimos a la lista Incidencia.
                    incidencias.getIncidencias().add(new Incidencia(lineaUno[1] + " " + lineaUno[2], lineaUno[3], lineaUno[4], partesIncidencias[1], partesIncidencias[2]));
                }
                System.out.println("Incidencias");
                //Leemos la lista con toString
                for (Incidencia incidencia : incidencias.getIncidencias()) {
                    System.out.println(incidencia);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        //Creamos el XML
        JAXBContext jaxbContext = JAXBContext.newInstance(Incidencias.class);
        //Parte de serializar
        //Creamos el serializador
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        //Escribimos en formato XML
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        //Generamos el XML por la consola para comprobar que es correcto
        jaxbMarshaller.marshal(incidencias, System.out);
        //Archivo donde guardamos
        File xmlFinal = new File("..\\..\\incidencias.xml");
        //Generar archivo 
        jaxbMarshaller.marshal(incidencias, xmlFinal);
    }
}
