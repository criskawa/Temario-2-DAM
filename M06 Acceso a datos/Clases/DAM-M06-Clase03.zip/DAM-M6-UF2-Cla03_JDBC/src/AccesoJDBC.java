
public class AccesoJDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //EN ESTE MAIN SE INVOCAN A DIFERENTES MÉTODOS SEGÚN LO QUE SE QUIERA HACER. REALMENTE NO ES
        //UNA APLICACIÓN, SOLO UN BENCHMARK PARA PROBAR LO VISTO EN CLASE.
        //RECUERDA:
        // * deben estar instalados los drivers MySQL en NetBeans para que funcione
        // * Se deben crear la estructura de tablas correspondiente que funcione.
        // * Se debe dar acceso a MySQL con usuario "root" y clave "" para que funcione
        Gestor_conexion gestor = new Gestor_conexion();
        
        //USALO PARA: EJECUTAR UNA CONSULTA SELECT
        gestor.Consulta_Statement();
        System.out.println("----------------------------------");
        //USALO PARA: INSERTAR UN REGISTRO NUEVO
        //gestor.Insertar(); 
        //gestor.Insertar(7, "ABBA", "Grupo musical");
        //USALO PARA: EJECUTAR UNA CONSULTA UPDATE
        //gestor.Actualizar();
        //USALO PARA: EJECUTAR UNA CONSULTA DELETE
        //gestor.Borrar();
        //USALO PARA: EJECUTAR UNA CONSULTA SELECT
        gestor.Consulta_Statement(); 
        gestor.cerrar_Conexion();
    }
}
