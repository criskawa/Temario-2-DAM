/*
 * Ejemplo con Hibernate
 */
package damhibgym;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.exception.ConstraintViolationException;
import pojos.Actividad;
import pojos.Matricula;
import pojos.Socio;

public class DamHibGym {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Inicializamos el gestor con ORM
        GymORM miGestor = new GymORM();
        // Trabajamos con el ORM
        /*Socio s = new Socio(8, "Roberto Alfredo Javier", "Fernandez Martínez");
        try {
            miGestor.insertarSocio(s);
            System.out.println("Socio insertado.");
        } catch (ConstraintViolationException ex) {
            System.out.println("El socio no se ha podido insertar. Ya existe.");
        }*/

        Socio otro = new Socio(1, "María", "Robledo");
       /* if (miGestor.existeSocio(otro)) {
            System.out.println("El socio ya existe.");
        } else {
            miGestor.insertarSocio(otro);
            System.out.println("Socio dado de alta");
        }*/

      /*  s.setNombre("Alfredo");
        miGestor.modificarSocio(s);
        System.out.println("Socio modificado.");*/

        System.out.println("Consultas de matrículas de un socio");
        List<Matricula> matriculas = miGestor.matriculasPorSocio(otro);
        for (Matricula m : matriculas) {
            System.out.println(m);
        }

        Socio nuevoSocio = new Socio(9, "Luis", "Lopez");
        miGestor.insertarSocio(nuevoSocio);
        Actividad nuevaActividad = new Actividad("Spining", new BigDecimal(9.50), 1);
        miGestor.insertarActividad(nuevaActividad);
        Matricula nuevaMatricula = new Matricula(nuevaActividad, nuevoSocio, "11/03/2017");
        miGestor.insertarMatricula(nuevaMatricula);

       /* Socio socioMod = new Socio(10, "Alberto", "Gomez");
        miGestor.insertarSocio(socioMod);
        nuevaMatricula.setSocio(socioMod);
        miGestor.modificarMatricula(nuevaMatricula);

        miGestor.borrarSocio(socioMod);
        miGestor.borrarActividad(nuevaActividad);*/

        miGestor.close();
    }

}
