/*
 * Código que se encargará de la persistencia
 */
package damhibgym;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import pojos.Actividad;
import pojos.Matricula;
import pojos.NewHibernateUtil;
import pojos.Socio;

public class GymORM {

    private Session sesion;
    private Transaction tx;

    public GymORM() {
        sesion = NewHibernateUtil.getSessionFactory().openSession();
    }

    public void insertarSocio(Socio s) {
        try {// Siempre se trabaja con transacciones
            tx = sesion.beginTransaction();
            sesion.save(s);
            tx.commit();
        } catch (ConstraintViolationException ex) {
            // haríamos el rollback
            tx.rollback();
            throw ex;
        }
    }

    public void modificarSocio(Socio s) {
        tx = sesion.beginTransaction();
        sesion.update(s);
        tx.commit();
    }

    public void modificarNombre(Socio s) {
        modificarSocio(s);
    }

    public void borrarSocio(Socio s) {
        tx = sesion.beginTransaction();
        sesion.delete(s);
        tx.commit();
    }

    public boolean existeSocio(Socio s) {
        Socio elSocio = (Socio) sesion.get(Socio.class, s.getNumsocio());
//        if (elSocio != null) {
//            return true;
//        } else {
//            return false;
//        }
        return (elSocio != null);
    }

    public List<Matricula> matriculasPorSocio(Socio s) {
        String query = "select m from Matricula m where socio.numsocio = " + s.getNumsocio();
        Query q = sesion.createQuery(query);
        return q.list();
    }
    
    public void insertarMatricula(Matricula m) {
        try {// Siempre se trabaja con transacciones
            tx = sesion.beginTransaction();
            sesion.save(m);
            tx.commit();
        } catch (ConstraintViolationException ex) {
            // haríamos el rollback
            tx.rollback();
            throw ex;
        }
    }
    
     public void modificarMatricula(Matricula m) {
        tx = sesion.beginTransaction();
        sesion.update(m);
        tx.commit();
    }
    
    public void insertarActividad(Actividad a) {
        try {// Siempre se trabaja con transacciones
            tx = sesion.beginTransaction();
            sesion.save(a);
            tx.commit();
        } catch (ConstraintViolationException ex) {
            // haríamos el rollback
            tx.rollback();
            throw ex;
        }
    }
    
    public void borrarActividad(Actividad a) {
        tx = sesion.beginTransaction();
        sesion.delete(a);
        tx.commit();
    }

    public void close() {
        sesion.close();
        //NewHibernateUtil.close();
    }
}
