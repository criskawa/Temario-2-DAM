
//import com.mysql.jdbc.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Gestor_conexion {

    Connection conn1 = null;

    public Gestor_conexion() {
         // ABRE UNA CONEXIÓN A UNA BASE DE DATOS QUE SE SUPONE MYSQL Y QUE TIENE LAS TABLAS
        // Y LOS USUARIOS CREADOS SEGÚN ESTE EJEMPLO.

        try {
            //RECUERDA: PARA EJECUTAR ESTE CÓDIGO ES NECESARIO TENER mYSQL FUNCIONANDO Y LAS TABLAS Y USUARIOS CREADOS
            String url1 = "jdbc:mysql://localhost:3306/discografica";
            String user = "root";
            String password = "";
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Conectado discografica");
            }

        } catch (SQLException ex) {
            System.out.println("ERROR:La dirección no es válida o el usuario y clave");
            ex.printStackTrace();
        }
    }

    public void Insertar_preparedStatement() {
        try {

            // CREA UN STATEMENT PARA UNA CONSULTA SQL INSERT CON PARÁMETROS
            String query = "INSERT INTO album VALUES (?, ?, ?)";
            PreparedStatement pst = conn1.prepareStatement(query);
            pst.setInt(1, 8);
            pst.setString(2, "Black Album");
            pst.setString(3, "Metallica");

            pst.executeUpdate();
            pst.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Insert");
            ex.printStackTrace();
        }
    }

    public void Consulta_Statement() {
        //CRAR UN STATEMENT PARA UNA CONSULTA SELECT
        try {
            Statement stmt = conn1.createStatement();
            //String query = "SELECT * FROM album WHERE titulo like '%B%'";
            String query = "SELECT * FROM album";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println("ID - " + rs.getInt("id")
                        + ", Título " + rs.getString("titulo")
                        + ", Autor " + rs.getString("autor"));
            }
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al consultar");
            ex.printStackTrace();
        }
    }

    public void Consulta_preparedStatement() {
        //CRAR UN STATEMENT PARA UNA CONSULTA SELECT CON PARÁMETROS
        try {
            String query = "SELECT * FROM album WHERE titulo like ?";
            PreparedStatement pst = conn1.prepareStatement(query);
            pst.setString(1, "%B%");

            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                System.out.println("ID - " + rs.getInt("id")
                        + ", Título " + rs.getString("titulo")
                        + ", Autor " + rs.getString("autor"));
            }
            rs.close();
            pst.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al consultar");
            ex.printStackTrace();
        }

    }
    
    public void Actualizar_preparedStatement(){
        try {
            // CREA UN STATEMENT PARA UNA CONSULTA SQL UPDATE CON PARÁMETROS
            String query = "UPDATE album SET titulo=?,autor=? WHERE id=?";
            PreparedStatement pst = conn1.prepareStatement(query);
            pst.setString(1, "Songs of inocence");
            pst.setString(2, "U2");
            pst.setInt(3, 3);

            pst.executeUpdate();
            pst.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Update");
            ex.printStackTrace();
        }
    }
    
    public void Borrar_preparedStatement(){
        try {
            // CREA UN STATEMENT PARA UNA CONSULTA SQL DELETE CON PARÁMETROS
            String query = "DELETE FROM album WHERE id=?";
            PreparedStatement pst = conn1.prepareStatement(query);
            pst.setInt(1, 3);

            pst.executeUpdate();
            pst.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Delete");
            ex.printStackTrace();
        }
    }

    public void cerrar_Conexion() {
        //SE CIERRA LA CONEXIÓN
        try {
            conn1.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al cerrar la conexión");
            ex.printStackTrace();
        }
    }

}
