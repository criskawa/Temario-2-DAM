//import com.mysql.jdbc.Connection;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Gestor_conexion {

    Connection conn1 = null;

    public Gestor_conexion() {
         // ABRE UNA CONEXIÓN A UNA BASE DE DATOS QUE SE SUPONE MYSQL Y QUE TIENE LAS TABLAS
        // Y LOS USUARIOS CREADOS SEGÚN ESTE EJEMPLO.
        try {
            //RECUERDA: PARA EJECUTAR ESTE CÓDIGO ES NECESARIO TENER mYSQL FUNCIONANDO Y LAS TABLAS Y USUARIOS CREADOS
            String url1 = "jdbc:mysql://localhost:3306/discografica";
            String user = "root";
            String password = "";
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Conectado discografica");
            }

        } catch (SQLException ex) {
            System.out.println("ERROR:La dirección no es válida o el usuario y clave");
            ex.printStackTrace();
        }
    }

    public void Insertar_con_commit() {
        //INSERTA CON UN SQL INSERT PERO RESPETANDO TRANSACCIONES
        try {
            conn1.setAutoCommit(false);
            // create our java jdbc statement
            Statement sta = conn1.createStatement();
            sta.executeUpdate("INSERT INTO album VALUES (3, 'Black Album', 'Metallica')");
            sta.executeUpdate("INSERT INTO album VALUES (9, 'A kind of magic', 'Queen')");
            conn1.commit();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Insert");
            try {
                if (conn1 != null) {
                    conn1.rollback();
                }
            } catch (SQLException se2) {
                se2.printStackTrace();
            }//end try
            ex.printStackTrace();
        }
    }
    
    public void Actualizar_con_commit() {
        //INSERTA CON UN SQL UPDATE PERO RESPETANDO TRANSACCIONES
        try {
            conn1.setAutoCommit(false);
            // create our java jdbc statement
            Statement sta = conn1.createStatement();
            sta.executeUpdate("UPDATE album SET titulo='Black Ice',autor='AC/DC' WHERE id=1");
            sta.executeUpdate("UPDATE album SET titulo='Songs of inocence',autor='U2' WHERE id=2");
            sta.executeUpdate("UPDATE album SET titulo='ABC',autor='AA' WHERE id=5");
            conn1.commit();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Update");
            try {
                if (conn1 != null) {
                    conn1.rollback();
                }
            } catch (SQLException se2) {
                se2.printStackTrace();
            }//end try
            ex.printStackTrace();
        }
    }
    
    public void Borrar_con_commit() {
        //INSERTA CON UN SQL DELETE PERO RESPETANDO TRANSACCIONES
        try {
            conn1.setAutoCommit(false);
            // create our java jdbc statement
            Statement sta = conn1.createStatement();
            sta.executeUpdate("DELETE FROM album WHERE autor='U2'");
            sta.executeUpdate("DELETE FROM album WHERE id=5");
            conn1.commit();
        } catch (SQLException ex) {
            System.out.println("ERROR:al hacer un Update");
            try {
                if (conn1 != null) {
                    conn1.rollback();
                }
            } catch (SQLException se2) {
                se2.printStackTrace();
            }//end try
            ex.printStackTrace();
        }
    }

    public void Consulta_Statement() {
        //CRAR UN ESTATEMENT PARA UNA CONSULTA SELECT
        try {
            Statement stmt = conn1.createStatement();
            //String query = "SELECT * FROM album WHERE titulo like 'B%'";
            String query = "SELECT * FROM album";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println("ID - " + rs.getInt("id")
                        + ", Título " + rs.getString("titulo")
                        + ", Autor " + rs.getString("autor"));
            }
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al consultar");
            ex.printStackTrace();
        }
    }

    public void cerrar_Conexion() {
        //SE CIERRA LA CONEXIÓN
        try {
            conn1.close();
        } catch (SQLException ex) {
            System.out.println("ERROR:al cerrar la conexión");
            ex.printStackTrace();
        }
    }

}
