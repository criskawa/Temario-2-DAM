public class AccesoJDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //EN ESTE MAIN SE INVOCAN A DIFERENTES MÉTODOS SEGÚN LO QUE SE QUIERA HACER. REALMENTE NO ES
        //UNA APLICACIÓN, SOLO UN BENCHMARK PARA PROBAR LO VISTO EN EL CAPÍTULO.
        //RECUERDA:
        // * deben estar instalados los drivers MySQL en NetBeans para que funcione
        // * Se deben crear la estructura de tablas correspondiente.
        // * Se debe dar acceso a MySQL con usuario "root" y clave "" para que funcione
        Gestor_conexion gestor = new Gestor_conexion();
        
        //USALO PARA: probar el Pool de conexiones
        //DataSourceExample dse = new DataSourceExample();
        //dse.crearConexion();
        
        //USALO PARA: EJECUTAR UNA CONSULTA SELECT
        gestor.Consulta_Statement();
        System.out.println("----------------------------------");
        //USALO PARA: INSERTAR UN REGISTRO NUEVO CON TRANSACCIONES
        //gestor.Insertar_con_commit();
        //USALO PARA: ACTUALIZAR UN REGISTRO NUEVO CON TRANSACCIONES
        //gestor.Actualizar_con_commit();
        //USALO PARA: BORRAR UN REGISTRO NUEVO CON TRANSACCIONES
        //gestor.Borrar_con_commit();
        //USALO PARA: EJECUTAR UNA CONSULTA SELECT
        gestor.Consulta_Statement();
        gestor.cerrar_Conexion();
    }
}
