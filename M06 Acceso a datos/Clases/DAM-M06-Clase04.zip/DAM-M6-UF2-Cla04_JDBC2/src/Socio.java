
public class Socio {

    private int numSocio;
    private String nombre;
    private String apellidos;

    public Socio() {
        nombre = "";
        apellidos = "";
    }

    public Socio(int numSocio, String nombre, String apellidos) {
        this.numSocio = numSocio;
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumSocio() {
        return numSocio;
    }

    public void setNumSocio(int numSocio) {
        this.numSocio = numSocio;
    }

    @Override
    public String toString() {
        return numSocio + " - " + nombre + " " + apellidos;
    }
}
