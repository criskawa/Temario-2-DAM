import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DamGym {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GymJDBC miGestor = new GymJDBC();
        Socio s = new Socio(3, "Ana", "Garcia");
        Socio s2 = new Socio(4, "Luis", "Garcia");
        Actividad a = new Actividad("Karate", 6.00, 2);
        Actividad a1 = new Actividad("Spinning", 7, 1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm");
        Date ahora = new Date();
        String laFechaEnTexto = sdf.format(ahora);
        System.out.println(laFechaEnTexto);
        Matricula m = new Matricula(0, s, a, laFechaEnTexto);
        try {
            if (!miGestor.existeSocio(s.getNumSocio())) {
                System.out.println("Insertando socio...");
                miGestor.insertarSocio(s);
                System.out.println("Socio insertado");
            }
 /*           System.out.println("Consultar una matricula por su id");
            Matricula consultada = miGestor.getMatriculaById(3);
            System.out.println(consultada);*/
            
            miGestor.insertarMatricula(m);
            System.out.println("Matricula insertada");
            System.out.println("Datos de la matrícula");
            System.out.println(m);
          //  miGestor.insertarSocio(s2);
         //   System.out.println("Socio insertado");

//            System.out.println("Insertando actividades...");
//            miGestor.insertarActividad(a);
//            System.out.println("Actividad insertada.");
//            miGestor.insertarActividad(a1);
//            System.out.println("Actividad insertada");
            System.out.println("Listado de socios");
            List<Socio> misSocios = miGestor.selectAllSocios();
            for (Socio actual : misSocios) {
                System.out.println(actual);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
