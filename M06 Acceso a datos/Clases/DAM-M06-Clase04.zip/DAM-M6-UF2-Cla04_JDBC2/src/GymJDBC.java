import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class GymJDBC {

    private Connection conexion;
    
    public Matricula getMatriculaById(int id) throws SQLException {
        Matricula m = new Matricula();
        conectar();
        String query = "select fecha, numsocio, socio.nombre as nombresocio, apellidos, "
                + "actividad.nombre as nombreactividad, precio, horas from matricula "
                + "join socio join actividad on matricula.socio = numsocio and "
                + "matricula.actividad = actividad.nombre where idmatricula = "+id;
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery(query);
        if(rs.next()) {
            m.setId(id);
            m.getSocio().setNumSocio(rs.getInt("numsocio"));
            m.getSocio().setNombre(rs.getString("nombresocio"));
            m.getSocio().setApellidos(rs.getString("apellidos"));
            Actividad a = new Actividad();
            a.setNombre(rs.getString("nombreactividad"));
            a.setPrecio(rs.getDouble("precio"));
            a.setHoras(rs.getInt("horas"));
            m.setActividad(a);
            m.setFecha(rs.getString("fecha"));
        }
        desconectar();
        return m;
    }
    
    public void insertarMatricula(Matricula m) throws SQLException {
        conectar();
        String insert = "insert into matricula values(null, ?, ?, ?);";
        PreparedStatement ps = conexion.prepareStatement(insert);
        ps.setInt(1, m.getSocio().getNumSocio());
        ps.setString(2, m.getActividad().getNombre());
        ps.setString(3, m.getFecha());
        ps.executeUpdate();
        ps.close();
        String consulta = "select idmatricula from matricula order by idmatricula desc limit 1;";
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery(consulta);
        if (rs.next()) {
            int id = rs.getInt("idmatricula");
            m.setId(id);
        }
        rs.close();
        st.close();
        desconectar();
    }

    public void insertarSocio(Socio s) throws SQLException {
        conectar();
        String insert = "insert into socio values(?, ?, ?);";
        PreparedStatement consultaParametrizada = conexion.prepareStatement(insert);
        consultaParametrizada.setInt(1, s.getNumSocio());
        consultaParametrizada.setString(2, s.getNombre());
        consultaParametrizada.setString(3, s.getApellidos());
        consultaParametrizada.executeUpdate();
        consultaParametrizada.close();
        desconectar();
    }

    public boolean existeSocio(int numSocio) throws SQLException {
        boolean existe;
        conectar();
        // DEfinimos la consulta
        String query = "select * from socio where numsocio=" + numSocio;
        // Creamos el statement para poder ejecutarla
        Statement st = conexion.createStatement();
        // Ejecutamos la consulta y recogemos el resultado
        ResultSet rs = st.executeQuery(query);
        if (rs.next()) {
            // Si el resultado tiene algo es que el socio existe
            existe = true;
            // insertariamos el evento en la tabla historial
        } else {
            existe = false;
        }
        rs.close();
        st.close();
        desconectar();
        return existe;
    }

    public void insertarActividad(Actividad a) throws SQLException {
        conectar();
        String insert = "insert into actividad values(?, ?, ?);";
        PreparedStatement consultaParametrizada = conexion.prepareStatement(insert);
        consultaParametrizada.setString(1, a.getNombre());
        consultaParametrizada.setDouble(2, a.getPrecio());
        consultaParametrizada.setInt(3, a.getHoras());
        consultaParametrizada.executeUpdate();
        consultaParametrizada.close();
        desconectar();
    }

    public List<Socio> selectAllSocios() throws SQLException {
        List<Socio> losSocios = new ArrayList<>();
        conectar();
        String query = "select * from socio;";
        Statement consulta = conexion.createStatement();
        ResultSet resultado = consulta.executeQuery(query);
        while (resultado.next()) {
            Socio s = new Socio();
            s.setNumSocio(resultado.getInt("numsocio"));
            s.setNombre(resultado.getString("nombre"));
            s.setApellidos(resultado.getString("apellidos"));
            losSocios.add(s);
        }
        resultado.close();
        consulta.close();
        desconectar();
        return losSocios;
    }

    private void conectar() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/dam_gym";
        String usr = "root";
        String pass = "";
        conexion = DriverManager.getConnection(url, usr, pass);
    }

    private void desconectar() throws SQLException {
        conexion.close();
    }

}
