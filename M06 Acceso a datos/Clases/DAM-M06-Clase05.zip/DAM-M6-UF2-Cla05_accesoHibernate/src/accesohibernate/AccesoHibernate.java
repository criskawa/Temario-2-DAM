package accesohibernate;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Iterator;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class AccesoHibernate {

    //Esta clase implementa el acceso a hibernate para las operaciones básicas (añadir, consultar, ...)
    //En nuestro caso se ha creado una
    //base de datos en el propio entorno NetBeans.Dentro de ella se ha creado una clase Album.
    //La base de datos debe estar ejecutándose (Pestaña Services->Databases) para que funcione.
    
    public static void annadir_album(int id, String tit, String aut)
    {//añade un objeto nuevo a la base de datos (persistencia)
        Transaction tx=null; 
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        tx=session.beginTransaction(); //Crea una transacción
        Album a = new Album(id, tit, aut);
        //a.setAutor(aut);
        //a.setTitulo(tit);
        //a.setId(id);
        session.save(a);//Guarda el objeto creado en la BBDD.
        tx.commit(); //Materializa la transacción
        session.close();
        
    }
    public static void modificar_album(int id, String tit, String aut)
    {//Modifica un objeto cuyo id se pasa como parámetro
        Transaction tx=null; 
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        tx=session.beginTransaction(); //Crea una transacción
        Album a = new Album(id);
        a.setAutor(aut);
        a.setTitulo(tit);
        a.setId(id);
        session.update(a);//Modifica el objeto con Id indicado
        tx.commit(); //MAterializa la transacción
        session.close();
        
    }
    public static void recuperar_album(int id)
    {//recupera un objeto cuyo id se pasa como parámentro
        //Transaction tx=null; 
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction(); //Crea una transacción
        Album a ;
        a=(Album)session.get(Album.class,id);
        System.out.println ("Autor: " + a.getAutor());
        tx.commit(); //MAterializa la transacción
        session.close();
    }
    
    public static void borrar_album(int id)
    {//Borrar un objeto cuyo id se pasa como parámentro
        Transaction tx=null; 
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        tx=session.beginTransaction(); //Crea una transacción
        Album a = new Album(id,"One", "The Beatles");
        session.delete(a);
        System.out.println ("Objeto borrado");
        tx.commit(); //MAterializa la transacción
        session.close();
    }
    
    public static void consulta(String c)
    {//Ejecuta una consulta cuando el resultado se devuelve como un objeto Albumes
        System.out.println ("Salida de consulta");
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        Query q= session.createQuery(c);
        List results = q.list();
        
        Iterator albumesiterator= results.iterator();
        while (albumesiterator.hasNext())
        {
            Album a2= (Album)albumesiterator.next();
            System.out.println ( a2.getId() + " - " + a2.getTitulo () );
        }
        session.close(); 
        
    }
    public static void consulta2(String c)
    { //Ejecuta una consulta cuando el resultado se devuelve como String
        System.out.println ("Salida de consulta");
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        Query q= session.createQuery(c);
        List results = q.list();
        
        Iterator albumesiterator= results.iterator();
        while (albumesiterator.hasNext())
        {
            String a2= (String)albumesiterator.next();
            System.out.println ( " *-* " + a2 );
        }
        session.close(); 
        
    }
    public static void main(String[] args) {
        //USAR PARA: probar a recuperar un Album
        //recuperar_album(3);
        //USAR PARA: probar a borrar un album
        //borrar_album(3);
        //USAR PARA: probar a modificar un album
        //modificar_album(6,"La casa blanca", "Obus");
        //USAR PARA: probar a añadir un album
         //annadir_album(7,"Far Beyond Driven", "Panteras");
         
         
        //USAR PARA: probar a llamar a consulta
        //consulta("select a from Album a where titulo like '%Black%'");
        //USAR PARA: probar a llamar a consulta2
        //consulta2("SELECT a.titulo from Album a WHERE a.titulo like '%B%' ");
    }
}
